# NOVA KZ — APK gratuito

Este projeto é um aplicativo Android nativo em Kotlin/Jetpack Compose.

## Gerar o APK gratuitamente

A maneira mais simples é usar GitHub Actions. O workflow incluído instala JDK 17, Android SDK 36.1, Build Tools 36.0.0 e Gradle 9.3.1, e depois gera o APK de debug.

### Passos

1. Crie um repositório novo no GitHub, por exemplo `nova-kz-app`.
2. Envie todo o conteúdo desta pasta para a branch `main`.
3. No GitHub, abra **Actions**.
4. Selecione **Build NOVA KZ APK**.
5. Clique em **Run workflow**.
6. Quando terminar, abra a execução concluída.
7. Em **Artifacts**, baixe `NOVA-KZ-debug-apk`.
8. Extraia o ZIP do artifact. O arquivo `app-debug.apk` é o APK instalável.

O APK de debug é assinado automaticamente pelo ambiente de build e pode ser instalado em aparelhos Android para testes.

## Publicar na Google Play

Para produção, não use o APK de debug como versão final. Será necessário configurar uma chave de assinatura de produção e gerar um AAB assinado.

## Observações

As credenciais secretas do Supabase, BitPay ou Gemini não devem ser colocadas no código-fonte público. O arquivo `.env.example` serve apenas como referência para os nomes das variáveis.
