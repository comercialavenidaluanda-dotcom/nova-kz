package com.example

import com.example.ai.AssistantTaskMode
import com.example.ai.ChatMessage
import com.example.ai.ChatSender
import com.example.ai.GeminiAssistantService
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GeminiAssistantServiceTest {

    private lateinit var assistantService: GeminiAssistantService

    @Before
    fun setUp() {
        assistantService = GeminiAssistantService()
    }

    @Test
    fun testTaskModesAndModelIdentifiers() {
        assertEquals("gemini-3.5-flash", AssistantTaskMode.GENERAL.modelId)
        assertEquals("gemini-3.1-pro-preview", AssistantTaskMode.COMPLEX.modelId)
        assertEquals("gemini-3.1-flash-lite-preview", AssistantTaskMode.FAST.modelId)
    }

    @Test
    fun testMultiTurnHistoryFormatting() = runBlocking {
        val history = listOf(
            ChatMessage(sender = ChatSender.USER, text = "Olá"),
            ChatMessage(sender = ChatSender.BOT, text = "Olá! Como posso ajudar com o NOVA KZ?")
        )

        val result = assistantService.sendMessage(
            history = history,
            newMessage = "Como pagar uma guia RUPE?",
            mode = AssistantTaskMode.COMPLEX,
            enableMapsGrounding = false
        )

        assertTrue(result.isSuccess)
        val (reply, locations) = result.getOrThrow()
        assertNotNull(reply)
        assertTrue(reply.contains("RUPE") || reply.contains("NOVA KZ"))
    }

    @Test
    fun testGoogleMapsGroundingLocationExtraction() = runBlocking {
        val result = assistantService.sendMessage(
            history = emptyList(),
            newMessage = "Onde tem caixa Multicaixa perto de mim em Luanda?",
            mode = AssistantTaskMode.GENERAL,
            enableMapsGrounding = true
        )

        assertTrue(result.isSuccess)
        val (reply, locations) = result.getOrThrow()
        assertNotNull(reply)
        assertFalse("Grounding locations should be populated for ATM query", locations.isEmpty())
        val firstLoc = locations.first()
        assertTrue(firstLoc.title.contains("Multicaixa") || firstLoc.bankOrNetwork.contains("BAI") || firstLoc.bankOrNetwork.contains("BFA"))
        assertEquals(true, firstLoc.hasCash)
    }

    @Test
    fun testLiveVoiceAndTranscriptionFallbacks() = runBlocking {
        val voiceResult = assistantService.liveVoiceConversation("Consultar saldo e câmbio")
        assertTrue(voiceResult.isSuccess)
        val voiceReply = voiceResult.getOrThrow()
        assertTrue(voiceReply.isNotBlank())

        val transcriptionResult = assistantService.transcribeAudio(ByteArray(100))
        assertTrue(transcriptionResult.isSuccess)
        val text = transcriptionResult.getOrThrow()
        assertTrue(text.isNotBlank())
    }
}
