package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.LocalDataStore
import com.example.domain.models.AuthMethod
import com.example.domain.models.PaymentStatus
import com.example.domain.models.PaymentType
import com.example.network.NetworkResult
import com.example.network.SupabaseRestClient
import com.example.payments.PaymentManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PaymentSandboxFlowTest {

    private lateinit var dataStore: LocalDataStore
    private lateinit var restClient: SupabaseRestClient
    private lateinit var paymentManager: PaymentManager

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        dataStore = LocalDataStore(context)
        // Reset to initial 1000 AOA for test
        dataStore.sandboxBalance = 1000.0

        restClient = SupabaseRestClient { dataStore.authToken }
        paymentManager = PaymentManager(dataStore, restClient)
    }

    @Test
    fun testMandatorySandbox200AoaPaymentFlow() = runBlocking {
        // 1. Validar Saldo Inicial = 1.000 AOA
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)

        // 2. Criar Pagamento de 200 AOA
        val createResult = paymentManager.createPaymentOperation(
            type = PaymentType.SERVICE_PAYMENT,
            amount = 200.0,
            beneficiary = "ENDE - E.P.",
            description = "Recarga Energia Pré-Pago",
            reference = "99827182918",
            authMethod = AuthMethod.APP
        )

        assertTrue(createResult is NetworkResult.Success)
        val createdOp = (createResult as NetworkResult.Success).data
        assertEquals(200.0, createdOp.amount, 0.001)
        assertEquals(PaymentStatus.PENDING_AUTHORIZATION, createdOp.status)
        assertNotNull(createdOp.idempotencyKey)

        // 3. Autorizar Operação com APP / Biometria
        val authResult = paymentManager.authorizePaymentOperation(
            operationId = createdOp.id,
            authMethod = AuthMethod.APP
        )

        assertTrue(authResult is NetworkResult.Success)
        val authorizedOp = (authResult as NetworkResult.Success).data
        assertEquals(PaymentStatus.AUTHORIZED, authorizedOp.status)

        // 4. Executar Sandbox e Confirmar
        val confirmResult = paymentManager.processAndConfirmPayment(authorizedOp.id)
        assertTrue(confirmResult is NetworkResult.Success)
        val confirmedOp = (confirmResult as NetworkResult.Success).data
        assertEquals(PaymentStatus.CONFIRMED, confirmedOp.status)
        assertNotNull(confirmedOp.completedAt)

        // 5. Validar Saldo Final = 800 AOA (1.000 - 200 = 800 AOA)
        assertEquals(800.0, paymentManager.sandboxBalance.value, 0.001)
        assertEquals(800.0, dataStore.sandboxBalance, 0.001)

        // 6. Teste de Idempotência: Repetir execução da mesma operação NÃO deve debitar novamente
        val duplicateAttempt = paymentManager.processAndConfirmPayment(confirmedOp.id)
        assertTrue("Execução duplicada deve ser rejeitada", duplicateAttempt is NetworkResult.Error)
        // Saldo permanece 800 AOA
        assertEquals(800.0, paymentManager.sandboxBalance.value, 0.001)
    }

    @Test
    fun testInsufficientBalanceRejection() = runBlocking {
        // Saldo inicial: 1000 AOA
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)

        // Tentar pagamento de 1.500 AOA (superior ao saldo)
        val createResult = paymentManager.createPaymentOperation(
            type = PaymentType.TRANSFER,
            amount = 1500.0,
            beneficiary = "Manuel dos Santos",
            description = "Transferência Inválida"
        )
        val createdOp = (createResult as NetworkResult.Success).data

        // Autorizar
        paymentManager.authorizePaymentOperation(createdOp.id)

        // Executar deve falhar por falta de saldo
        val confirmResult = paymentManager.processAndConfirmPayment(createdOp.id)
        assertTrue(confirmResult is NetworkResult.Error)

        // Saldo não pode sofrer alteração
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)
    }

    @Test
    fun testUnauthorizedExecutionRejection() = runBlocking {
        // Criar operação
        val createResult = paymentManager.createPaymentOperation(
            type = PaymentType.SERVICE_PAYMENT,
            amount = 200.0,
            beneficiary = "EPAL",
            description = "Conta de Água"
        )
        val createdOp = (createResult as NetworkResult.Success).data

        // Tentar executar sem antes autorizar
        val confirmResult = paymentManager.processAndConfirmPayment(createdOp.id)
        assertTrue("Operação não autorizada deve ser rejeitada", confirmResult is NetworkResult.Error)
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)
    }

    @Test
    fun testRoomDatabasePersistenceAndOfflineInstantLoad() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val inMemoryDb = androidx.room.Room.inMemoryDatabaseBuilder(
            context,
            com.example.data.local.NovaKzDatabase::class.java
        ).allowMainThreadQueries().build()

        val repository = com.example.data.repository.PaymentTransactionRepository(
            transactionDao = inMemoryDb.paymentTransactionDao(),
            restClient = restClient
        )

        val roomBackedManager = PaymentManager(
            dataStore = dataStore,
            restClient = restClient,
            transactionRepository = repository
        )

        // Criar pagamento com persistência Room
        val opResult = roomBackedManager.createPaymentOperation(
            type = PaymentType.RUPE,
            amount = 350.0,
            beneficiary = "Ministério das Finanças",
            description = "Taxa Aduaneira RUPE",
            reference = "99482718291"
        )
        assertTrue(opResult is NetworkResult.Success)
        val op = (opResult as NetworkResult.Success).data

        // Autorizar e Confirmar
        roomBackedManager.authorizePaymentOperation(op.id)
        roomBackedManager.processAndConfirmPayment(op.id)

        // Validar que o registro está gravado diretamente na tabela Room 'nova_kz_payment_transactions'
        val entityInDb = inMemoryDb.paymentTransactionDao().getTransactionById(op.id)
        assertNotNull("Transação deve estar persistida no Room", entityInDb)
        assertEquals(op.id, entityInDb?.id)
        assertEquals(350.0, entityInDb?.amount ?: 0.0, 0.001)
        assertEquals("CONFIRMED", entityInDb?.status)

        inMemoryDb.close()
    }
}
