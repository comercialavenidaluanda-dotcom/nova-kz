package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.LocalDataStore
import com.example.data.local.NovaKzDatabase
import com.example.data.local.PaymentTransactionEntity
import com.example.data.repository.PaymentTransactionRepository
import com.example.domain.models.AuthMethod
import com.example.domain.models.PaymentOperation
import com.example.domain.models.PaymentStatus
import com.example.domain.models.PaymentType
import com.example.network.NetworkResult
import com.example.network.SupabaseEndpoints
import com.example.network.SupabaseRestClient
import com.example.payments.PaymentManager
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NovaKzSupabaseEndToEndAuditTest {

    private lateinit var context: Context
    private lateinit var dataStore: LocalDataStore
    private lateinit var restClient: SupabaseRestClient
    private lateinit var inMemoryDb: NovaKzDatabase
    private lateinit var repository: PaymentTransactionRepository
    private lateinit var paymentManager: PaymentManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        dataStore = LocalDataStore(context)
        // Saldo inicial Sandbox obrigatório: 1.000,00 AOA
        dataStore.sandboxBalance = 1000.0

        restClient = SupabaseRestClient { dataStore.authToken }

        inMemoryDb = Room.inMemoryDatabaseBuilder(
            context,
            NovaKzDatabase::class.java
        ).allowMainThreadQueries().build()

        repository = PaymentTransactionRepository(
            transactionDao = inMemoryDb.paymentTransactionDao(),
            restClient = restClient
        )

        paymentManager = PaymentManager(
            dataStore = dataStore,
            restClient = restClient,
            transactionRepository = repository
        )
    }

    @After
    fun tearDown() {
        inMemoryDb.close()
    }

    // AUDIT ITEM 5: MÁQUINA DE ESTADOS
    @Test
    fun audit01_testPaymentStateMachineTransitionsAndIllegalRollbacks() {
        // Valid forward path:
        assertTrue(PaymentStatus.DRAFT.canTransitionTo(PaymentStatus.VALIDATED))
        assertTrue(PaymentStatus.VALIDATED.canTransitionTo(PaymentStatus.PENDING_AUTHORIZATION))
        assertTrue(PaymentStatus.PENDING_AUTHORIZATION.canTransitionTo(PaymentStatus.AUTHORIZED))
        assertTrue(PaymentStatus.AUTHORIZED.canTransitionTo(PaymentStatus.PROCESSING))
        assertTrue(PaymentStatus.PROCESSING.canTransitionTo(PaymentStatus.CONFIRMED))

        // Terminal states cannot transition to anything
        assertTrue(PaymentStatus.CONFIRMED.isTerminal())
        assertTrue(PaymentStatus.FAILED.isTerminal())
        assertTrue(PaymentStatus.REJECTED.isTerminal())
        assertTrue(PaymentStatus.CANCELLED.isTerminal())

        // Illegal rollback: CONFIRMED -> PENDING_AUTHORIZATION MUST BE REJECTED
        assertFalse("CONFIRMED -> PENDING_AUTHORIZATION deve ser estritamente proibido",
            PaymentStatus.CONFIRMED.canTransitionTo(PaymentStatus.PENDING_AUTHORIZATION))
        assertFalse("CONFIRMED -> AUTHORIZED deve ser proibido",
            PaymentStatus.CONFIRMED.canTransitionTo(PaymentStatus.AUTHORIZED))
        assertFalse("FAILED -> CONFIRMED deve ser proibido",
            PaymentStatus.FAILED.canTransitionTo(PaymentStatus.CONFIRMED))
    }

    // AUDIT ITEM 6, 7 & 8: FLUXO REAL SANDBOX 1.000 -> 800 AOA + DUPLICAÇÃO
    @Test
    fun audit02_testSandbox200AoaExecutionAndDuplicationProtection() = runBlocking {
        // 1. Saldo Inicial
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)

        // 2. Criar Operação de 200 AOA
        val idempotencyKey = "AUDIT_IDEMP_" + UUID.randomUUID().toString()
        val createResult = paymentManager.createPaymentOperation(
            type = PaymentType.SERVICE_PAYMENT,
            amount = 200.0,
            beneficiary = "ENDE - E.P.",
            description = "Recarga Energia Auditoria",
            reference = "99827182918",
            authMethod = AuthMethod.APP,
            idempotencyKey = idempotencyKey
        )

        assertTrue(createResult is NetworkResult.Success)
        val createdOp = (createResult as NetworkResult.Success).data
        assertEquals(200.0, createdOp.amount, 0.001)
        assertEquals(PaymentStatus.PENDING_AUTHORIZATION, createdOp.status)
        assertEquals(idempotencyKey, createdOp.idempotencyKey)

        // 3. Validação de Biometria / Autorização Sensível
        // O fluxo exige validação antes da transição para AUTHORIZED
        val authResult = paymentManager.authorizePaymentOperation(
            operationId = createdOp.id,
            authMethod = AuthMethod.APP,
            confirmationCode = "BIO_TOKEN_SECURE_VAL"
        )
        assertTrue(authResult is NetworkResult.Success)
        val authorizedOp = (authResult as NetworkResult.Success).data
        assertEquals(PaymentStatus.AUTHORIZED, authorizedOp.status)

        // 4. Execução Sandbox e Confirmação
        val confirmResult = paymentManager.processAndConfirmPayment(authorizedOp.id)
        assertTrue(confirmResult is NetworkResult.Success)
        val confirmedOp = (confirmResult as NetworkResult.Success).data
        assertEquals(PaymentStatus.CONFIRMED, confirmedOp.status)
        assertNotNull(confirmedOp.completedAt)

        // 5. Verificação de Saldo Final: 1.000,00 -> 800,00 AOA
        assertEquals(800.0, paymentManager.sandboxBalance.value, 0.001)
        assertEquals(800.0, dataStore.sandboxBalance, 0.001)

        // 6. Verificação de Persistência no Room
        val savedInRoom = repository.getTransactionById(confirmedOp.id)
        assertNotNull("Transação deve estar salva no Room", savedInRoom)
        assertEquals(PaymentStatus.CONFIRMED, savedInRoom?.status)
        assertEquals(200.0, savedInRoom?.amount ?: 0.0, 0.001)

        // 7. TESTE DE DUPLICAÇÃO / IDEMPOTÊNCIA:
        // Executar novamente com a mesma operação
        val duplicateExecResult = paymentManager.processAndConfirmPayment(confirmedOp.id)
        assertTrue("Segunda execução deve ser rejeitada/idempotente", duplicateExecResult is NetworkResult.Error)

        // Saldo permanece rigorosamente 800,00 AOA (nenhuma nova dedução)
        assertEquals(800.0, paymentManager.sandboxBalance.value, 0.001)
        assertEquals(800.0, dataStore.sandboxBalance, 0.001)

        // Tentar recriar com a mesma idempotency_key deve retornar a operação já existente
        val duplicateCreateResult = paymentManager.createPaymentOperation(
            type = PaymentType.SERVICE_PAYMENT,
            amount = 200.0,
            beneficiary = "ENDE - E.P.",
            description = "Recarga Energia Auditoria",
            reference = "99827182918",
            idempotencyKey = idempotencyKey
        )
        assertTrue(duplicateCreateResult is NetworkResult.Success)
        val returnedExistingOp = (duplicateCreateResult as NetworkResult.Success).data
        assertEquals(confirmedOp.id, returnedExistingOp.id)
        assertEquals(800.0, paymentManager.sandboxBalance.value, 0.001)
    }

    // AUDIT ITEM 12: CONCORRÊNCIA DE EXECUÇÃO
    @Test
    fun audit03_testConcurrentExecutionHandling() = runBlocking {
        assertEquals(1000.0, paymentManager.sandboxBalance.value, 0.001)

        val createResult = paymentManager.createPaymentOperation(
            type = PaymentType.TRANSFER,
            amount = 200.0,
            beneficiary = "Banco BFA Transfer",
            description = "Transferência Concorrente",
            authMethod = AuthMethod.APP
        )
        val op = (createResult as NetworkResult.Success).data
        paymentManager.authorizePaymentOperation(op.id)

        // Simula duas tentativas simultâneas/concorrentes em coroutines
        val task1 = async { paymentManager.processAndConfirmPayment(op.id) }
        val task2 = async { paymentManager.processAndConfirmPayment(op.id) }

        val result1 = task1.await()
        val result2 = task2.await()

        // Exatamente UMA deve ter tido sucesso de execução e a outra deve ter sido rejeitada
        val successCount = listOf(result1, result2).count { it is NetworkResult.Success }
        val errorCount = listOf(result1, result2).count { it is NetworkResult.Error }

        assertEquals(1, successCount)
        assertEquals(1, errorCount)

        // Saldo resultante: debitado exatamente uma vez (1.000 -> 800 AOA)
        assertEquals(800.0, paymentManager.sandboxBalance.value, 0.001)
        assertEquals(800.0, dataStore.sandboxBalance, 0.001)
    }

    // AUDIT ITEM 4 & 9: OFFLINE CACHE & REACTIVE FLOW
    @Test
    fun audit04_testOfflineRoomCacheAndReconnection() = runBlocking {
        val isolatedDb = Room.inMemoryDatabaseBuilder(
            context,
            NovaKzDatabase::class.java
        ).allowMainThreadQueries().build()

        val offlineOp = PaymentOperation(
            id = "offline-tx-001",
            idempotencyKey = "idemp-off-001",
            type = PaymentType.ENERGY,
            amount = 120.0,
            currency = "AOA",
            beneficiary = "ENDE Luanda",
            description = "Pagamento Offline",
            status = PaymentStatus.CONFIRMED,
            environment = "SANDBOX",
            createdAt = "22/09/2026 10:00"
        )
        val isolatedRepo = PaymentTransactionRepository(
            transactionDao = isolatedDb.paymentTransactionDao(),
            restClient = restClient
        )
        isolatedRepo.saveOrUpdateTransaction(offlineOp)

        // 1. Mesmo sem rede, Room emite os dados offline imediatamente
        val cachedList = isolatedRepo.allTransactions.first()
        assertTrue(cachedList.any { it.id == "offline-tx-001" })
        assertEquals(1, isolatedRepo.getTransactionCount())

        // 2. Sincronização offline: quando a rede falha, o cache local NÃO é destruído
        val simulatedOfflineClient = SupabaseRestClient(baseUrl = "https://unreachable.supabase.local") { null }
        val offlineRepo = PaymentTransactionRepository(
            transactionDao = isolatedDb.paymentTransactionDao(),
            restClient = simulatedOfflineClient
        )
        val syncResult = offlineRepo.syncTransactionsFromBackend()
        // Deve retornar erro de rede sem lançar exceção fatal
        assertTrue(syncResult is NetworkResult.Error)

        // Cache continua intacto e seguro
        val cacheAfterOffline = offlineRepo.allTransactions.first()
        assertEquals(1, cacheAfterOffline.size)
        assertEquals("offline-tx-001", cacheAfterOffline[0].id)

        isolatedDb.close()
    }

    // AUDIT ITEM 2 & 10: CONSISTÊNCIA DE SCHEMA ROOM VS SUPABASE
    @Test
    fun audit05_testRoomSchemaAndSupabaseColumnsAlignment() {
        val entity = PaymentTransactionEntity(
            id = "tx-schema-01",
            idempotencyKey = "idemp-schema-01",
            type = "SERVICE_PAYMENT",
            amount = 200.0,
            currency = "AOA",
            beneficiary = "ENDE",
            beneficiaryAccount = "AO06.1234",
            reference = "9982718",
            description = "Teste de Schema",
            status = "CONFIRMED",
            authMethod = "APP",
            environment = "SANDBOX",
            createdAt = "22/09/2026 12:00",
            completedAt = "22/09/2026 12:01",
            fee = 0.0,
            transactionId = "NKZ-12345678",
            failureReason = null,
            updatedAt = 1790066860000L
        )

        // Valida conversão bidirecional sem perda de dados
        val domain = entity.toDomainModel()
        assertEquals(entity.id, domain.id)
        assertEquals(entity.idempotencyKey, domain.idempotencyKey)
        assertEquals(PaymentType.SERVICE_PAYMENT, domain.type)
        assertEquals(PaymentStatus.CONFIRMED, domain.status)
        assertEquals(AuthMethod.APP, domain.authMethod)

        val reconstructed = PaymentTransactionEntity.fromDomainModel(domain)
        assertEquals(entity.id, reconstructed.id)
        assertEquals(entity.amount, reconstructed.amount, 0.001)
        assertEquals(entity.beneficiary, reconstructed.beneficiary)
    }
}
