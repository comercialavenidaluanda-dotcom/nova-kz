package com.example.insurance

import com.example.domain.models.InsuranceProduct
import com.example.domain.models.InsuranceQuote
import com.example.domain.models.InsurerCompany
import com.example.network.NetworkResult
import com.example.network.SupabaseRestClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class InsuranceRepository(
    private val restClient: SupabaseRestClient
) {
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "AO"))

    private val _quotes = MutableStateFlow<List<InsuranceQuote>>(emptyList())
    val quotes: StateFlow<List<InsuranceQuote>> = _quotes.asStateFlow()

    init {
        // Sample initial quote
        _quotes.value = listOf(
            InsuranceQuote(
                id = "quote_sample_01",
                insurer = InsurerCompany.NOSSA,
                product = InsuranceProduct.AUTO,
                clientName = "Utilizador NOVA KZ",
                clientPhone = "+244 923 000 000",
                clientEmail = "comercialavenidaluanda@gmail.com",
                notes = "Viatura ligeira de passageiros, Luanda",
                quoteAmountAoa = 45000.0,
                status = "COTADO_SANDBOX",
                isSandbox = true,
                createdAt = dateFormat.format(Date(System.currentTimeMillis() - 86400000L)),
                quoteReference = "SEG-839201"
            )
        )
    }

    suspend fun requestQuote(
        insurer: InsurerCompany,
        product: InsuranceProduct,
        clientName: String,
        clientPhone: String,
        clientEmail: String,
        notes: String
    ): NetworkResult<InsuranceQuote> {
        if (clientName.isBlank() || clientPhone.isBlank() || clientEmail.isBlank()) {
            return NetworkResult.Error("Preencha o nome, telefone e e-mail para a cotação.")
        }

        // Calculate estimated premium based on product
        val calculatedAmount = product.baseEstimateAoa

        val quote = InsuranceQuote(
            id = UUID.randomUUID().toString(),
            insurer = insurer,
            product = product,
            clientName = clientName,
            clientPhone = clientPhone,
            clientEmail = clientEmail,
            notes = notes,
            quoteAmountAoa = calculatedAmount,
            status = "COTADO_SANDBOX",
            isSandbox = true,
            createdAt = dateFormat.format(Date()),
            quoteReference = "SEG-" + System.currentTimeMillis().toString().takeLast(6)
        )

        // Call Integration Gateway Edge Function for Seguros
        val payload = JSONObject().apply {
            put("provider", insurer.name)
            put("product", product.name)
            put("client_name", clientName)
            put("client_phone", clientPhone)
            put("client_email", clientEmail)
            put("notes", notes)
            put("quote_amount", calculatedAmount)
            put("currency", "AOA")
            put("homologated", insurer.providerHomologated)
        }

        restClient.invokeEdgeGateway("insurance_quote_request", payload)

        _quotes.value = listOf(quote) + _quotes.value
        return NetworkResult.Success(quote)
    }

    fun markQuoteAsPaid(quoteId: String) {
        _quotes.value = _quotes.value.map {
            if (it.id == quoteId) it.copy(status = "PAGO_SANDBOX") else it
        }
    }
}
