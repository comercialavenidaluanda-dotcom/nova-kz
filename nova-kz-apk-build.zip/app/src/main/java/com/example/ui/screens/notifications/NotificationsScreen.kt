package com.example.ui.screens.notifications

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.NotificationCategory
import com.example.domain.models.NovaNotification
import com.example.notifications.NotificationRepository
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.components.formatAoa
import com.example.ui.theme.NovaBorder
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaInfoBlue
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaSandboxAmber
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary

@Composable
fun NotificationsScreen(
    notificationRepository: NotificationRepository,
    onNavigateToOperation: (String) -> Unit,
    onBack: () -> Unit
) {
    val notifications by notificationRepository.notifications.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Notificações",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SandboxDisclaimerBanner()
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Centro de Alertas & Notificações",
                        color = NovaTextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Marcar todas como lidas",
                        color = NovaGold,
                        fontSize = 11.sp,
                        modifier = Modifier.clickable { notificationRepository.markAllAsRead() }
                    )
                }
            }

            items(notifications) { notif ->
                NotificationItemCard(
                    notification = notif,
                    onClick = {
                        notificationRepository.markAsRead(notif.id)
                        notif.operationId?.let { opId ->
                            onNavigateToOperation(opId)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun NotificationItemCard(
    notification: NovaNotification,
    onClick: () -> Unit
) {
    val icon = when (notification.category) {
        NotificationCategory.TRANSFER_DONE -> Icons.AutoMirrored.Filled.Send
        NotificationCategory.PAYMENT_DONE -> Icons.Default.Payment
        NotificationCategory.VALUE_RECEIVED -> Icons.Default.Payment
        NotificationCategory.NEW_AUTHORIZATION, NotificationCategory.PAYMENT_PENDING -> Icons.Default.Warning
        NotificationCategory.INSURANCE -> Icons.Default.HealthAndSafety
        NotificationCategory.ACCOUNT_SECURITY -> Icons.Default.Shield
        else -> Icons.Default.Notifications
    }

    val iconTint = when (notification.category) {
        NotificationCategory.TRANSFER_DONE, NotificationCategory.PAYMENT_DONE, NotificationCategory.VALUE_RECEIVED -> NovaEmerald
        NotificationCategory.NEW_AUTHORIZATION, NotificationCategory.PAYMENT_PENDING -> NovaSandboxAmber
        NotificationCategory.PAYMENT_FAILED -> NovaDangerRed
        NotificationCategory.ACCOUNT_SECURITY -> NovaInfoBlue
        else -> NovaGold
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .testTag("notification_card_${notification.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (!notification.isRead) NovaNavySurface else NovaNavyCard
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp,
                    if (!notification.isRead) NovaGold.copy(alpha = 0.4f) else NovaNavyCardBorder.copy(alpha = 0.6f),
                    RoundedCornerShape(14.dp)
                )
                .padding(16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(NovaNavyDark),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = notification.title,
                        color = NovaTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (!notification.isRead) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(NovaGold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = notification.body,
                    color = NovaTextSecondary,
                    fontSize = 12.sp
                )

                if (notification.amount != null && notification.amount > 0) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Valor: ${formatAoa(notification.amount)}",
                        color = NovaGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = notification.timestamp,
                    color = NovaTextSecondary.copy(alpha = 0.7f),
                    fontSize = 10.sp
                )
            }
        }
    }
}
