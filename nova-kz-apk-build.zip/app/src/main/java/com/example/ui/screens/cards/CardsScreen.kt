package com.example.ui.screens.cards

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.CardItem
import com.example.domain.models.CardStatus
import com.example.payments.PaymentManager
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.components.formatAoa
import com.example.ui.theme.NovaBorder
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaEmeraldBg
import com.example.ui.theme.NovaEmeraldLight
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaGoldLight
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary

@Composable
fun CardsScreen(
    paymentManager: PaymentManager,
    onBack: () -> Unit
) {
    val cards by paymentManager.cards.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Cartões",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SandboxDisclaimerBanner()
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Gestão de Cartões Multicaixa & Internacionais",
                    color = NovaTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Por razões estritas de segurança bancária, apenas a marca, nome amigável e os últimos 4 dígitos são armazenados e exibidos.",
                    color = NovaTextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            items(cards) { card ->
                SecurityCompliantCardItem(card = card)
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                SecurityNoticeCard()
            }
        }
    }
}

@Composable
fun SecurityCompliantCardItem(card: CardItem) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(190.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = if (card.isVirtual) listOf(Color(0xFF1B3D72), Color(0xFF091629))
                    else listOf(Color(0xFF193254), Color(0xFF0A1626))
                )
            )
            .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(20.dp))
            .padding(22.dp)
            .testTag("card_item_${card.id}")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(NovaGold.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CreditCard,
                            contentDescription = null,
                            tint = NovaGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = card.friendlyName,
                        color = NovaTextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(NovaEmeraldBg.copy(alpha = 0.85f))
                        .border(1.dp, NovaEmerald.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .padding(horizontal = 9.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = card.status.label,
                        color = NovaEmeraldLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Security Masked Number (Only last 4 digits)
            Text(
                text = "••••   ••••   ••••   ${card.last4Digits}",
                color = NovaGoldLight,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.5.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "VALIDADE", color = NovaTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = card.expiryDate, color = NovaTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Column {
                    Text(text = "LIMITE DIÁRIO", color = NovaTextSecondary, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = formatAoa(card.dailyLimitAoa), color = NovaTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
                Text(
                    text = card.brand.uppercase(),
                    color = NovaGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
fun SecurityNoticeCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(12.dp))
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = null,
                tint = NovaEmerald,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "Proteção de Dados Financeiros",
                    color = NovaTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Nunca guardamos PIN do cartão, CVV ou códigos de segurança nos nossos servidores.",
                    color = NovaTextSecondary,
                    fontSize = 11.sp
                )
            }
        }
    }
}
