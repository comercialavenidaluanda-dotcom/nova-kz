package com.example.ui.screens.credit

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.components.formatAoa
import com.example.ui.theme.NovaEmeraldLight
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaGoldLight
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary

@Composable
fun CreditScreen(onBack: () -> Unit) {
    var loanAmount by remember { mutableFloatStateOf(50000f) }
    var termMonths by remember { mutableFloatStateOf(6f) }
    var isSubmitted by remember { mutableStateOf(false) }

    val monthlyRate = 0.035 // 3.5% Sandbox interest rate
    val monthlyPayment = (loanAmount * (1 + (monthlyRate * termMonths))) / termMonths

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Crédito & Financiamento",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SandboxDisclaimerBanner()
            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Simulação de Microcrédito NOVA KZ",
                color = NovaTextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                text = "Solução de financiamento pontual e tesouraria para particulares e pequenos negócios em Angola (Sandbox).",
                color = NovaTextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Simulation Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(14.dp))
                        .padding(18.dp)
                ) {
                    Text(
                        text = "Montante do Financiamento",
                        color = NovaTextSecondary,
                        fontSize = 12.sp
                    )
                    Text(
                        text = formatAoa(loanAmount.toDouble()),
                        color = NovaGoldLight,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold
                    )

                    Slider(
                        value = loanAmount,
                        onValueChange = { loanAmount = it },
                        valueRange = 10000f..500000f,
                        steps = 48,
                        colors = SliderDefaults.colors(
                            thumbColor = NovaGold,
                            activeTrackColor = NovaGold,
                            inactiveTrackColor = NovaNavyCardBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Prazo de Reembolso: ${termMonths.toInt()} Meses",
                        color = NovaTextSecondary,
                        fontSize = 12.sp
                    )

                    Slider(
                        value = termMonths,
                        onValueChange = { termMonths = it },
                        valueRange = 1f..12f,
                        steps = 10,
                        colors = SliderDefaults.colors(
                            thumbColor = NovaGold,
                            activeTrackColor = NovaGold,
                            inactiveTrackColor = NovaNavyCardBorder
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(NovaNavyCardBorder)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Prestação Mensal Estimada:", color = NovaTextSecondary, fontSize = 13.sp)
                        Text(
                            text = formatAoa(monthlyPayment.toDouble()),
                            color = NovaGold,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Taxa Nominal (TAN Sandbox):", color = NovaTextSecondary, fontSize = 12.sp)
                        Text(text = "3.5% / mês", color = NovaTextPrimary, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (isSubmitted) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = NovaNavySurface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, NovaEmeraldLight, RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Text(
                            text = "Proposta Submetida para Análise em Sandbox",
                            color = NovaEmeraldLight,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "A sua proposta de financiamento foi registada no ambiente Sandbox para avaliação automática.",
                            color = NovaTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            NovaButton(
                text = "Solicitar Financiamento Sandbox",
                onClick = { isSubmitted = true },
                modifier = Modifier.fillMaxWidth(),
                testTag = "credit_submit_button"
            )
        }
    }
}
