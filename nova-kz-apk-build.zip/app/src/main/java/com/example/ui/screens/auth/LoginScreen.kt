package com.example.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.auth.AuthManager
import com.example.network.NetworkResult
import com.example.ui.components.NovaButton
import com.example.ui.components.SandboxBadge
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(
    authManager: AuthManager,
    onLoginSuccess: () -> Unit,
    onNavigateToRegister: () -> Unit,
    onNavigateToForgotPassword: () -> Unit,
    onBiometricLogin: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("ivanioalberto83@gmail.com") }
    var pinOrPassword by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        // Brand Emblem
        Box(
            modifier = Modifier
                .size(76.dp)
                .clip(CircleShape)
                .background(NovaNavyCard),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "NKZ",
                color = NovaGold,
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "NOVA KZ",
            color = NovaTextPrimary,
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp
        )

        Text(
            text = "Plataforma Nativa de Pagamentos & Finanças",
            color = NovaTextSecondary,
            fontSize = 13.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(14.dp))
        SandboxBadge()

        Spacer(modifier = Modifier.height(28.dp))
        SandboxDisclaimerBanner()
        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = email,
            onValueChange = {
                email = it
                errorMessage = null
            },
            label = { Text("E-mail ou Telefone", color = NovaTextSecondary) },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Mail, contentDescription = null, tint = NovaGold)
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NovaGold,
                unfocusedBorderColor = NovaNavyCardBorder,
                focusedTextColor = NovaTextPrimary,
                unfocusedTextColor = NovaTextPrimary
            ),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("login_email_input")
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = pinOrPassword,
            onValueChange = {
                pinOrPassword = it
                errorMessage = null
            },
            label = { Text("Palavra-passe ou PIN", color = NovaTextSecondary) },
            leadingIcon = {
                Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = NovaGold)
            },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NovaGold,
                unfocusedBorderColor = NovaNavyCardBorder,
                focusedTextColor = NovaTextPrimary,
                unfocusedTextColor = NovaTextPrimary
            ),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("login_password_input")
        )

        if (errorMessage != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = errorMessage!!,
                color = NovaDangerRed,
                fontSize = 12.sp,
                textAlign = TextAlign.Start,
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Text(
                text = "Recuperar acesso?",
                color = NovaGold,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clickable { onNavigateToForgotPassword() }
                    .padding(4.dp)
                    .testTag("login_forgot_password_link")
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        NovaButton(
            text = "Entrar no NOVA KZ",
            onClick = {
                scope.launch {
                    isLoading = true
                    errorMessage = null
                    val result = authManager.login(email, pinOrPassword)
                    isLoading = false
                    when (result) {
                        is NetworkResult.Success -> onLoginSuccess()
                        is NetworkResult.Error -> errorMessage = result.message
                    }
                }
            },
            isLoading = isLoading,
            modifier = Modifier.fillMaxWidth(),
            testTag = "login_submit_button"
        )

        Spacer(modifier = Modifier.height(12.dp))

        NovaButton(
            text = "Entrar com Biometria",
            onClick = onBiometricLogin,
            isSecondary = true,
            leadingIcon = Icons.Default.Fingerprint,
            modifier = Modifier.fillMaxWidth(),
            testTag = "login_biometric_button"
        )

        Spacer(modifier = Modifier.height(28.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Ainda não tem conta? ",
                color = NovaTextSecondary,
                fontSize = 14.sp
            )
            Text(
                text = "Criar conta",
                color = NovaGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable { onNavigateToRegister() }
                    .padding(4.dp)
                    .testTag("login_register_link")
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}
