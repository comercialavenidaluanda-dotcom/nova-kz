package com.example.ui.screens.services

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.AuthMethod
import com.example.domain.models.PaymentType
import com.example.domain.models.ServiceCategoryType
import com.example.domain.models.ServiceProviderItem
import com.example.network.NetworkResult
import com.example.payments.PaymentManager
import com.example.services.ServicesCatalog
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaGoldLight
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import kotlinx.coroutines.launch

@Composable
fun ServicesScreen(
    paymentManager: PaymentManager,
    onNavigateToAuthorize: (String) -> Unit,
    onNavigateToInsurance: () -> Unit,
    onBack: () -> Unit,
    onNavigateToAssistant: () -> Unit = {}
) {
    val scope = rememberCoroutineScope()
    var selectedCategory by remember { mutableStateOf(ServiceCategoryType.ESTADO) }
    var selectedProvider by remember { mutableStateOf(ServicesCatalog.providers.first()) }
    var referenceInput by remember { mutableStateOf("24010293849102") }
    var amountInput by remember { mutableStateOf("500") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val categories = ServiceCategoryType.values()
    val filteredProviders = ServicesCatalog.getProvidersByCategory(selectedCategory)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Pagamento de Serviços",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                SandboxDisclaimerBanner()
            }

            // BankBot AI Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onNavigateToAssistant() }
                        .testTag("services_assistant_banner"),
                    colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, NovaGold.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(NovaGold.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = NovaGold,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Assistente Inteligente & Google Maps",
                                color = NovaTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Tire dúvidas sobre RUPE, câmbio BNA e caixas Multicaixa",
                                color = NovaTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .background(NovaGold, RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Abrir",
                                color = NovaNavyDark,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Catálogo de Serviços em Angola",
                    color = NovaTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Selecione a categoria e o fornecedor para liquidação imediata em Sandbox.",
                    color = NovaTextSecondary,
                    fontSize = 12.sp
                )
            }

            // Categories horizontal scroller
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories) { cat ->
                        val isSelected = cat == selectedCategory
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) NovaGold else NovaNavyCard)
                                .border(1.dp, if (isSelected) NovaGold else NovaNavyCardBorder, RoundedCornerShape(20.dp))
                                .clickable {
                                    selectedCategory = cat
                                    val newProviders = ServicesCatalog.getProvidersByCategory(cat)
                                    if (newProviders.isNotEmpty()) {
                                        selectedProvider = newProviders.first()
                                        referenceInput = ""
                                    }
                                }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = cat.label,
                                color = if (isSelected) NovaNavyDark else NovaTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            if (selectedCategory == ServiceCategoryType.SEGUROS) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToInsurance() },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, NovaGold, RoundedCornerShape(12.dp))
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Módulo Especializado de Seguros",
                                color = NovaGold,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Consulte cotações com NOSSA Seguros, ENSA, Fidelidade, SanlamAllianz e VIVA.",
                                color = NovaTextSecondary,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            NovaButton(
                                text = "Abrir Módulo de Seguros",
                                onClick = onNavigateToInsurance,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            } else {
                // Providers in this category
                item {
                    Text(
                        text = "Fornecedor / Entidade",
                        color = NovaTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(filteredProviders) { provider ->
                    val isSelected = provider.id == selectedProvider.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedProvider = provider
                                referenceInput = ""
                            }
                            .testTag("service_provider_${provider.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) NovaNavySurface else NovaNavyCard
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    1.dp,
                                    if (isSelected) NovaGold else NovaNavyCardBorder,
                                    RoundedCornerShape(12.dp)
                                )
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(NovaNavyDark),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (provider.category) {
                                        ServiceCategoryType.ENERGIA -> Icons.Default.ElectricBolt
                                        ServiceCategoryType.AGUA -> Icons.Default.WaterDrop
                                        ServiceCategoryType.TELECOM -> Icons.Default.Phone
                                        ServiceCategoryType.EDUCACAO -> Icons.Default.School
                                        else -> Icons.Default.Widgets
                                    },
                                    contentDescription = null,
                                    tint = NovaGold,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = provider.name,
                                    color = if (isSelected) NovaGoldLight else NovaTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Entidade: ${provider.entityCode} • ${provider.description}",
                                    color = NovaTextSecondary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                // Payment form for selected provider
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(14.dp))
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "Dados para Liquidação: ${selectedProvider.name}",
                                color = NovaGold,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = referenceInput,
                                onValueChange = { referenceInput = it },
                                label = { Text(selectedProvider.referenceLabel, color = NovaTextSecondary) },
                                placeholder = { Text(selectedProvider.placeholderRef, color = NovaTextSecondary.copy(alpha = 0.5f)) },
                                leadingIcon = { Icon(Icons.Default.Numbers, null, tint = NovaGold) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NovaGold,
                                    unfocusedBorderColor = NovaNavyCardBorder,
                                    focusedTextColor = NovaTextPrimary,
                                    unfocusedTextColor = NovaTextPrimary
                                ),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = amountInput,
                                onValueChange = { amountInput = it },
                                label = { Text("Montante a Pagar (AOA)", color = NovaTextSecondary) },
                                leadingIcon = { Icon(Icons.Default.Payment, null, tint = NovaGold) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NovaGold,
                                    unfocusedBorderColor = NovaNavyCardBorder,
                                    focusedTextColor = NovaTextPrimary,
                                    unfocusedTextColor = NovaTextPrimary
                                ),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            if (errorMessage != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = errorMessage!!,
                                    color = NovaDangerRed,
                                    fontSize = 12.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            NovaButton(
                                text = "Continuar para Autorização",
                                onClick = {
                                    val amount = amountInput.toDoubleOrNull()
                                    if (amount == null || amount <= 0) {
                                        errorMessage = "Introduza um montante válido superior a 0,00 AOA."
                                        return@NovaButton
                                    }
                                    if (referenceInput.isBlank()) {
                                        errorMessage = "Introduza o ${selectedProvider.referenceLabel}."
                                        return@NovaButton
                                    }

                                    scope.launch {
                                        isLoading = true
                                        errorMessage = null
                                        val result = paymentManager.createPaymentOperation(
                                            type = PaymentType.SERVICE_PAYMENT,
                                            amount = amount,
                                            beneficiary = selectedProvider.name,
                                            reference = referenceInput,
                                            description = "Pagamento de ${selectedProvider.name}",
                                            authMethod = AuthMethod.APP
                                        )
                                        isLoading = false
                                        when (result) {
                                            is NetworkResult.Success -> onNavigateToAuthorize(result.data.id)
                                            is NetworkResult.Error -> errorMessage = result.message
                                        }
                                    }
                                },
                                isLoading = isLoading,
                                modifier = Modifier.fillMaxWidth(),
                                testTag = "service_pay_submit_button"
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
