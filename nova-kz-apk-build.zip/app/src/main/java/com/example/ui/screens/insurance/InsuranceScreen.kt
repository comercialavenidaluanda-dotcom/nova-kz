package com.example.ui.screens.insurance

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.AuthMethod
import com.example.domain.models.InsuranceProduct
import com.example.domain.models.InsuranceQuote
import com.example.domain.models.InsurerCompany
import com.example.domain.models.PaymentType
import com.example.insurance.InsuranceRepository
import com.example.network.NetworkResult
import com.example.payments.PaymentManager
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxBadge
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.components.formatAoa
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaEmeraldBg
import com.example.ui.theme.NovaEmeraldLight
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaGoldLight
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaSandboxAmber
import com.example.ui.theme.NovaSandboxBg
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import kotlinx.coroutines.launch

@Composable
fun InsuranceScreen(
    insuranceRepository: InsuranceRepository,
    paymentManager: PaymentManager,
    onNavigateToAuthorize: (String) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val quotes by insuranceRepository.quotes.collectAsState()

    var selectedInsurer by remember { mutableStateOf(InsurerCompany.NOSSA) }
    var selectedProduct by remember { mutableStateOf(InsuranceProduct.AUTO) }

    var clientName by remember { mutableStateOf("Manuel Bento") }
    var clientPhone by remember { mutableStateOf("+244 923 000 000") }
    var clientEmail by remember { mutableStateOf("manuel.bento@exemplo.ao") }
    var notes by remember { mutableStateOf("Viatura Toyota Hilux 2022, Luanda") }

    var isLoading by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Seguros & Cotações",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                SandboxDisclaimerBanner()
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Módulo de Seguros NOVA KZ",
                    color = NovaTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Simulações e pedidos de cotação em ambiente Sandbox. Toda integração real passa pelo Integration Gateway / Edge Functions.",
                    color = NovaTextSecondary,
                    fontSize = 12.sp
                )
            }

            // Insurers Selection
            item {
                Text(
                    text = "Selecione a Seguradora",
                    color = NovaTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(InsurerCompany.values()) { insurer ->
                        val isSelected = insurer == selectedInsurer
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) NovaNavySurface else NovaNavyCard)
                                .border(1.dp, if (isSelected) NovaGold else NovaNavyCardBorder, RoundedCornerShape(10.dp))
                                .clickable { selectedInsurer = insurer }
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                                .testTag("insurer_${insurer.name}")
                        ) {
                            Column {
                                Text(
                                    text = insurer.companyName,
                                    color = if (isSelected) NovaGoldLight else NovaTextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Sandbox Homologado",
                                    color = NovaSandboxAmber,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }

            // Products Selection
            item {
                Text(
                    text = "Tipo de Seguro",
                    color = NovaTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(InsuranceProduct.values()) { prod ->
                        val isSelected = prod == selectedProduct
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) NovaGold else NovaNavyCard)
                                .border(1.dp, if (isSelected) NovaGold else NovaNavyCardBorder, RoundedCornerShape(20.dp))
                                .clickable { selectedProduct = prod }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = prod.productName,
                                color = if (isSelected) NovaNavyDark else NovaTextPrimary,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // Form
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(14.dp))
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Dados do Proponente",
                            color = NovaGold,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = clientName,
                            onValueChange = { clientName = it },
                            label = { Text("Nome Completo", color = NovaTextSecondary) },
                            leadingIcon = { Icon(Icons.Default.Person, null, tint = NovaGold) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NovaGold,
                                unfocusedBorderColor = NovaNavyCardBorder,
                                focusedTextColor = NovaTextPrimary,
                                unfocusedTextColor = NovaTextPrimary
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = clientPhone,
                            onValueChange = { clientPhone = it },
                            label = { Text("Telefone (+244)", color = NovaTextSecondary) },
                            leadingIcon = { Icon(Icons.Default.Phone, null, tint = NovaGold) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NovaGold,
                                unfocusedBorderColor = NovaNavyCardBorder,
                                focusedTextColor = NovaTextPrimary,
                                unfocusedTextColor = NovaTextPrimary
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = clientEmail,
                            onValueChange = { clientEmail = it },
                            label = { Text("E-mail", color = NovaTextSecondary) },
                            leadingIcon = { Icon(Icons.Default.Mail, null, tint = NovaGold) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NovaGold,
                                unfocusedBorderColor = NovaNavyCardBorder,
                                focusedTextColor = NovaTextPrimary,
                                unfocusedTextColor = NovaTextPrimary
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("Detalhes do Bem / Observações", color = NovaTextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NovaGold,
                                unfocusedBorderColor = NovaNavyCardBorder,
                                focusedTextColor = NovaTextPrimary,
                                unfocusedTextColor = NovaTextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        if (errorMessage != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = errorMessage!!, color = NovaDangerRed, fontSize = 12.sp)
                        }

                        if (statusMessage != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = statusMessage!!, color = NovaEmeraldLight, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        NovaButton(
                            text = "Solicitar Cotação em Sandbox",
                            onClick = {
                                scope.launch {
                                    isLoading = true
                                    errorMessage = null
                                    statusMessage = null
                                    val result = insuranceRepository.requestQuote(
                                        insurer = selectedInsurer,
                                        product = selectedProduct,
                                        clientName = clientName,
                                        clientPhone = clientPhone,
                                        clientEmail = clientEmail,
                                        notes = notes
                                    )
                                    isLoading = false
                                    when (result) {
                                        is NetworkResult.Success -> {
                                            statusMessage = "Cotação gerada com sucesso! Referência: ${result.data.quoteReference}"
                                        }
                                        is NetworkResult.Error -> {
                                            errorMessage = result.message
                                        }
                                    }
                                }
                            },
                            isLoading = isLoading,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "insurance_request_quote_button"
                        )
                    }
                }
            }

            // Quotes History & Payment Section
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Cotações Recentes & Pagamentos Sandbox",
                    color = NovaTextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            items(quotes) { quote ->
                InsuranceQuoteCard(
                    quote = quote,
                    onPayInSandbox = {
                        scope.launch {
                            val payResult = paymentManager.createPaymentOperation(
                                type = PaymentType.SERVICE_PAYMENT,
                                amount = quote.quoteAmountAoa,
                                beneficiary = quote.insurer.companyName,
                                reference = quote.quoteReference,
                                description = "Prémio de Seguro ${quote.product.productName}",
                                authMethod = AuthMethod.APP
                            )
                            if (payResult is NetworkResult.Success) {
                                insuranceRepository.markQuoteAsPaid(quote.id)
                                onNavigateToAuthorize(payResult.data.id)
                            }
                        }
                    }
                )
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun InsuranceQuoteCard(
    quote: InsuranceQuote,
    onPayInSandbox: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("quote_card_${quote.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(12.dp))
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = quote.insurer.companyName,
                    color = NovaGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (quote.status.contains("PAGO")) NovaEmeraldBg else NovaSandboxBg)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = quote.status,
                        color = if (quote.status.contains("PAGO")) NovaEmeraldLight else NovaSandboxAmber,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "${quote.product.productName} • ${quote.clientName}",
                color = NovaTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = "Ref: ${quote.quoteReference} • ${quote.createdAt}",
                color = NovaTextSecondary,
                fontSize = 11.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Prémio Estimado", color = NovaTextSecondary, fontSize = 10.sp)
                    Text(
                        text = formatAoa(quote.quoteAmountAoa),
                        color = NovaGoldLight,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (!quote.status.contains("PAGO")) {
                    NovaButton(
                        text = "Pagar em Sandbox",
                        onClick = onPayInSandbox,
                        modifier = Modifier.height(40.dp),
                        testTag = "pay_quote_${quote.id}"
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, null, tint = NovaEmerald, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Liquidado", color = NovaEmeraldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
