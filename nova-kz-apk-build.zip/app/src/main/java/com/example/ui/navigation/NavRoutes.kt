package com.example.ui.navigation

object NavRoutes {
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val FORGOT_PASSWORD = "forgot_password"
    const val OVERVIEW = "overview"
    const val BANK_ACCOUNTS = "bank_accounts"
    const val CARDS = "cards"
    const val PAY = "pay"
    const val SEND = "send"
    const val SERVICES = "services"
    const val CREDIT = "credit"
    const val SAVINGS = "savings"
    const val INSURANCE = "insurance"
    const val HISTORY = "history"
    const val NOTIFICATIONS = "notifications"
    const val PROFILE = "profile"
    const val SECURITY = "security"
    const val ASSISTANT = "assistant"
    const val AUTHORIZE = "authorize/{operationId}"
    const val RECEIPT = "receipt/{operationId}"

    fun authorizeRoute(operationId: String) = "authorize/$operationId"
    fun receiptRoute(operationId: String) = "receipt/$operationId"
}
