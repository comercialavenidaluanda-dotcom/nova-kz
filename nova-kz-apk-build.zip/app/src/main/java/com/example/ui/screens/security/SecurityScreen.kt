package com.example.ui.screens.security

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LocalDataStore
import com.example.security.SecurityManager
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaEmeraldLight
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary

@Composable
fun SecurityScreen(
    dataStore: LocalDataStore,
    securityManager: SecurityManager,
    onLockApp: () -> Unit,
    onBack: () -> Unit
) {
    var isBiometricEnabled by remember { mutableStateOf<Boolean>(dataStore.isBiometricsEnabled) }
    var selectedTimeout by remember { mutableIntStateOf(dataStore.inactivityTimeoutMinutes) }

    var currentPin by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var confirmNewPin by remember { mutableStateOf("") }
    var pinMessage by remember { mutableStateOf<String?>(null) }
    var pinError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Centro de Segurança",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SandboxDisclaimerBanner()
            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Parâmetros de Segurança da Conta",
                color = NovaTextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                text = "Configure a autenticação biométrica, tempo limite de inatividade e código de acesso da app.",
                color = NovaTextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Biometrics Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(14.dp))
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Fingerprint, null, tint = NovaGold, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Autenticação Biométrica",
                                color = NovaTextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Utilizar impressão digital ou reconhecimento facial para autorizações e login.",
                                color = NovaTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Switch(
                        checked = isBiometricEnabled,
                        onCheckedChange = {
                            isBiometricEnabled = it
                            dataStore.isBiometricEnabled = it
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NovaGold,
                            checkedTrackColor = NovaNavySurface,
                            uncheckedThumbColor = NovaTextSecondary,
                            uncheckedTrackColor = NovaNavyDark
                        ),
                        modifier = Modifier.testTag("biometric_toggle_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Inactivity Timeout Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(14.dp))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Timer, null, tint = NovaGold, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Bloqueio Automático por Inatividade",
                            color = NovaTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "A aplicação será bloqueada quando não for detetada qualquer interação durante este intervalo.",
                        color = NovaTextSecondary,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    val timeouts = listOf(1, 3, 5, 10)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        timeouts.forEach { minutes ->
                            val isSelected = selectedTimeout == minutes
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) NovaGold else NovaNavyDark)
                                    .border(1.dp, if (isSelected) NovaGold else NovaNavyCardBorder, RoundedCornerShape(8.dp))
                                    .clickable {
                                        selectedTimeout = minutes
                                        dataStore.inactivityTimeoutMinutes = minutes
                                    }
                                    .padding(horizontal = 16.dp, vertical = 8.dp)
                                    .testTag("timeout_${minutes}m")
                            ) {
                                Text(
                                    text = "$minutes min",
                                    color = if (isSelected) NovaNavyDark else NovaTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Change PIN Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(14.dp))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, null, tint = NovaGold, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Alterar PIN de Segurança da App",
                            color = NovaTextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = currentPin,
                        onValueChange = { if (it.length <= 6) currentPin = it },
                        label = { Text("PIN Atual", color = NovaTextSecondary) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NovaGold,
                            unfocusedBorderColor = NovaNavyCardBorder,
                            focusedTextColor = NovaTextPrimary,
                            unfocusedTextColor = NovaTextPrimary
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { if (it.length <= 6) newPin = it },
                        label = { Text("Novo PIN (4 a 6 dígitos)", color = NovaTextSecondary) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NovaGold,
                            unfocusedBorderColor = NovaNavyCardBorder,
                            focusedTextColor = NovaTextPrimary,
                            unfocusedTextColor = NovaTextPrimary
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = confirmNewPin,
                        onValueChange = { if (it.length <= 6) confirmNewPin = it },
                        label = { Text("Confirmar Novo PIN", color = NovaTextSecondary) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NovaGold,
                            unfocusedBorderColor = NovaNavyCardBorder,
                            focusedTextColor = NovaTextPrimary,
                            unfocusedTextColor = NovaTextPrimary
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (pinError != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = pinError!!, color = NovaDangerRed, fontSize = 12.sp)
                    }

                    if (pinMessage != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = pinMessage!!, color = NovaEmeraldLight, fontSize = 12.sp)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    NovaButton(
                        text = "Guardar Novo PIN",
                        onClick = {
                            pinError = null
                            pinMessage = null

                            if (!dataStore.verifyAppPin(currentPin)) {
                                pinError = "O PIN atual introduzido é incorreto."
                                return@NovaButton
                            }
                            if (newPin.length < 4) {
                                pinError = "O novo PIN deve ter pelo menos 4 dígitos."
                                return@NovaButton
                            }
                            if (newPin != confirmNewPin) {
                                pinError = "A confirmação não coincide com o novo PIN."
                                return@NovaButton
                            }

                            dataStore.setAppPin(newPin)
                            pinMessage = "PIN alterado com sucesso!"
                            currentPin = ""
                            newPin = ""
                            confirmNewPin = ""
                        },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "save_new_pin_button"
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Manual Lock Button
            NovaButton(
                text = "Bloquear Aplicação Agora",
                onClick = {
                    securityManager.lockManually()
                    onLockApp()
                },
                isSecondary = true,
                leadingIcon = Icons.Default.Lock,
                modifier = Modifier.fillMaxWidth(),
                testTag = "security_lock_now_button"
            )

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
