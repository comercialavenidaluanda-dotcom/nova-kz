package com.example.ui.screens.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.example.ai.AssistantTaskMode
import com.example.ai.ChatMessage
import com.example.ai.ChatSender
import com.example.ai.GeminiAssistantService
import com.example.ai.GroundingLocation
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.ui.theme.NovaTextTertiary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantScreen(
    onNavigateBack: () -> Unit,
    assistantService: GeminiAssistantService = remember { GeminiAssistantService() }
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var inputText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var selectedMode by remember { mutableStateOf(AssistantTaskMode.GENERAL) }
    var mapsGroundingEnabled by remember { mutableStateOf(true) }

    // Live Voice Mode Dialog State (gemini-3.8-live)
    var showLiveVoiceDialog by remember { mutableStateOf(false) }
    var isLiveVoiceListening by remember { mutableStateOf(false) }
    var liveVoicePrompt by remember { mutableStateOf("Fale agora com o assistente ao vivo...") }
    var liveVoiceReply by remember { mutableStateOf("") }

    // Audio Transcription (gemini-3.5-transcribe)
    var isTranscribing by remember { mutableStateOf(false) }

    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                sender = ChatSender.BOT,
                text = "Olá! Sou o **Assistente Oficial NOVA KZ (BankBot)**.\n\nPosso ajudá-lo com:\n• Localização de caixas Multicaixa (ATM) e balcões com **Google Maps**\n• Liquidação de Guias **RUPE** e pagamentos do Estado\n• Consulta de taxas de câmbio oficiais do **BNA** (AOA, USD, EUR)\n• Recargas e pagamentos de serviços (ENDE, EPAL, ZAP, DSTV)\n\nUtilize o microfone para transcrição por voz ou ative o modo de voz ao vivo!",
                modelUsed = "gemini-3.5-flash"
            )
        )
    }

    // Scroll to bottom when new messages arrive
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Speech Recognizer setup for microphone transcription
    val speechRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else null
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "Microfone autorizado. Pressione para falar.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Permissão de áudio necessária para transcrição por voz.", Toast.LENGTH_LONG).show()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            speechRecognizer?.destroy()
        }
    }

    fun startSpeechTranscription() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPermission) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }

        if (speechRecognizer == null) {
            Toast.makeText(context, "Reconhecimento de fala não disponível no dispositivo.", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-AO")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale a sua pergunta para o NOVA KZ...")
        }

        isTranscribing = true
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                isTranscribing = false
            }
            override fun onError(error: Int) {
                isTranscribing = false
            }
            override fun onResults(results: Bundle?) {
                isTranscribing = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val recognizedText = matches?.firstOrNull() ?: ""
                if (recognizedText.isNotBlank()) {
                    inputText = recognizedText
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        speechRecognizer.startListening(intent)
    }

    fun sendMessage(textToSend: String) {
        if (textToSend.isBlank() || isLoading) return
        val userText = textToSend.trim()
        inputText = ""

        messages.add(
            ChatMessage(
                sender = ChatSender.USER,
                text = userText
            )
        )

        isLoading = true
        scope.launch {
            val result = assistantService.sendMessage(
                history = messages,
                newMessage = userText,
                mode = selectedMode,
                enableMapsGrounding = mapsGroundingEnabled
            )

            isLoading = false
            result.onSuccess { (reply, locations) ->
                messages.add(
                    ChatMessage(
                        sender = ChatSender.BOT,
                        text = reply,
                        modelUsed = selectedMode.modelId,
                        groundingLocations = locations
                    )
                )
            }.onFailure {
                messages.add(
                    ChatMessage(
                        sender = ChatSender.BOT,
                        text = "Não foi possível conectar ao assistente no momento. Por favor verifique sua ligação à internet.",
                        modelUsed = selectedMode.modelId
                    )
                )
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(NovaGold.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = NovaGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Assistente NOVA KZ",
                                color = NovaTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "BankBot IA • ${selectedMode.label}",
                                color = NovaGold,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Voltar",
                            tint = NovaTextPrimary
                        )
                    }
                },
                actions = {
                    // Live Voice button
                    IconButton(
                        onClick = {
                            showLiveVoiceDialog = true
                            isLiveVoiceListening = true
                            liveVoiceReply = ""
                        },
                        modifier = Modifier.testTag("btn_live_voice")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = "Voz ao Vivo (gemini-3.8-live)",
                            tint = NovaGold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = NovaNavyDark
                )
            )
        },
        containerColor = NovaNavyDark
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Model Selector Bar & Google Maps Grounding Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NovaNavyCard)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    item {
                        FilterChip(
                            selected = mapsGroundingEnabled,
                            onClick = { mapsGroundingEnabled = !mapsGroundingEnabled },
                            label = { Text("Google Maps", fontSize = 11.sp) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Map,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = if (mapsGroundingEnabled) NovaNavyDark else NovaGold
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NovaGold,
                                selectedLabelColor = NovaNavyDark
                            )
                        )
                    }

                    items(AssistantTaskMode.values()) { mode ->
                        FilterChip(
                            selected = selectedMode == mode,
                            onClick = { selectedMode = mode },
                            label = { Text(mode.label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NovaGold.copy(alpha = 0.25f),
                                selectedLabelColor = NovaGold
                            )
                        )
                    }
                }
            }

            // Quick Prompt Suggestions
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    SuggestionBadge("📍 Caixa Multicaixa mais próximo") {
                        sendMessage("Onde fica o caixa Multicaixa mais próximo com numerário em Luanda?")
                    }
                }
                item {
                    SuggestionBadge("📄 Como pagar Guia RUPE?") {
                        sendMessage("Como efetuar a liquidação de uma Guia RUPE no NOVA KZ?")
                    }
                }
                item {
                    SuggestionBadge("💱 Câmbio BNA hoje") {
                        sendMessage("Qual é a cotação oficial do Banco Nacional de Angola (BNA) hoje?")
                    }
                }
                item {
                    SuggestionBadge("⚡ Pagar Luz ENDE") {
                        sendMessage("Como pagar fatura de energia pré-paga da ENDE?")
                    }
                }
            }

            // Messages List (Multi-turn chat thread)
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    ChatMessageItem(message = message, onLocationClick = { loc ->
                        val gmmIntentUri = Uri.parse("geo:${loc.latitude},${loc.longitude}?q=${Uri.encode(loc.title)}")
                        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                        try {
                            context.startActivity(mapIntent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "${loc.title}: ${loc.address}", Toast.LENGTH_LONG).show()
                        }
                    })
                }

                if (isLoading) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = NovaGold,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "BankBot está a formular resposta com ${selectedMode.modelId}...",
                                color = NovaTextTertiary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Bottom Input Bar
            Surface(
                color = NovaNavyCard,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    AnimatedVisibility(visible = isTranscribing) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp)
                                .background(NovaGold.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = NovaGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "A escutar áudio (gemini-3.5-transcribe)...",
                                color = NovaGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Microphone button for speech transcription (gemini-3.5-transcribe)
                        IconButton(
                            onClick = { startSpeechTranscription() },
                            modifier = Modifier
                                .size(44.dp)
                                .background(
                                    if (isTranscribing) NovaGold else NovaNavyDark,
                                    CircleShape
                                )
                                .testTag("btn_mic_transcribe")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Transcrever Áudio",
                                tint = if (isTranscribing) NovaNavyDark else NovaGold,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = {
                                Text(
                                    text = if (isTranscribing) "A falar..." else "Pergunte sobre pagamentos, câmbio ou caixas...",
                                    color = NovaTextTertiary,
                                    fontSize = 13.sp
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("input_assistant_message"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NovaGold,
                                unfocusedBorderColor = NovaNavyDark,
                                focusedTextColor = NovaTextPrimary,
                                unfocusedTextColor = NovaTextPrimary,
                                focusedContainerColor = NovaNavyDark,
                                unfocusedContainerColor = NovaNavyDark
                            ),
                            shape = RoundedCornerShape(24.dp),
                            maxLines = 3
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = { sendMessage(inputText) },
                            enabled = inputText.isNotBlank() && !isLoading,
                            modifier = Modifier
                                .size(44.dp)
                                .background(
                                    if (inputText.isNotBlank() && !isLoading) NovaGold else NovaNavyDark,
                                    CircleShape
                                )
                                .testTag("btn_send_assistant")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Enviar Mensagem",
                                tint = if (inputText.isNotBlank() && !isLoading) NovaNavyDark else NovaTextTertiary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }

    // Live Voice Conversation Dialog (gemini-3.8-live)
    if (showLiveVoiceDialog) {
        LiveVoiceConversationDialog(
            assistantService = assistantService,
            onDismiss = { showLiveVoiceDialog = false }
        )
    }
}

@Composable
fun SuggestionBadge(text: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(NovaNavyCard, RoundedCornerShape(16.dp))
            .border(1.dp, NovaGold.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = text,
            color = NovaGold,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun ChatMessageItem(
    message: ChatMessage,
    onLocationClick: (GroundingLocation) -> Unit
) {
    val isUser = message.sender == ChatSender.USER
    val alignment = if (isUser) Alignment.End else Alignment.Start
    val bgColor = if (isUser) NovaGold.copy(alpha = 0.15f) else NovaNavyCard
    val textColor = if (isUser) NovaTextPrimary else NovaTextPrimary
    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        Box(
            modifier = Modifier
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .background(bgColor)
                .border(
                    width = 1.dp,
                    color = if (isUser) NovaGold.copy(alpha = 0.4f) else Color.Transparent,
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(14.dp)
                .widthIn(max = 320.dp)
        ) {
            Column {
                if (!isUser) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = null,
                            tint = NovaGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "NOVA KZ BankBot",
                            color = NovaGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (message.modelUsed != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "• ${message.modelUsed}",
                                color = NovaTextTertiary,
                                fontSize = 9.sp
                            )
                        }
                    }
                }

                Text(
                    text = message.text,
                    color = textColor,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )

                // Grounding Locations from Google Maps
                if (message.groundingLocations.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "📍 Pontos Multicaixa / Balcões no Google Maps:",
                        color = NovaGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    message.groundingLocations.forEach { loc ->
                        LocationCard(location = loc, onClick = { onLocationClick(loc) })
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = timeFormat.format(Date(message.timestamp)),
                    color = NovaTextTertiary,
                    fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

@Composable
fun LocationCard(
    location: GroundingLocation,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = NovaNavyDark.copy(alpha = 0.8f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        tint = NovaGold,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = location.title,
                        color = NovaTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = location.address,
                    color = NovaTextSecondary,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(NovaEmerald.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Numerário Disponível",
                            color = NovaEmerald,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${location.distance}",
                        color = NovaGold,
                        fontSize = 10.sp
                    )
                }
            }

            IconButton(onClick = onClick) {
                Icon(
                    imageVector = Icons.Default.Navigation,
                    contentDescription = "Abrir no Mapa",
                    tint = NovaGold,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun LiveVoiceConversationDialog(
    assistantService: GeminiAssistantService,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var isRecording by remember { mutableStateOf(false) }
    var isThinking by remember { mutableStateOf(false) }
    var voiceMessage by remember { mutableStateOf("Toque no microfone para falar com o assistente ao vivo (gemini-3.8-live)") }
    var assistantResponse by remember { mutableStateOf("") }

    // Sound wave pulse animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isRecording) 1.25f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = NovaNavyDark),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .border(1.dp, NovaGold.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = NovaGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Voz ao Vivo",
                            color = NovaTextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Fechar",
                            tint = NovaTextTertiary
                        )
                    }
                }

                Text(
                    text = "Modelo: gemini-3.8-live (Tempo Real)",
                    color = NovaGold,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(bottom = 20.dp)
                )

                // Interactive Audio Wave Visualizer
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .scale(pulseScale)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    NovaGold.copy(alpha = if (isRecording) 0.5f else 0.2f),
                                    Color.Transparent
                                )
                            ),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(
                        onClick = {
                            if (!isRecording) {
                                isRecording = true
                                voiceMessage = "A escutar a sua voz..."
                                assistantResponse = ""
                            } else {
                                isRecording = false
                                isThinking = true
                                voiceMessage = "Processando com gemini-3.8-live..."
                                scope.launch {
                                    val reply = assistantService.liveVoiceConversation("Consultar saldo e caixas Multicaixa próximos em Luanda")
                                    isThinking = false
                                    reply.onSuccess {
                                        assistantResponse = it
                                        voiceMessage = "Resposta do Assistente ao Vivo:"
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .size(70.dp)
                            .background(if (isRecording) NovaGold else NovaNavyCard, CircleShape)
                            .border(2.dp, NovaGold, CircleShape)
                    ) {
                        Icon(
                            imageVector = if (isRecording) Icons.Default.GraphicEq else Icons.Default.Mic,
                            contentDescription = "Falar",
                            tint = if (isRecording) NovaNavyDark else NovaGold,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = voiceMessage,
                    color = if (isRecording) NovaGold else NovaTextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )

                if (isThinking) {
                    Spacer(modifier = Modifier.height(12.dp))
                    CircularProgressIndicator(
                        color = NovaGold,
                        modifier = Modifier.size(24.dp)
                    )
                }

                if (assistantResponse.isNotBlank()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NovaNavyCard, RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Text(
                            text = assistantResponse,
                            color = NovaTextPrimary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }
    }
}
