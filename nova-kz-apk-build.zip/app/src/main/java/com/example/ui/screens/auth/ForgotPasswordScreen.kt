package com.example.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.auth.AuthManager
import com.example.network.NetworkResult
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.theme.NovaEmeraldLight
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import kotlinx.coroutines.launch

@Composable
fun ForgotPasswordScreen(
    authManager: AuthManager,
    onBackToLogin: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var identifier by remember { mutableStateOf("") }
    var successMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Recuperar Acesso",
            onBack = onBackToLogin
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SandboxDisclaimerBanner()
            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Recuperação de Credenciais",
                color = NovaTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                text = "Introduza o seu e-mail ou número de telefone registado no NOVA KZ para restabelecer o seu PIN de acesso.",
                color = NovaTextSecondary,
                fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = identifier,
                onValueChange = { identifier = it },
                label = { Text("E-mail ou Telefone (+244)", color = NovaTextSecondary) },
                leadingIcon = { Icon(Icons.Default.Mail, null, tint = NovaGold) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NovaGold,
                    unfocusedBorderColor = NovaNavyCardBorder,
                    focusedTextColor = NovaTextPrimary,
                    unfocusedTextColor = NovaTextPrimary
                ),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("recovery_identifier_input")
            )

            if (successMessage != null) {
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = successMessage!!,
                    color = NovaEmeraldLight,
                    fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            NovaButton(
                text = "Enviar Instruções de Recuperação",
                onClick = {
                    scope.launch {
                        isLoading = true
                        val result = authManager.recoverAccess(identifier)
                        isLoading = false
                        if (result is NetworkResult.Success) {
                            successMessage = result.data
                        }
                    }
                },
                isLoading = isLoading,
                modifier = Modifier.fillMaxWidth(),
                testTag = "recovery_submit_button"
            )
        }
    }
}
