package com.example.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import com.example.NovaKzApplication
import com.example.ui.components.InactivityLockOverlay
import com.example.ui.screens.accounts.BankAccountsScreen
import com.example.ui.screens.auth.ForgotPasswordScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.RegisterScreen
import com.example.ui.screens.cards.CardsScreen
import com.example.ui.screens.credit.CreditScreen
import com.example.ui.screens.history.HistoryScreen
import com.example.ui.screens.insurance.InsuranceScreen
import com.example.ui.screens.notifications.NotificationsScreen
import com.example.ui.screens.overview.OverviewScreen
import com.example.ui.screens.payments.AuthorizePaymentScreen
import com.example.ui.screens.payments.PayScreen
import com.example.ui.screens.payments.ReceiptScreen
import com.example.ui.screens.payments.SendScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.savings.SavingsScreen
import com.example.ui.screens.security.SecurityScreen
import com.example.ui.screens.services.ServicesScreen
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary

data class BottomNavItem(
    val route: String,
    val title: String,
    val icon: ImageVector
)

@Composable
fun NovaNavHost(
    navController: NavHostController,
    app: NovaKzApplication,
    onBiometricAuthRequested: (onSuccess: () -> Unit) -> Unit
) {
    val authManager = app.authManager
    val paymentManager = app.paymentManager
    val notificationRepository = app.notificationRepository
    val insuranceRepository = app.insuranceRepository
    val securityManager = app.securityManager
    val dataStore = app.dataStore

    val isLocked by securityManager.isLocked.collectAsState()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomNavItems = listOf(
        BottomNavItem(NavRoutes.OVERVIEW, "Início", Icons.Default.Home),
        BottomNavItem(NavRoutes.PAY, "Pagar", Icons.Default.Payment),
        BottomNavItem(NavRoutes.SERVICES, "Serviços", Icons.Default.Widgets),
        BottomNavItem(NavRoutes.CARDS, "Cartões", Icons.Default.CreditCard),
        BottomNavItem(NavRoutes.HISTORY, "Histórico", Icons.Default.History)
    )

    val showBottomBar = currentRoute in listOf(
        NavRoutes.OVERVIEW,
        NavRoutes.PAY,
        NavRoutes.SERVICES,
        NavRoutes.CARDS,
        NavRoutes.HISTORY
    )

    val startDestination = if (dataStore.authToken != null) NavRoutes.OVERVIEW else NavRoutes.LOGIN

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                if (showBottomBar) {
                    NavigationBar(
                        containerColor = NovaNavyDark,
                        contentColor = NovaTextPrimary
                    ) {
                        bottomNavItems.forEach { item ->
                            val isSelected = currentRoute == item.route
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = {
                                    if (currentRoute != item.route) {
                                        navController.navigate(item.route) {
                                            popUpTo(NavRoutes.OVERVIEW) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                icon = {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = item.title,
                                        tint = if (isSelected) NovaGold else NovaTextSecondary
                                    )
                                },
                                label = {
                                    Text(
                                        text = item.title,
                                        color = if (isSelected) NovaGold else NovaTextSecondary,
                                        fontSize = 11.sp
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = NovaNavyCard
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = startDestination,
                modifier = Modifier.padding(innerPadding)
            ) {
                // Auth Routes
                composable(NavRoutes.LOGIN) {
                    LoginScreen(
                        authManager = authManager,
                        onLoginSuccess = {
                            navController.navigate(NavRoutes.OVERVIEW) {
                                popUpTo(NavRoutes.LOGIN) { inclusive = true }
                            }
                        },
                        onNavigateToRegister = { navController.navigate(NavRoutes.REGISTER) },
                        onNavigateToForgotPassword = { navController.navigate(NavRoutes.FORGOT_PASSWORD) },
                        onBiometricLogin = {
                            onBiometricAuthRequested {
                                authManager.loginWithBiometrics()
                                navController.navigate(NavRoutes.OVERVIEW) {
                                    popUpTo(NavRoutes.LOGIN) { inclusive = true }
                                }
                            }
                        }
                    )
                }

                composable(NavRoutes.REGISTER) {
                    RegisterScreen(
                        authManager = authManager,
                        onRegisterSuccess = {
                            navController.navigate(NavRoutes.OVERVIEW) {
                                popUpTo(NavRoutes.LOGIN) { inclusive = true }
                            }
                        },
                        onBackToLogin = { navController.popBackStack() }
                    )
                }

                composable(NavRoutes.FORGOT_PASSWORD) {
                    ForgotPasswordScreen(
                        authManager = authManager,
                        onBackToLogin = { navController.popBackStack() }
                    )
                }

                // Core Dashboard & Hub
                composable(NavRoutes.OVERVIEW) {
                    OverviewScreen(
                        authManager = authManager,
                        paymentManager = paymentManager,
                        notificationRepository = notificationRepository,
                        onNavigateToPay = { navController.navigate(NavRoutes.PAY) },
                        onNavigateToSend = { navController.navigate(NavRoutes.SEND) },
                        onNavigateToServices = { navController.navigate(NavRoutes.SERVICES) },
                        onNavigateToAccounts = { navController.navigate(NavRoutes.BANK_ACCOUNTS) },
                        onNavigateToCards = { navController.navigate(NavRoutes.CARDS) },
                        onNavigateToCredit = { navController.navigate(NavRoutes.CREDIT) },
                        onNavigateToSavings = { navController.navigate(NavRoutes.SAVINGS) },
                        onNavigateToInsurance = { navController.navigate(NavRoutes.INSURANCE) },
                        onNavigateToHistory = { navController.navigate(NavRoutes.HISTORY) },
                        onNavigateToNotifications = { navController.navigate(NavRoutes.NOTIFICATIONS) },
                        onNavigateToProfile = { navController.navigate(NavRoutes.PROFILE) },
                        onNavigateToSecurity = { navController.navigate(NavRoutes.SECURITY) },
                        onNavigateToAuthorize = { opId -> navController.navigate(NavRoutes.authorizeRoute(opId)) },
                        onNavigateToReceipt = { opId -> navController.navigate(NavRoutes.receiptRoute(opId)) },
                        onNavigateToAssistant = { navController.navigate(NavRoutes.ASSISTANT) }
                    )
                }

                composable(NavRoutes.BANK_ACCOUNTS) {
                    BankAccountsScreen(
                        paymentManager = paymentManager,
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(NavRoutes.CARDS) {
                    CardsScreen(
                        paymentManager = paymentManager,
                        onBack = { navController.popBackStack() }
                    )
                }

                // Financial Operations
                composable(NavRoutes.PAY) {
                    PayScreen(
                        paymentManager = paymentManager,
                        onNavigateToAuthorize = { opId -> navController.navigate(NavRoutes.authorizeRoute(opId)) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(NavRoutes.SEND) {
                    SendScreen(
                        paymentManager = paymentManager,
                        onNavigateToAuthorize = { opId -> navController.navigate(NavRoutes.authorizeRoute(opId)) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    route = NavRoutes.AUTHORIZE,
                    arguments = listOf(navArgument("operationId") { type = NavType.StringType }),
                    deepLinks = listOf(navDeepLink { uriPattern = "novakz://operation?id={operationId}" })
                ) { backStackEntry ->
                    val operationId = backStackEntry.arguments?.getString("operationId") ?: ""
                    AuthorizePaymentScreen(
                        operationId = operationId,
                        paymentManager = paymentManager,
                        onBiometricAuthRequested = onBiometricAuthRequested,
                        onPaymentConfirmed = { opId ->
                            navController.navigate(NavRoutes.receiptRoute(opId)) {
                                popUpTo(NavRoutes.AUTHORIZE) { inclusive = true }
                            }
                        },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    route = NavRoutes.RECEIPT,
                    arguments = listOf(navArgument("operationId") { type = NavType.StringType }),
                    deepLinks = listOf(navDeepLink { uriPattern = "novakz://receipt?id={operationId}" })
                ) { backStackEntry ->
                    val operationId = backStackEntry.arguments?.getString("operationId") ?: ""
                    ReceiptScreen(
                        operationId = operationId,
                        paymentManager = paymentManager,
                        onNavigateToHome = {
                            navController.navigate(NavRoutes.OVERVIEW) {
                                popUpTo(NavRoutes.OVERVIEW) { inclusive = true }
                            }
                        },
                        onBack = { navController.popBackStack() }
                    )
                }

                // Services & Insurance
                composable(NavRoutes.SERVICES) {
                    ServicesScreen(
                        paymentManager = paymentManager,
                        onNavigateToAuthorize = { opId -> navController.navigate(NavRoutes.authorizeRoute(opId)) },
                        onNavigateToInsurance = { navController.navigate(NavRoutes.INSURANCE) },
                        onBack = { navController.popBackStack() },
                        onNavigateToAssistant = { navController.navigate(NavRoutes.ASSISTANT) }
                    )
                }

                composable(NavRoutes.INSURANCE) {
                    InsuranceScreen(
                        insuranceRepository = insuranceRepository,
                        paymentManager = paymentManager,
                        onNavigateToAuthorize = { opId -> navController.navigate(NavRoutes.authorizeRoute(opId)) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(NavRoutes.CREDIT) {
                    CreditScreen(onBack = { navController.popBackStack() })
                }

                composable(NavRoutes.SAVINGS) {
                    SavingsScreen(onBack = { navController.popBackStack() })
                }

                composable(NavRoutes.HISTORY) {
                    HistoryScreen(
                        paymentManager = paymentManager,
                        onNavigateToReceipt = { opId -> navController.navigate(NavRoutes.receiptRoute(opId)) },
                        onNavigateToAuthorize = { opId -> navController.navigate(NavRoutes.authorizeRoute(opId)) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(
                    route = NavRoutes.NOTIFICATIONS,
                    deepLinks = listOf(navDeepLink { uriPattern = "novakz://notifications" })
                ) {
                    NotificationsScreen(
                        notificationRepository = notificationRepository,
                        onNavigateToOperation = { opId ->
                            navController.navigate(NavRoutes.receiptRoute(opId))
                        },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(NavRoutes.PROFILE) {
                    ProfileScreen(
                        authManager = authManager,
                        onLogout = {
                            navController.navigate(NavRoutes.LOGIN) {
                                popUpTo(0) { inclusive = true }
                            }
                        },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(NavRoutes.SECURITY) {
                    SecurityScreen(
                        dataStore = dataStore,
                        securityManager = securityManager,
                        onLockApp = { /* Trigger lock */ },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable(NavRoutes.ASSISTANT) {
                    com.example.ui.screens.assistant.AssistantScreen(
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }
        }

        // Automatic Inactivity Lock Screen
        AnimatedVisibility(visible = isLocked) {
            InactivityLockOverlay(
                onUnlockWithPin = { pin -> securityManager.unlockWithPin(pin) },
                onUnlockWithBiometrics = {
                    onBiometricAuthRequested {
                        securityManager.unlockWithBiometrics()
                    }
                },
                onLogout = {
                    authManager.logout()
                    securityManager.resetLock()
                    navController.navigate(NavRoutes.LOGIN) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }
    }
}
