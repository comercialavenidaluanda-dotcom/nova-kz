package com.example.ui.screens.savings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.components.formatAoa
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaEmeraldBg
import com.example.ui.theme.NovaEmeraldLight
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaGoldLight
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary

@Composable
fun SavingsScreen(onBack: () -> Unit) {
    var savedAmount by remember { mutableStateOf(150000.0) }
    var targetAmount by remember { mutableStateOf(500000.0) }
    val progress = (savedAmount / targetAmount).toFloat().coerceIn(0f, 1f)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Cofres & Poupança",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SandboxDisclaimerBanner()
            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Cofres Digitais NOVA KZ",
                color = NovaTextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                text = "Separe dinheiro para os seus objetivos com remuneração programada em Kwanza (Sandbox).",
                color = NovaTextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Main Vault Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("savings_vault_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(16.dp))
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Cofre Fundo de Emergência",
                            color = NovaGold,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(NovaEmeraldBg)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "+8.5% ao ano",
                                color = NovaEmeraldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "Saldo no Cofre", color = NovaTextSecondary, fontSize = 11.sp)
                    Text(
                        text = formatAoa(savedAmount),
                        color = NovaGoldLight,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Meta: ${formatAoa(targetAmount)}", color = NovaTextSecondary, fontSize = 12.sp)
                        Text(text = "${(progress * 100).toInt()}% atingido", color = NovaEmeraldLight, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = NovaEmerald,
                        trackColor = NovaNavyDark,
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    NovaButton(
                        text = "Reforçar Poupança (+10.000 AOA)",
                        onClick = { savedAmount += 10000.0 },
                        modifier = Modifier.fillMaxWidth(),
                        testTag = "savings_deposit_button"
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
