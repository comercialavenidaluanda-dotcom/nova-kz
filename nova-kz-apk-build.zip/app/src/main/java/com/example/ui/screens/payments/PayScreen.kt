package com.example.ui.screens.payments

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.AuthMethod
import com.example.domain.models.PaymentType
import com.example.network.NetworkResult
import com.example.payments.PaymentManager
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import kotlinx.coroutines.launch

@Composable
fun PayScreen(
    paymentManager: PaymentManager,
    onNavigateToAuthorize: (String) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var entity by remember { mutableStateOf("00201 (ENDE Pré-pago)") }
    var reference by remember { mutableStateOf("1002938491") }
    var amountText by remember { mutableStateOf("150") }
    var description by remember { mutableStateOf("Recarga de energia pré-pago") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Efetuar Pagamento",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SandboxDisclaimerBanner()
            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Pagamento por Entidade & Referência",
                color = NovaTextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                text = "Suporte para pagamentos de serviços, RUPE e utilidades em Angola via NOVA KZ.",
                color = NovaTextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedTextField(
                value = entity,
                onValueChange = { entity = it },
                label = { Text("Entidade", color = NovaTextSecondary) },
                leadingIcon = { Icon(Icons.Default.Widgets, null, tint = NovaGold) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NovaGold,
                    unfocusedBorderColor = NovaNavyCardBorder,
                    focusedTextColor = NovaTextPrimary,
                    unfocusedTextColor = NovaTextPrimary
                ),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pay_entity_input")
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = reference,
                onValueChange = { reference = it },
                label = { Text("Referência de Pagamento (9 dígitos)", color = NovaTextSecondary) },
                leadingIcon = { Icon(Icons.Default.Numbers, null, tint = NovaGold) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NovaGold,
                    unfocusedBorderColor = NovaNavyCardBorder,
                    focusedTextColor = NovaTextPrimary,
                    unfocusedTextColor = NovaTextPrimary
                ),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pay_reference_input")
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it },
                label = { Text("Valor a Pagar (AOA)", color = NovaTextSecondary) },
                leadingIcon = { Icon(Icons.Default.Payment, null, tint = NovaGold) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NovaGold,
                    unfocusedBorderColor = NovaNavyCardBorder,
                    focusedTextColor = NovaTextPrimary,
                    unfocusedTextColor = NovaTextPrimary
                ),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pay_amount_input")
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Descrição (opcional)", color = NovaTextSecondary) },
                leadingIcon = { Icon(Icons.Default.Receipt, null, tint = NovaGold) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NovaGold,
                    unfocusedBorderColor = NovaNavyCardBorder,
                    focusedTextColor = NovaTextPrimary,
                    unfocusedTextColor = NovaTextPrimary
                ),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pay_description_input")
            )

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = errorMessage!!,
                    color = NovaDangerRed,
                    fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            NovaButton(
                text = "Validar e Prosseguir",
                onClick = {
                    val amount = amountText.toDoubleOrNull()
                    if (amount == null || amount <= 0) {
                        errorMessage = "Introduza um valor válido superior a zero."
                        return@NovaButton
                    }
                    scope.launch {
                        isLoading = true
                        errorMessage = null
                        val result = paymentManager.createPaymentOperation(
                            type = PaymentType.SERVICE_PAYMENT,
                            amount = amount,
                            beneficiary = entity,
                            reference = reference,
                            description = description,
                            authMethod = AuthMethod.APP
                        )
                        isLoading = false
                        when (result) {
                            is NetworkResult.Success -> onNavigateToAuthorize(result.data.id)
                            is NetworkResult.Error -> errorMessage = result.message
                        }
                    }
                },
                isLoading = isLoading,
                modifier = Modifier.fillMaxWidth(),
                testTag = "pay_submit_button"
            )
        }
    }
}
