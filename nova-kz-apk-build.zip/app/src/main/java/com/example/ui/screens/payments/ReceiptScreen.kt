package com.example.ui.screens.payments

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.PaymentOperation
import com.example.payments.PaymentManager
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxBadge
import com.example.ui.components.StatusChip
import com.example.ui.components.formatAoa
import com.example.ui.theme.NovaBorder
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaEmeraldBg
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaGoldLight
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary

@Composable
fun ReceiptScreen(
    operationId: String,
    paymentManager: PaymentManager,
    onNavigateToHome: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val operations by paymentManager.operations.collectAsState()
    val operation = operations.find { it.id == operationId } ?: paymentManager.getOperationById(operationId)

    androidx.compose.runtime.LaunchedEffect(operationId) {
        if (operation == null) {
            paymentManager.loadMyPaymentOperations()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Comprovativo Oficial",
            onBack = onBack
        )

        if (operation == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = "Comprovativo não encontrado.", color = NovaTextPrimary)
                Spacer(modifier = Modifier.height(16.dp))
                NovaButton(text = "Voltar", onClick = onBack)
            }
            return@Column
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Receipt Canvas Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("receipt_canvas_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(20.dp))
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(NovaEmeraldBg.copy(alpha = 0.8f))
                            .border(1.dp, NovaEmerald.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Sucesso",
                            tint = NovaEmerald,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "NOVA KZ",
                        color = NovaGold,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.5.sp
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "COMPROVATIVO DE OPERAÇÃO",
                        color = NovaTextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    SandboxBadge(compact = true)

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = formatAoa(operation.amount),
                        color = NovaGoldLight,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(NovaNavyCardBorder.copy(alpha = 0.7f))
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Key receipt details
                    ReceiptRow("Tipo de Operação", operation.type.label)
                    ReceiptRow("Beneficiário / Entidade", operation.beneficiary)
                    if (!operation.reference.isNullOrBlank()) {
                        ReceiptRow("Referência", operation.reference)
                    }
                    if (!operation.beneficiaryAccount.isNullOrBlank()) {
                        ReceiptRow("Conta / IBAN Destino", operation.beneficiaryAccount)
                    }
                    ReceiptRow("Moeda", operation.currency)
                    ReceiptRow("Estado da Operação", operation.status.label)
                    ReceiptRow("Ambiente", operation.environment)
                    ReceiptRow("Data e Hora", operation.completedAt ?: operation.createdAt)
                    ReceiptRow("ID da Transação", operation.transactionId)
                    ReceiptRow("ID de Idempotência", operation.idempotencyKey.take(16) + "...")
                    ReceiptRow("Método de Validação", operation.authMethod.label)

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(NovaNavyCardBorder)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Documento emitido eletronicamente pela plataforma financeira NOVA KZ. Válido para efeitos de confirmação em ambiente Sandbox.",
                        color = NovaTextSecondary,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action: Partilhar comprovativo
            NovaButton(
                text = "Partilhar Comprovativo",
                leadingIcon = Icons.Default.Share,
                onClick = {
                    val shareText = """
                        *NOVA KZ - Comprovativo de Operação*
                        ------------------------------------
                        Operação: ${operation.type.label}
                        Beneficiário: ${operation.beneficiary}
                        Valor: ${formatAoa(operation.amount)}
                        Referência: ${operation.reference ?: "N/A"}
                        Data: ${operation.completedAt ?: operation.createdAt}
                        Estado: ${operation.status.label}
                        Ambiente: ${operation.environment}
                        ID Transação: ${operation.transactionId}
                        ------------------------------------
                        Emitido via NOVA KZ Android Nativo
                    """.trimIndent()

                    val sendIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        putExtra(Intent.EXTRA_TEXT, shareText)
                        type = "text/plain"
                    }
                    context.startActivity(Intent.createChooser(sendIntent, "Partilhar comprovativo NOVA KZ"))
                },
                modifier = Modifier.fillMaxWidth(),
                testTag = "receipt_share_button"
            )

            Spacer(modifier = Modifier.height(12.dp))

            NovaButton(
                text = "Concluir e Voltar ao Início",
                isSecondary = true,
                leadingIcon = Icons.Default.Home,
                onClick = onNavigateToHome,
                modifier = Modifier.fillMaxWidth(),
                testTag = "receipt_home_button"
            )

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun ReceiptRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = NovaTextSecondary, fontSize = 11.sp)
        Text(
            text = value,
            color = NovaTextPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.End,
            modifier = Modifier.widthIn(max = 200.dp)
        )
    }
}
