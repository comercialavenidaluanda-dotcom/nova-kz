package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NOVA KZ Brand Palette
val NovaNavyDark = Color(0xFF071324)
val NovaNavySurface = Color(0xFF0D1F38)
val NovaNavyCard = Color(0xFF13294B)
val NovaNavyCardBorder = Color(0xFF1E3A66)
val NovaNavyHeroStart = Color(0xFF12284C)
val NovaNavyHeroEnd = Color(0xFF08152B)

val NovaGold = Color(0xFFE5B842)
val NovaGoldLight = Color(0xFFF7D57F)
val NovaGoldDark = Color(0xFFB88E28)
val NovaGoldMetallic = Color(0xFFE2B755)

val NovaEmerald = Color(0xFF10B981)
val NovaEmeraldLight = Color(0xFF34D399)
val NovaEmeraldBg = Color(0xFF064E3B)

val NovaSandboxAmber = Color(0xFFF59E0B)
val NovaSandboxBg = Color(0xFF78350F)

val NovaDangerRed = Color(0xFFEF4444)
val NovaDangerBg = Color(0xFF7F1D1D)

val NovaInfoBlue = Color(0xFF3B82F6)
val NovaInfoBg = Color(0xFF1E3A8A)

val NovaTextPrimary = Color(0xFFF8FAFC)
val NovaTextSecondary = Color(0xFF94A3B8)
val NovaTextTertiary = Color(0xFF64748B)

val NovaBorder = Color(0xFF1E293B)
