package com.example.ui.screens.history

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.PaymentOperation
import com.example.domain.models.PaymentStatus
import com.example.domain.models.PaymentType
import com.example.payments.PaymentManager
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.components.StatusChip
import com.example.ui.components.formatAoa
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary

@Composable
fun HistoryScreen(
    paymentManager: PaymentManager,
    onNavigateToReceipt: (String) -> Unit,
    onNavigateToAuthorize: (String) -> Unit,
    onBack: () -> Unit
) {
    val operations by paymentManager.operations.collectAsState()
    var selectedFilter by remember { mutableStateOf("TODOS") }

    val filteredList = when (selectedFilter) {
        "CONFIRMADOS" -> operations.filter { it.status == PaymentStatus.CONFIRMED }
        "PENDENTES" -> operations.filter { it.status == PaymentStatus.PENDING_AUTHORIZATION || it.status == PaymentStatus.PROCESSING || it.status == PaymentStatus.VALIDATED }
        "FALHADOS" -> operations.filter { it.status == PaymentStatus.FAILED || it.status == PaymentStatus.CANCELLED }
        else -> operations
    }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        paymentManager.loadMyPaymentOperations()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Histórico de Transações",
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SandboxDisclaimerBanner()
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Registo de Operações Financeiras",
                    color = NovaTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Consulte e partilhe comprovativos de pagamentos e transferências realizadas.",
                    color = NovaTextSecondary,
                    fontSize = 12.sp
                )
            }

            // Filters
            item {
                val filters = listOf("TODOS", "CONFIRMADOS", "PENDENTES", "FALHADOS")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filters) { filter ->
                        val isSelected = filter == selectedFilter
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) NovaGold else NovaNavyCard)
                                .border(1.dp, if (isSelected) NovaGold else NovaNavyCardBorder, RoundedCornerShape(20.dp))
                                .clickable { selectedFilter = filter }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                                .testTag("filter_$filter")
                        ) {
                            Text(
                                text = filter,
                                color = if (isSelected) NovaNavyDark else NovaTextPrimary,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            if (filteredList.isEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(30.dp))
                    Text(
                        text = "Nenhuma operação encontrada neste filtro.",
                        color = NovaTextSecondary,
                        fontSize = 14.sp
                    )
                }
            }

            items(filteredList) { op ->
                HistoryOperationCard(
                    op = op,
                    onClick = {
                        if (op.status == PaymentStatus.PENDING_AUTHORIZATION) {
                            onNavigateToAuthorize(op.id)
                        } else {
                            onNavigateToReceipt(op.id)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun HistoryOperationCard(op: PaymentOperation, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("history_item_${op.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(12.dp))
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(NovaNavyDark),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (op.type) {
                        PaymentType.TRANSFER -> Icons.AutoMirrored.Filled.Send
                        PaymentType.SERVICE_PAYMENT -> Icons.Default.Widgets
                        else -> Icons.Default.Payment
                    },
                    contentDescription = null,
                    tint = NovaGold,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = op.beneficiary,
                    color = NovaTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${op.type.label} • ${op.createdAt}",
                    color = NovaTextSecondary,
                    fontSize = 11.sp
                )
                if (!op.reference.isNullOrBlank()) {
                    Text(
                        text = "Ref: ${op.reference}",
                        color = NovaTextSecondary,
                        fontSize = 10.sp
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = formatAoa(op.amount),
                    color = NovaTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                StatusChip(status = op.status)
            }
        }
    }
}
