package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.PaymentStatus
import com.example.ui.theme.NovaBorder
import com.example.ui.theme.NovaDangerBg
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaEmeraldBg
import com.example.ui.theme.NovaEmeraldLight
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaGoldDark
import com.example.ui.theme.NovaInfoBg
import com.example.ui.theme.NovaInfoBlue
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaSandboxAmber
import com.example.ui.theme.NovaSandboxBg
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import com.example.ui.theme.NovaTextTertiary
import java.util.Locale

@Composable
fun SandboxBadge(
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(NovaSandboxAmber.copy(alpha = 0.12f))
            .border(1.dp, NovaSandboxAmber.copy(alpha = 0.45f), RoundedCornerShape(20.dp))
            .padding(horizontal = if (compact) 7.dp else 10.dp, vertical = if (compact) 3.dp else 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(if (compact) 5.dp else 6.dp)
                .clip(CircleShape)
                .background(NovaSandboxAmber)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = "SANDBOX",
            color = NovaSandboxAmber,
            fontSize = if (compact) 9.5.sp else 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp
        )
    }
}

@Composable
fun SandboxDisclaimerBanner(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(NovaSandboxAmber.copy(alpha = 0.08f))
            .border(1.dp, NovaSandboxAmber.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Shield,
            contentDescription = "Sandbox",
            tint = NovaSandboxAmber,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = "Ambiente de Testes Sandbox • Nenhuma operação movimenta dinheiro real.",
            color = NovaSandboxAmber.copy(alpha = 0.95f),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            lineHeight = 15.sp
        )
    }
}

@Composable
fun StatusChip(status: PaymentStatus, modifier: Modifier = Modifier) {
    val (bgColor, textColor, borderColor) = when (status) {
        PaymentStatus.CONFIRMED -> Triple(NovaEmeraldBg, NovaEmeraldLight, NovaEmerald)
        PaymentStatus.FAILED, PaymentStatus.CANCELLED, PaymentStatus.REJECTED -> Triple(NovaDangerBg, NovaDangerRed, NovaDangerRed)
        PaymentStatus.PENDING_AUTHORIZATION -> Triple(NovaSandboxBg, NovaSandboxAmber, NovaSandboxAmber)
        PaymentStatus.AUTHORIZED -> Triple(NovaInfoBg, NovaInfoBlue, NovaInfoBlue)
        PaymentStatus.PROCESSING -> Triple(NovaNavyCard, NovaGold, NovaGold)
        PaymentStatus.VALIDATED, PaymentStatus.DRAFT -> Triple(NovaNavySurface, NovaTextSecondary, NovaNavyCardBorder)
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor.copy(alpha = 0.7f))
            .border(1.dp, borderColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = status.label,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun NovaButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    isSecondary: Boolean = false,
    isDanger: Boolean = false,
    leadingIcon: ImageVector? = null,
    testTag: String = "nova_button"
) {
    var lastClickTime by remember { mutableStateOf(0L) }

    val containerColor = when {
        isDanger -> NovaDangerRed
        isSecondary -> NovaNavyCard
        else -> NovaGold
    }

    val contentColor = when {
        isDanger -> Color.White
        isSecondary -> NovaGold
        else -> NovaNavyDark
    }

    Button(
        onClick = {
            val now = System.currentTimeMillis()
            if (now - lastClickTime > 600L && !isLoading) {
                lastClickTime = now
                onClick()
            }
        },
        enabled = enabled && !isLoading,
        modifier = modifier
            .height(52.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = NovaNavyCardBorder.copy(alpha = 0.5f),
            disabledContentColor = NovaTextTertiary
        ),
        border = if (isSecondary) androidx.compose.foundation.BorderStroke(1.dp, NovaNavyCardBorder) else null
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color = contentColor,
                strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("Processando...", fontSize = 14.sp, fontWeight = FontWeight.Bold)
        } else {
            leadingIcon?.let {
                Icon(imageVector = it, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(text = text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun NovaTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    onNotificationsClick: (() -> Unit)? = null,
    unreadNotificationsCount: Int = 0,
    showSandboxBadge: Boolean = true
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NovaNavyDark)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onBack != null) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("top_bar_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Voltar",
                            tint = NovaTextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                }
                Text(
                    text = title,
                    color = NovaTextPrimary,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.3.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (showSandboxBadge) {
                    SandboxBadge(compact = true)
                    Spacer(modifier = Modifier.width(10.dp))
                }
                if (onNotificationsClick != null) {
                    Box {
                        IconButton(
                            onClick = onNotificationsClick,
                            modifier = Modifier.testTag("top_bar_notifications_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Notificações",
                                tint = NovaGold
                            )
                        }
                        if (unreadNotificationsCount > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 6.dp, end = 6.dp)
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(NovaDangerRed),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = unreadNotificationsCount.toString(),
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(NovaNavyCardBorder.copy(alpha = 0.5f))
        )
    }
}

@Composable
fun InactivityLockOverlay(
    onUnlockWithPin: (String) -> Boolean,
    onUnlockWithBiometrics: () -> Unit,
    onLogout: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = NovaNavyDark.copy(alpha = 0.98f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(NovaNavyCard)
                    .border(2.dp, NovaGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Bloqueado",
                    tint = NovaGold,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text(
                text = "Aplicação Bloqueada",
                color = NovaTextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Bloqueio automático por inatividade para sua segurança financeira.",
                color = NovaTextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = pin,
                onValueChange = {
                    if (it.length <= 6) {
                        pin = it
                        errorMessage = null
                    }
                },
                label = { Text("Introduza o PIN da aplicação", color = NovaTextSecondary) },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.NumberPassword,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = {
                    if (onUnlockWithPin(pin)) {
                        pin = ""
                    } else {
                        errorMessage = "PIN incorreto. Tente novamente."
                    }
                }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NovaGold,
                    unfocusedBorderColor = NovaNavyCardBorder,
                    focusedTextColor = NovaTextPrimary,
                    unfocusedTextColor = NovaTextPrimary
                ),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("inactivity_pin_input")
            )

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMessage!!,
                    color = NovaDangerRed,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            NovaButton(
                text = "Desbloquear com PIN",
                onClick = {
                    if (onUnlockWithPin(pin)) {
                        pin = ""
                    } else {
                        errorMessage = "PIN incorreto."
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                testTag = "inactivity_unlock_button"
            )

            Spacer(modifier = Modifier.height(12.dp))

            NovaButton(
                text = "Desbloquear com Biometria",
                onClick = onUnlockWithBiometrics,
                isSecondary = true,
                leadingIcon = Icons.Default.Fingerprint,
                modifier = Modifier.fillMaxWidth(),
                testTag = "inactivity_biometric_button"
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Terminar Sessão",
                color = NovaDangerRed,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clickable { onLogout() }
                    .padding(8.dp)
                    .testTag("inactivity_logout_link")
            )
        }
    }
}

fun formatAoa(amount: Double): String {
    return String.format(Locale("pt", "AO"), "%,.2f AOA", amount)
}
