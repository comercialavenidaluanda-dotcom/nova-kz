package com.example.ui.screens.overview

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.auth.AuthManager
import com.example.domain.models.BankAccount
import com.example.domain.models.CardItem
import com.example.domain.models.PaymentOperation
import com.example.notifications.NotificationRepository
import com.example.payments.PaymentManager
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxBadge
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.components.StatusChip
import com.example.ui.components.formatAoa
import com.example.ui.theme.NovaBorder
import com.example.ui.theme.NovaDangerBg
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaEmeraldLight
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaGoldLight
import com.example.ui.theme.NovaInfoBlue
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaSandboxAmber
import com.example.ui.theme.NovaSandboxBg
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import kotlinx.coroutines.launch

@Composable
fun OverviewScreen(
    authManager: AuthManager,
    paymentManager: PaymentManager,
    notificationRepository: NotificationRepository,
    onNavigateToPay: () -> Unit,
    onNavigateToSend: () -> Unit,
    onNavigateToServices: () -> Unit,
    onNavigateToAccounts: () -> Unit,
    onNavigateToCards: () -> Unit,
    onNavigateToCredit: () -> Unit,
    onNavigateToSavings: () -> Unit,
    onNavigateToInsurance: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToNotifications: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onNavigateToSecurity: () -> Unit,
    onNavigateToAuthorize: (String) -> Unit,
    onNavigateToReceipt: (String) -> Unit,
    onNavigateToAssistant: () -> Unit = {}
) {
    val scope = rememberCoroutineScope()
    val user by authManager.currentUser.collectAsState()
    val sandboxBalance by paymentManager.sandboxBalance.collectAsState()
    val accounts by paymentManager.bankAccounts.collectAsState()
    val cards by paymentManager.cards.collectAsState()
    val operations by paymentManager.operations.collectAsState()
    val pendingAuth by paymentManager.pendingAuthorizations.collectAsState()
    val notifications by notificationRepository.notifications.collectAsState()
    val unreadCount = notifications.count { !it.isRead }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        paymentManager.fetchSandboxBalance()
        paymentManager.loadMyPaymentOperations()
        paymentManager.loadBankAccounts()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "NOVA KZ",
            onNotificationsClick = onNavigateToNotifications,
            unreadNotificationsCount = unreadCount,
            showSandboxBadge = true
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(10.dp))
            SandboxDisclaimerBanner()
            Spacer(modifier = Modifier.height(16.dp))

            // Greeting & User
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Olá, ${user?.name ?: "Utilizador"}",
                        color = NovaTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Conta Sandbox Ativa",
                        color = NovaTextSecondary,
                        fontSize = 12.sp
                    )
                }

                Row {
                    IconButton(
                        onClick = { onNavigateToAssistant() },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(NovaGold.copy(alpha = 0.2f))
                            .border(1.dp, NovaGold.copy(alpha = 0.5f), CircleShape)
                            .testTag("overview_assistant_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "Assistente BankBot", tint = NovaGold)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = { onNavigateToProfile() },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(NovaNavyCard)
                            .testTag("overview_profile_button")
                    ) {
                        Icon(Icons.Default.Person, contentDescription = "Perfil", tint = NovaGold)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = { onNavigateToSecurity() },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(NovaNavyCard)
                            .testTag("overview_security_button")
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = "Segurança", tint = NovaTextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // BankBot Gemini AI Banner Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToAssistant() }
                    .testTag("overview_assistant_banner"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NovaGold.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(NovaGold.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = NovaGold,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Assistente NOVA KZ • Gemini AI",
                                color = NovaTextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Caixas Multicaixa (Google Maps), Câmbio BNA & Conversa por Voz",
                            color = NovaTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Abrir",
                        tint = NovaGold,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Hero Balance Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("overview_balance_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            brush = Brush.linearGradient(
                                colors = listOf(Color(0xFF142D55), Color(0xFF0A182E))
                            )
                        )
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(20.dp))
                        .padding(22.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "SALDO DISPONÍVEL",
                                color = NovaTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp
                            )
                            SandboxBadge(compact = true)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = formatAoa(sandboxBalance),
                            color = NovaGoldLight,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Conta Principal • AOA (Kwanza Angolano)",
                            color = NovaTextSecondary.copy(alpha = 0.85f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        // Primary Shortcuts: Pagar, Enviar, Serviços
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ShortcutButton(
                                label = "Pagar",
                                icon = Icons.Default.Payment,
                                onClick = onNavigateToPay,
                                tag = "shortcut_pay",
                                modifier = Modifier.weight(1f)
                            )
                            ShortcutButton(
                                label = "Enviar",
                                icon = Icons.AutoMirrored.Filled.Send,
                                onClick = onNavigateToSend,
                                tag = "shortcut_send",
                                modifier = Modifier.weight(1f)
                            )
                            ShortcutButton(
                                label = "Serviços",
                                icon = Icons.Default.Widgets,
                                onClick = onNavigateToServices,
                                tag = "shortcut_services",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Pending Authorizations Alert
            if (pendingAuth.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToAuthorize(pendingAuth.first().id) }
                        .testTag("overview_pending_auth_banner"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = NovaSandboxBg.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, NovaSandboxAmber.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = NovaSandboxAmber,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${pendingAuth.size} Autorização Pendente",
                                color = NovaSandboxAmber,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${pendingAuth.first().beneficiary} • ${formatAoa(pendingAuth.first().amount)}",
                                color = NovaTextPrimary,
                                fontSize = 12.sp
                            )
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Autorizar",
                            tint = NovaSandboxAmber,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Secondary Hub (Contas, Cartões, Poupança, Crédito, Seguros, Histórico)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Acesso Rápido",
                    color = NovaTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                HubIconItem("Contas", Icons.Default.AccountBalance, onNavigateToAccounts, "hub_accounts")
                HubIconItem("Cartões", Icons.Default.CreditCard, onNavigateToCards, "hub_cards")
                HubIconItem("Seguros", Icons.Default.HealthAndSafety, onNavigateToInsurance, "hub_insurance")
                HubIconItem("Crédito", Icons.Default.Payment, onNavigateToCredit, "hub_credit")
                HubIconItem("Poupança", Icons.Default.Savings, onNavigateToSavings, "hub_savings")
                HubIconItem("Histórico", Icons.Default.History, onNavigateToHistory, "hub_history")
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Cartões Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Meus Cartões",
                    color = NovaTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Ver todos",
                    color = NovaGold,
                    fontSize = 13.sp,
                    modifier = Modifier.clickable { onNavigateToCards() }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(cards) { card ->
                    OverviewCardItem(card = card, onClick = onNavigateToCards)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Operações Recentes Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Operações Recentes",
                    color = NovaTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Histórico completo",
                    color = NovaGold,
                    fontSize = 13.sp,
                    modifier = Modifier.clickable { onNavigateToHistory() }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            operations.take(4).forEach { op ->
                OverviewOperationRow(
                    op = op,
                    onClick = {
                        if (op.status == com.example.domain.models.PaymentStatus.PENDING_AUTHORIZATION) {
                            onNavigateToAuthorize(op.id)
                        } else {
                            onNavigateToReceipt(op.id)
                        }
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun ShortcutButton(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    tag: String,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(NovaNavyCard)
            .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp)
            .testTag(tag)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(NovaGold.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = NovaGold,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = label, color = NovaTextPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun HubIconItem(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit,
    tag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(4.dp)
            .testTag(tag)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(NovaNavyCard)
                .border(1.dp, NovaNavyCardBorder, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = NovaGold, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = title, color = NovaTextSecondary, fontSize = 11.sp)
    }
}

@Composable
fun OverviewCardItem(card: CardItem, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .width(220.dp)
            .height(120.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = if (card.isVirtual) listOf(Color(0xFF1E3A5F), Color(0xFF0F1E33))
                    else listOf(Color(0xFF13294B), Color(0xFF091426))
                )
            )
            .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = card.brand,
                    color = NovaGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = if (card.isVirtual) "VIRTUAL" else "FÍSICO",
                    color = NovaTextSecondary,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = "••••  ••••  ••••  ${card.last4Digits}",
                color = NovaTextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = card.friendlyName,
                    color = NovaTextSecondary,
                    fontSize = 10.sp
                )
                Text(
                    text = card.expiryDate,
                    color = NovaTextSecondary,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun OverviewOperationRow(op: PaymentOperation, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(NovaNavyCard)
            .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(NovaNavyDark),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = when (op.type) {
                    com.example.domain.models.PaymentType.TRANSFER -> Icons.AutoMirrored.Filled.Send
                    com.example.domain.models.PaymentType.SERVICE_PAYMENT -> Icons.Default.Widgets
                    else -> Icons.Default.Payment
                },
                contentDescription = null,
                tint = NovaGold,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = op.beneficiary,
                color = NovaTextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${op.type.label} • ${op.createdAt}",
                color = NovaTextSecondary,
                fontSize = 11.sp
            )
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = formatAoa(op.amount),
                color = NovaTextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            StatusChip(status = op.status)
        }
    }
}
