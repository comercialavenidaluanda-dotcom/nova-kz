package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val NovaDarkColorScheme = darkColorScheme(
    primary = NovaGold,
    onPrimary = NovaNavyDark,
    primaryContainer = NovaNavyCard,
    onPrimaryContainer = NovaGoldLight,
    secondary = NovaEmerald,
    onSecondary = NovaNavyDark,
    secondaryContainer = NovaEmeraldBg,
    onSecondaryContainer = NovaEmeraldLight,
    tertiary = NovaInfoBlue,
    onTertiary = NovaNavyDark,
    background = NovaNavyDark,
    onBackground = NovaTextPrimary,
    surface = NovaNavySurface,
    onSurface = NovaTextPrimary,
    surfaceVariant = NovaNavyCard,
    onSurfaceVariant = NovaTextSecondary,
    outline = NovaNavyCardBorder,
    error = NovaDangerRed,
    onError = NovaTextPrimary,
    errorContainer = NovaDangerBg
)

private val NovaLightColorScheme = darkColorScheme(
    // Defaulting to dark navy theme preserves the exact NOVA KZ brand identity across devices
    primary = NovaGold,
    onPrimary = NovaNavyDark,
    primaryContainer = NovaNavyCard,
    onPrimaryContainer = NovaGoldLight,
    secondary = NovaEmerald,
    onSecondary = NovaNavyDark,
    secondaryContainer = NovaEmeraldBg,
    onSecondaryContainer = NovaEmeraldLight,
    tertiary = NovaInfoBlue,
    onTertiary = NovaNavyDark,
    background = NovaNavyDark,
    onBackground = NovaTextPrimary,
    surface = NovaNavySurface,
    onSurface = NovaTextPrimary,
    surfaceVariant = NovaNavyCard,
    onSurfaceVariant = NovaTextSecondary,
    outline = NovaNavyCardBorder,
    error = NovaDangerRed,
    onError = NovaTextPrimary,
    errorContainer = NovaDangerBg
)

@Composable
fun NovaKzTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) NovaDarkColorScheme else NovaLightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            window?.let {
                it.statusBarColor = NovaNavyDark.toArgb()
                it.navigationBarColor = NovaNavyDark.toArgb()
                WindowCompat.getInsetsController(it, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(it, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// Backward compatibility alias
@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    NovaKzTheme(darkTheme = darkTheme, content = content)
}
