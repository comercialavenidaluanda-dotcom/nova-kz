package com.example.ui.screens.payments

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.AuthMethod
import com.example.domain.models.PaymentOperation
import com.example.domain.models.PaymentStatus
import com.example.network.NetworkResult
import com.example.payments.PaymentManager
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxBadge
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.components.StatusChip
import com.example.ui.components.formatAoa
import com.example.ui.theme.NovaBorder
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaEmeraldBg
import com.example.ui.theme.NovaEmeraldLight
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaGoldLight
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaSandboxAmber
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AuthorizePaymentScreen(
    operationId: String,
    paymentManager: PaymentManager,
    onBiometricAuthRequested: ((onSuccess: () -> Unit) -> Unit)? = null,
    onPaymentConfirmed: (String) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val operation = paymentManager.getOperationById(operationId)

    var selectedAuthMethod by remember { mutableStateOf(AuthMethod.APP) }
    var isProcessing by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var confirmationResult by remember { mutableStateOf<PaymentOperation?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Autorização de Operação",
            onBack = onBack
        )

        if (operation == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Operação não encontrada.",
                    color = NovaDangerRed,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                NovaButton(text = "Voltar", onClick = onBack)
            }
            return@Column
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SandboxDisclaimerBanner()
            Spacer(modifier = Modifier.height(14.dp))

            // Operation Details Summary Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("authorize_details_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(16.dp))
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = operation.type.label.uppercase(),
                            color = NovaTextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        StatusChip(status = operation.status)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = formatAoa(operation.amount),
                        color = NovaGoldLight,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(NovaNavyCardBorder.copy(alpha = 0.6f))
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    DetailItem(label = "Beneficiário", value = operation.beneficiary)
                    if (!operation.reference.isNullOrBlank()) {
                        DetailItem(label = "Referência", value = operation.reference)
                    }
                    if (!operation.beneficiaryAccount.isNullOrBlank()) {
                        DetailItem(label = "Conta / IBAN", value = operation.beneficiaryAccount)
                    }
                    DetailItem(label = "Descrição", value = operation.description)
                    DetailItem(label = "Chave de Idempotência", value = operation.idempotencyKey.take(18) + "...")
                    DetailItem(label = "Ambiente", value = operation.environment)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Authorization Methods Section
            Text(
                text = "Selecione o Método de Autorização",
                color = NovaTextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                text = "Para o ambiente Sandbox, utilize a autorização direta via App.",
                color = NovaTextSecondary,
                fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            val authMethods = listOf(
                AuthMethod.APP,
                AuthMethod.MCX_EXPRESS,
                AuthMethod.OTP,
                AuthMethod.THREE_DS,
                AuthMethod.BANK,
                AuthMethod.OTHER
            )

            authMethods.forEach { method ->
                AuthMethodRadioCard(
                    method = method,
                    isSelected = selectedAuthMethod == method,
                    onSelect = { selectedAuthMethod = method }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = errorMessage!!,
                    color = NovaDangerRed,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            val executePaymentTransaction: () -> Unit = {
                scope.launch {
                    isProcessing = true
                    errorMessage = null

                    // 1. Authorize Step
                    val authResult = paymentManager.authorizePaymentOperation(
                        operationId = operation.id,
                        authMethod = selectedAuthMethod
                    )

                    if (authResult is NetworkResult.Error) {
                        isProcessing = false
                        errorMessage = authResult.message
                        return@launch
                    }

                    delay(400) // Brief simulation of secure verification

                    // 2. Process & Confirm Step
                    val confirmResult = paymentManager.processAndConfirmPayment(operation.id)
                    isProcessing = false

                    when (confirmResult) {
                        is NetworkResult.Success -> {
                            confirmationResult = confirmResult.data
                            onPaymentConfirmed(confirmResult.data.id)
                        }
                        is NetworkResult.Error -> {
                            errorMessage = confirmResult.message
                        }
                    }
                }
            }

            if (selectedAuthMethod == AuthMethod.APP) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = NovaEmeraldBg)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fingerprint,
                            contentDescription = "Biometria",
                            tint = NovaEmeraldLight,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "A operação requer validação biométrica do dispositivo para confirmação segura.",
                            color = NovaEmeraldLight,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Confirmation Action
            NovaButton(
                text = if (selectedAuthMethod == AuthMethod.APP) "Autorizar com Biometria / App" else "Confirmar e Autorizar Operação",
                leadingIcon = if (selectedAuthMethod == AuthMethod.APP) Icons.Default.Fingerprint else Icons.Default.Shield,
                onClick = {
                    if (isProcessing) return@NovaButton
                    if (selectedAuthMethod == AuthMethod.APP && onBiometricAuthRequested != null) {
                        onBiometricAuthRequested {
                            executePaymentTransaction()
                        }
                    } else {
                        executePaymentTransaction()
                    }
                },
                isLoading = isProcessing,
                modifier = Modifier.fillMaxWidth(),
                testTag = "authorize_submit_button"
            )

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun DetailItem(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = NovaTextSecondary, fontSize = 12.sp)
        Text(
            text = value,
            color = NovaTextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun AuthMethodRadioCard(
    method: AuthMethod,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) NovaNavySurface else NovaNavyCard)
            .border(
                1.dp,
                if (isSelected) NovaGold else NovaNavyCardBorder,
                RoundedCornerShape(10.dp)
            )
            .clickable { onSelect() }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = isSelected,
            onClick = onSelect,
            colors = RadioButtonDefaults.colors(
                selectedColor = NovaGold,
                unselectedColor = NovaTextSecondary
            )
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = method.label,
                color = if (isSelected) NovaGoldLight else NovaTextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = method.description,
                color = NovaTextSecondary,
                fontSize = 11.sp
            )
        }
    }
}
