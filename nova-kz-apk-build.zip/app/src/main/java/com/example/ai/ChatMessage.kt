package com.example.ai

import java.util.UUID

enum class ChatSender {
    USER,
    BOT,
    SYSTEM
}

enum class AssistantTaskMode(val label: String, val modelId: String, val description: String) {
    GENERAL("Geral (3.5 Flash)", "gemini-3.5-flash", "Ideal para tarefas gerais e localização com Maps"),
    COMPLEX("Especialista (3.1 Pro)", "gemini-3.1-pro-preview", "Raciocínio financeiro avançado, análise e RUPE"),
    FAST("Rápido (3.1 Lite)", "gemini-3.1-flash-lite-preview", "Respostas instantâneas e dúvidas rápidas")
}

data class GroundingLocation(
    val title: String,
    val address: String,
    val bankOrNetwork: String = "EMIS / Multicaixa",
    val distance: String = "A 450 m",
    val isOpen24h: Boolean = true,
    val hasCash: Boolean = true,
    val latitude: Double = -8.8383,
    val longitude: Double = 13.2344
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: ChatSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val modelUsed: String? = null,
    val isVoice: Boolean = false,
    val groundingLocations: List<GroundingLocation> = emptyList(),
    val isStreaming: Boolean = false
)
