package com.example.payments

import android.util.Log
import com.example.data.LocalDataStore
import com.example.data.repository.PaymentTransactionRepository
import com.example.domain.models.AuthMethod
import com.example.domain.models.BankAccount
import com.example.domain.models.CardItem
import com.example.domain.models.CardStatus
import com.example.domain.models.PaymentOperation
import com.example.domain.models.PaymentStatus
import com.example.domain.models.PaymentType
import com.example.network.NetworkResult
import com.example.network.SupabaseEndpoints
import com.example.network.SupabaseRestClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class PaymentManager(
    private val dataStore: LocalDataStore,
    private val restClient: SupabaseRestClient,
    private val transactionRepository: PaymentTransactionRepository? = null,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
) {
    private val executionMutex = Mutex()
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "AO"))

    private val _operations = MutableStateFlow<List<PaymentOperation>>(emptyList())
    val operations: StateFlow<List<PaymentOperation>> = _operations.asStateFlow()

    private val _bankAccounts = MutableStateFlow<List<BankAccount>>(emptyList())
    val bankAccounts: StateFlow<List<BankAccount>> = _bankAccounts.asStateFlow()

    private val _cards = MutableStateFlow<List<CardItem>>(emptyList())
    val cards: StateFlow<List<CardItem>> = _cards.asStateFlow()

    private val _sandboxBalance = MutableStateFlow(1000.0) // 1.000,00 AOA initial
    val sandboxBalance: StateFlow<Double> = _sandboxBalance.asStateFlow()

    private val _pendingAuthorizations = MutableStateFlow<List<PaymentOperation>>(emptyList())
    val pendingAuthorizations: StateFlow<List<PaymentOperation>> = _pendingAuthorizations.asStateFlow()

    init {
        loadInitialData()
    }

    private fun loadInitialData() {
        // Initial Sandbox accounts
        _bankAccounts.value = listOf(
            BankAccount(
                id = "acc_01",
                bankName = "Banco Angolano de Investimentos (BAI)",
                iban = "AO06.0040.0000.8291.0291.1012.3",
                accountNumber = "82910291101",
                accountType = "Conta Corrente",
                currency = "AOA",
                balance = 1000.0,
                isPrimary = true
            ),
            BankAccount(
                id = "acc_02",
                bankName = "Banco de Fomento Angola (BFA)",
                iban = "AO06.0006.0000.1928.3746.5019.2",
                accountNumber = "19283746501",
                accountType = "Conta Ordem",
                currency = "AOA",
                balance = 250000.0,
                isPrimary = false
            ),
            BankAccount(
                id = "acc_03",
                bankName = "Banco Millennium Atlântico (BMA)",
                iban = "AO06.0055.0000.4433.2211.9087.1",
                accountNumber = "44332211908",
                accountType = "Conta Poupança",
                currency = "AOA",
                balance = 50000.0,
                isPrimary = false
            )
        )

        // Initial Cards (strictly compliant with security rule: brand, last 4 digits, status, friendly name only)
        _cards.value = listOf(
            CardItem(
                id = "crd_01",
                friendlyName = "Multicaixa Débito BAI",
                brand = "Multicaixa",
                last4Digits = "8492",
                expiryDate = "08/28",
                status = CardStatus.ACTIVE,
                isVirtual = false,
                dailyLimitAoa = 500000.0
            ),
            CardItem(
                id = "crd_02",
                friendlyName = "Cartão Virtual Compras Online",
                brand = "Visa",
                last4Digits = "1934",
                expiryDate = "12/26",
                status = CardStatus.ACTIVE,
                isVirtual = true,
                dailyLimitAoa = 150000.0
            )
        )

        // Seed initial operations to show history and pending auth
        val initialList = listOf(
            PaymentOperation(
                id = "op_init_01",
                idempotencyKey = UUID.randomUUID().toString(),
                type = PaymentType.SERVICE_PAYMENT,
                amount = 150.0,
                currency = "AOA",
                beneficiary = "ENDE - E.P.",
                reference = "1002938491",
                description = "Pagamento Energia Pré-Pago",
                status = PaymentStatus.CONFIRMED,
                authMethod = AuthMethod.APP,
                environment = "SANDBOX",
                createdAt = dateFormat.format(Date(System.currentTimeMillis() - 86400000L * 2)),
                completedAt = dateFormat.format(Date(System.currentTimeMillis() - 86400000L * 2)),
                fee = 0.0,
                transactionId = "NKZ-84920192"
            ),
            PaymentOperation(
                id = "op_init_02",
                idempotencyKey = UUID.randomUUID().toString(),
                type = PaymentType.TRANSFER,
                amount = 200.0,
                currency = "AOA",
                beneficiary = "António Kwanza",
                beneficiaryAccount = "AO06.0040.0000.1122.3344.5566.7",
                description = "Reembolso almoço executivo",
                status = PaymentStatus.PENDING_AUTHORIZATION,
                authMethod = AuthMethod.APP,
                environment = "SANDBOX",
                createdAt = dateFormat.format(Date(System.currentTimeMillis() - 3600000L * 3)),
                fee = 0.0,
                transactionId = "NKZ-99381023"
            )
        )
        _operations.value = initialList
        updatePendingAuthorizations()

        // Room database persistence observation
        transactionRepository?.let { repo ->
            scope.launch {
                repo.allTransactions.collect { cachedList ->
                    if (cachedList.isNotEmpty()) {
                        _operations.value = cachedList
                        updatePendingAuthorizations()
                    }
                }
            }
            scope.launch {
                if (repo.getTransactionCount() == 0) {
                    repo.saveTransactions(initialList)
                }
            }
        }

        // Backend Sandbox balance default is 1000.00 AOA as mandated:
        // "O saldo Sandbox inicial do backend é 1.000,00 AOA. Não alterar esse valor automaticamente."
        _sandboxBalance.value = dataStore.sandboxBalance
    }

    private fun updatePendingAuthorizations() {
        _pendingAuthorizations.value = _operations.value.filter {
            it.status == PaymentStatus.PENDING_AUTHORIZATION
        }
    }

    // Step 1: CRIAR & VALIDAR
    suspend fun createPaymentOperation(
        type: PaymentType,
        amount: Double,
        beneficiary: String,
        description: String,
        reference: String? = null,
        beneficiaryAccount: String? = null,
        authMethod: AuthMethod = AuthMethod.APP,
        idempotencyKey: String? = null
    ): NetworkResult<PaymentOperation> {
        // Pre-validation
        if (amount <= 0) {
            return NetworkResult.Error("O valor do pagamento deve ser superior a 0,00 AOA.")
        }
        if (beneficiary.isBlank()) {
            return NetworkResult.Error("Indique o beneficiário ou entidade de destino.")
        }

        val effectiveIdempotencyKey = idempotencyKey ?: UUID.randomUUID().toString()

        // Idempotency check: if an operation with this idempotencyKey already exists, return it
        val existingOp = _operations.value.find { it.idempotencyKey == effectiveIdempotencyKey }
        if (existingOp != null) {
            Log.d(TAG, "Idempotent create: returning existing operation ${existingOp.id}")
            return NetworkResult.Success(existingOp)
        }

        val operation = PaymentOperation(
            id = UUID.randomUUID().toString(),
            idempotencyKey = effectiveIdempotencyKey,
            type = type,
            amount = amount,
            currency = "AOA",
            beneficiary = beneficiary,
            beneficiaryAccount = beneficiaryAccount,
            reference = reference,
            description = description.ifBlank { type.label },
            status = PaymentStatus.VALIDATED,
            authMethod = authMethod,
            environment = "SANDBOX",
            createdAt = dateFormat.format(Date()),
            fee = 0.0,
            transactionId = "NKZ-" + System.currentTimeMillis().toString().takeLast(8)
        )

        // Call RPC nova_kz_create_payment_operation with exact Supabase PostgreSQL signature
        val rpcParams = JSONObject().apply {
            put("p_amount", amount)
            put("p_beneficiary_account", beneficiaryAccount ?: "")
            put("p_beneficiary_name", beneficiary)
            put("p_currency", "AOA")
            put("p_description", operation.description)
            put("p_idempotency_key", effectiveIdempotencyKey)
            put("p_operation_type", type.name)
        }

        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_CREATE_PAYMENT, rpcParams)
        Log.d(TAG, "nova_kz_create_payment_operation RPC result: $rpcResult")

        // Progress to PENDING_AUTHORIZATION according to state machine
        val pendingOp = operation.copy(status = PaymentStatus.PENDING_AUTHORIZATION)
        _operations.value = listOf(pendingOp) + _operations.value
        updatePendingAuthorizations()
        scope.launch {
            transactionRepository?.saveOrUpdateTransaction(pendingOp)
        }

        return NetworkResult.Success(pendingOp)
    }

    // Step 2: AUTORIZAR
    suspend fun authorizePaymentOperation(
        operationId: String,
        authMethod: AuthMethod = AuthMethod.APP,
        confirmationCode: String = ""
    ): NetworkResult<PaymentOperation> {
        val currentOp = _operations.value.find { it.id == operationId }
            ?: return NetworkResult.Error("Operação não encontrada.")

        // Strict State Machine Validation
        if (!currentOp.status.canTransitionTo(PaymentStatus.AUTHORIZED)) {
            return NetworkResult.Error("Transição de estado inválida: não é permitido transitar de ${currentOp.status.name} para AUTHORIZED.")
        }

        // Call RPC nova_kz_authorize_payment_operation with exact Supabase PostgreSQL signature
        val rpcParams = JSONObject().apply {
            put("p_method", authMethod.name)
            put("p_operation_id", operationId)
        }

        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_AUTHORIZE_PAYMENT, rpcParams)
        Log.d(TAG, "nova_kz_authorize_payment_operation RPC result: $rpcResult")

        val authorizedOp = currentOp.copy(
            status = PaymentStatus.AUTHORIZED,
            authMethod = authMethod
        )

        updateOperationInList(authorizedOp)
        updatePendingAuthorizations()
        scope.launch {
            transactionRepository?.saveOrUpdateTransaction(authorizedOp)
        }

        return NetworkResult.Success(authorizedOp)
    }

    // Step 3 & 4: PROCESSAR & CONFIRMAR COM PROTEÇÃO DE CONCORRÊNCIA E IDEMPOTÊNCIA
    suspend fun processAndConfirmPayment(
        operationId: String
    ): NetworkResult<PaymentOperation> = executionMutex.withLock {
        val currentOp = _operations.value.find { it.id == operationId }
            ?: return@withLock NetworkResult.Error("Operação não encontrada.")

        // Idempotency: if already confirmed, reject second execution and do NOT deduct again!
        if (currentOp.status == PaymentStatus.CONFIRMED) {
            Log.d(TAG, "Idempotent payment confirmation: operation $operationId already CONFIRMED. Rejected second execution.")
            return@withLock NetworkResult.Error("Operação já confirmada (execução idempotente rejeitada). Nenhuma nova cobrança efetuada.")
        }

        // Strict state validation: must be authorized
        if (!currentOp.status.canTransitionTo(PaymentStatus.PROCESSING)) {
            return@withLock NetworkResult.Error("A operação não pode ser processada a partir do estado ${currentOp.status.label}.")
        }

        // Check sandbox balance
        if (currentOp.amount > _sandboxBalance.value) {
            val failedOp = currentOp.copy(
                status = PaymentStatus.FAILED,
                failureReason = "Saldo Sandbox insuficiente para cobrir o valor de ${String.format(Locale("pt", "AO"), "%,.2f", currentOp.amount)} AOA."
            )
            updateOperationInList(failedOp)
            updatePendingAuthorizations()
            scope.launch {
                transactionRepository?.saveOrUpdateTransaction(failedOp)
            }
            return@withLock NetworkResult.Error(failedOp.failureReason ?: "Saldo insuficiente.")
        }

        // Transition to PROCESSING
        val processingOp = currentOp.copy(status = PaymentStatus.PROCESSING)
        updateOperationInList(processingOp)

        // Call Supabase RPC nova_kz_execute_sandbox_payment
        val executeParams = JSONObject().apply {
            put("p_operation_id", operationId)
        }
        restClient.invokeRpc(SupabaseEndpoints.RPC_EXECUTE_SANDBOX_PAYMENT, executeParams)

        // Call Supabase RPC nova_kz_transition_payment with exact signature
        val transitionParams = JSONObject().apply {
            put("p_id", operationId)
            put("p_new_status", PaymentStatus.CONFIRMED.name)
            put("p_reason", "Transação confirmada via biometria/app")
        }
        restClient.invokeRpc(SupabaseEndpoints.RPC_TRANSITION_PAYMENT, transitionParams)

        // Transition to CONFIRMED
        val confirmedOp = processingOp.copy(
            status = PaymentStatus.CONFIRMED,
            completedAt = dateFormat.format(Date())
        )

        // Deduct from sandbox balance safely for this confirmed operation
        val newBalance = _sandboxBalance.value - currentOp.amount
        _sandboxBalance.value = newBalance
        dataStore.sandboxBalance = newBalance

        updateOperationInList(confirmedOp)
        updatePendingAuthorizations()
        scope.launch {
            transactionRepository?.saveOrUpdateTransaction(confirmedOp)
        }

        return@withLock NetworkResult.Success(confirmedOp)
    }

    private fun updateOperationInList(updated: PaymentOperation) {
        _operations.value = _operations.value.map {
            if (it.id == updated.id) updated else it
        }
    }

    fun getOperationById(id: String): PaymentOperation? {
        return _operations.value.find { it.id == id }
    }

    suspend fun refreshBackendBalance() {
        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_GET_SANDBOX_BALANCE, JSONObject())
        if (rpcResult is NetworkResult.Success) {
            try {
                val json = JSONObject(rpcResult.data)
                val balance = json.optDouble("balance", _sandboxBalance.value)
                _sandboxBalance.value = balance
                dataStore.sandboxBalance = balance
            } catch (e: Exception) {
                // Keep current
            }
        }
    }

    suspend fun fetchSandboxBalance() {
        refreshBackendBalance()
    }

    suspend fun loadBankAccounts() {
        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_LIST_BANK_ACCOUNTS, JSONObject())
        if (rpcResult is NetworkResult.Success) {
            try {
                val array = org.json.JSONArray(rpcResult.data)
                val list = mutableListOf<BankAccount>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        BankAccount(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            bankName = obj.optString("bank_name", "Banco"),
                            iban = obj.optString("iban", ""),
                            accountNumber = obj.optString("account_number", ""),
                            accountType = obj.optString("account_type", "Conta Corrente"),
                            currency = obj.optString("currency", "AOA"),
                            balance = obj.optDouble("balance", 0.0),
                            isPrimary = obj.optBoolean("is_primary", i == 0)
                        )
                    )
                }
                if (list.isNotEmpty()) {
                    _bankAccounts.value = list
                }
            } catch (e: Exception) {
                Log.d(TAG, "Error parsing bank accounts from RPC: ${e.message}")
            }
        }
    }

    suspend fun loadMyPaymentOperations() {
        if (transactionRepository != null) {
            val syncResult = transactionRepository.syncTransactionsFromBackend()
            if (syncResult is NetworkResult.Success && syncResult.data.isNotEmpty()) {
                _operations.value = syncResult.data
                updatePendingAuthorizations()
                return
            }
        }

        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_LIST_MY_OPERATIONS, JSONObject())
        if (rpcResult is NetworkResult.Success) {
            try {
                val array = org.json.JSONArray(rpcResult.data)
                val list = mutableListOf<PaymentOperation>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val statusStr = obj.optString("status", "DRAFT")
                    val typeStr = obj.optString("type", "TRANSFER")
                    val authMethodStr = obj.optString("auth_method", "APP")
                    val status = try { PaymentStatus.valueOf(statusStr) } catch (e: Exception) { PaymentStatus.DRAFT }
                    val type = try { PaymentType.valueOf(typeStr) } catch (e: Exception) { PaymentType.TRANSFER }
                    val authMethod = try { AuthMethod.valueOf(authMethodStr) } catch (e: Exception) { AuthMethod.APP }

                    list.add(
                        PaymentOperation(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            idempotencyKey = obj.optString("idempotency_key", UUID.randomUUID().toString()),
                            type = type,
                            amount = obj.optDouble("amount", 0.0),
                            currency = obj.optString("currency", "AOA"),
                            beneficiary = obj.optString("beneficiary", ""),
                            beneficiaryAccount = if (obj.has("beneficiary_account") && !obj.isNull("beneficiary_account")) obj.getString("beneficiary_account") else null,
                            reference = if (obj.has("reference") && !obj.isNull("reference")) obj.getString("reference") else null,
                            description = obj.optString("description", ""),
                            status = status,
                            authMethod = authMethod,
                            environment = obj.optString("environment", "SANDBOX"),
                            createdAt = obj.optString("created_at", dateFormat.format(Date())),
                            completedAt = if (obj.has("completed_at") && !obj.isNull("completed_at")) obj.getString("completed_at") else null,
                            fee = obj.optDouble("fee", 0.0),
                            transactionId = obj.optString("transaction_id", "NKZ-" + System.currentTimeMillis().toString().takeLast(8)),
                            failureReason = if (obj.has("failure_reason") && !obj.isNull("failure_reason")) obj.getString("failure_reason") else null
                        )
                    )
                }
                if (list.isNotEmpty()) {
                    _operations.value = list
                    updatePendingAuthorizations()
                    scope.launch {
                        transactionRepository?.saveTransactions(list)
                    }
                }
            } catch (e: Exception) {
                Log.d(TAG, "Error parsing payment operations from RPC: ${e.message}")
            }
        }
    }

    companion object {
        private const val TAG = "PaymentManager"
    }
}
