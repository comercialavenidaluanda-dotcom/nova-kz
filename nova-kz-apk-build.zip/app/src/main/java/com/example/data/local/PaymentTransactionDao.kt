package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentTransactionDao {

    @Query("SELECT * FROM nova_kz_payment_transactions ORDER BY updatedAt DESC, createdAt DESC")
    fun getAllTransactions(): Flow<List<PaymentTransactionEntity>>

    @Query("SELECT * FROM nova_kz_payment_transactions WHERE id = :id")
    suspend fun getTransactionById(id: String): PaymentTransactionEntity?

    @Query("SELECT * FROM nova_kz_payment_transactions WHERE idempotencyKey = :idempotencyKey")
    suspend fun getTransactionByIdempotencyKey(idempotencyKey: String): PaymentTransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: PaymentTransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<PaymentTransactionEntity>)

    @Query("UPDATE nova_kz_payment_transactions SET status = :status, completedAt = :completedAt, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateStatus(id: String, status: String, completedAt: String?, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM nova_kz_payment_transactions WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM nova_kz_payment_transactions")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM nova_kz_payment_transactions")
    suspend fun getCount(): Int
}
