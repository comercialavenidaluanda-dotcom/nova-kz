package com.example.data

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest

class LocalDataStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("nova_kz_secure_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_AUTH_TOKEN = "auth_token"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_EMAIL = "user_email"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_PHONE = "user_phone"
        private const val KEY_FCM_TOKEN = "fcm_token"
        private const val KEY_APP_PIN_HASH = "app_pin_hash"
        private const val KEY_BIOMETRICS_ENABLED = "biometrics_enabled"
        private const val KEY_INACTIVITY_TIMEOUT_MINS = "inactivity_timeout_mins"
        private const val KEY_LAST_INTERACTION_MS = "last_interaction_ms"
        private const val KEY_IS_LOCKED = "is_locked"
        private const val KEY_IS_BALANCE_HIDDEN = "is_balance_hidden"
        private const val KEY_SANDBOX_BALANCE = "sandbox_balance"
        private const val DEFAULT_SANDBOX_BALANCE = 1000.0 // 1.000,00 AOA as mandated
    }

    var isBalanceHidden: Boolean
        get() = prefs.getBoolean(KEY_IS_BALANCE_HIDDEN, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_BALANCE_HIDDEN, value).apply()

    var authToken: String?
        get() = prefs.getString(KEY_AUTH_TOKEN, null)
        set(value) = prefs.edit().putString(KEY_AUTH_TOKEN, value).apply()

    var userId: String
        get() = prefs.getString(KEY_USER_ID, "usr_novakz_sandbox_01") ?: "usr_novakz_sandbox_01"
        set(value) = prefs.edit().putString(KEY_USER_ID, value).apply()

    var userEmail: String
        get() = prefs.getString(KEY_USER_EMAIL, "comercialavenidaluanda@gmail.com") ?: "comercialavenidaluanda@gmail.com"
        set(value) = prefs.edit().putString(KEY_USER_EMAIL, value).apply()

    var userName: String
        get() = prefs.getString(KEY_USER_NAME, "Utilizador NOVA KZ") ?: "Utilizador NOVA KZ"
        set(value) = prefs.edit().putString(KEY_USER_NAME, value).apply()

    var userPhone: String
        get() = prefs.getString(KEY_USER_PHONE, "+244 923 000 000") ?: "+244 923 000 000"
        set(value) = prefs.edit().putString(KEY_USER_PHONE, value).apply()

    var fcmToken: String?
        get() = prefs.getString(KEY_FCM_TOKEN, null)
        set(value) = prefs.edit().putString(KEY_FCM_TOKEN, value).apply()

    var isBiometricsEnabled: Boolean
        get() = prefs.getBoolean(KEY_BIOMETRICS_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_BIOMETRICS_ENABLED, value).apply()

    var isBiometricEnabled: Boolean
        get() = isBiometricsEnabled
        set(value) { isBiometricsEnabled = value }

    var inactivityTimeoutMinutes: Int
        get() = prefs.getInt(KEY_INACTIVITY_TIMEOUT_MINS, 3)
        set(value) = prefs.edit().putInt(KEY_INACTIVITY_TIMEOUT_MINS, value).apply()

    var lastInteractionTimestamp: Long
        get() = prefs.getLong(KEY_LAST_INTERACTION_MS, System.currentTimeMillis())
        set(value) = prefs.edit().putLong(KEY_LAST_INTERACTION_MS, value).apply()

    var isAppLocked: Boolean
        get() = prefs.getBoolean(KEY_IS_LOCKED, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_LOCKED, value).apply()

    var sandboxBalance: Double
        get() = java.lang.Double.longBitsToDouble(
            prefs.getLong(KEY_SANDBOX_BALANCE, java.lang.Double.doubleToLongBits(DEFAULT_SANDBOX_BALANCE))
        )
        set(value) = prefs.edit().putLong(KEY_SANDBOX_BALANCE, java.lang.Double.doubleToLongBits(value)).apply()

    fun hasAppPin(): Boolean {
        return prefs.getString(KEY_APP_PIN_HASH, null) != null
    }

    fun setAppPin(pin: String) {
        val hash = hashPin(pin)
        prefs.edit().putString(KEY_APP_PIN_HASH, hash).apply()
    }

    fun verifyAppPin(pin: String): Boolean {
        val storedHash = prefs.getString(KEY_APP_PIN_HASH, null) ?: return pin == "1234"
        return storedHash == hashPin(pin)
    }

    private fun hashPin(pin: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest("nova_kz_salt_$pin".toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_AUTH_TOKEN)
            .remove(KEY_IS_LOCKED)
            .apply()
    }
}
