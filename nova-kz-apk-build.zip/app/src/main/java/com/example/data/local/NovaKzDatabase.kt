package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [PaymentTransactionEntity::class],
    version = 1,
    exportSchema = false
)
abstract class NovaKzDatabase : RoomDatabase() {

    abstract fun paymentTransactionDao(): PaymentTransactionDao

    companion object {
        @Volatile
        private var INSTANCE: NovaKzDatabase? = null

        fun getDatabase(context: Context): NovaKzDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NovaKzDatabase::class.java,
                    "nova_kz_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
