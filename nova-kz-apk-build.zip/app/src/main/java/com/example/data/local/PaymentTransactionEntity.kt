package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.models.AuthMethod
import com.example.domain.models.PaymentOperation
import com.example.domain.models.PaymentStatus
import com.example.domain.models.PaymentType

@Entity(tableName = "nova_kz_payment_transactions")
data class PaymentTransactionEntity(
    @PrimaryKey
    val id: String,
    val idempotencyKey: String,
    val type: String,
    val amount: Double,
    val currency: String = "AOA",
    val beneficiary: String,
    val beneficiaryAccount: String? = null,
    val reference: String? = null,
    val description: String,
    val status: String,
    val authMethod: String,
    val environment: String = "SANDBOX",
    val createdAt: String,
    val completedAt: String? = null,
    val fee: Double = 0.0,
    val transactionId: String,
    val failureReason: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun toDomainModel(): PaymentOperation {
        val opType = try { PaymentType.valueOf(type) } catch (e: Exception) { PaymentType.TRANSFER }
        val opStatus = try { PaymentStatus.valueOf(status) } catch (e: Exception) { PaymentStatus.DRAFT }
        val opAuth = try { AuthMethod.valueOf(authMethod) } catch (e: Exception) { AuthMethod.APP }
        return PaymentOperation(
            id = id,
            idempotencyKey = idempotencyKey,
            type = opType,
            amount = amount,
            currency = currency,
            beneficiary = beneficiary,
            beneficiaryAccount = beneficiaryAccount,
            reference = reference,
            description = description,
            status = opStatus,
            authMethod = opAuth,
            environment = environment,
            createdAt = createdAt,
            completedAt = completedAt,
            fee = fee,
            transactionId = transactionId,
            failureReason = failureReason
        )
    }

    companion object {
        fun fromDomainModel(op: PaymentOperation): PaymentTransactionEntity {
            return PaymentTransactionEntity(
                id = op.id,
                idempotencyKey = op.idempotencyKey,
                type = op.type.name,
                amount = op.amount,
                currency = op.currency,
                beneficiary = op.beneficiary,
                beneficiaryAccount = op.beneficiaryAccount,
                reference = op.reference,
                description = op.description,
                status = op.status.name,
                authMethod = op.authMethod.name,
                environment = op.environment,
                createdAt = op.createdAt,
                completedAt = op.completedAt,
                fee = op.fee,
                transactionId = op.transactionId,
                failureReason = op.failureReason,
                updatedAt = System.currentTimeMillis()
            )
        }
    }
}
