package com.example.data.repository

import android.util.Log
import com.example.data.local.PaymentTransactionDao
import com.example.data.local.PaymentTransactionEntity
import com.example.domain.models.AuthMethod
import com.example.domain.models.PaymentOperation
import com.example.domain.models.PaymentStatus
import com.example.domain.models.PaymentType
import com.example.network.NetworkResult
import com.example.network.SupabaseEndpoints
import com.example.network.SupabaseRestClient
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class PaymentTransactionRepository(
    private val transactionDao: PaymentTransactionDao,
    private val restClient: SupabaseRestClient
) {
    /**
     * Flow reativo expondo as transações cacheadas na tabela Room 'nova_kz_payment_transactions'.
     * Garante carregamento instantâneo no dispositivo offline ou online.
     */
    val allTransactions: Flow<List<PaymentOperation>> =
        transactionDao.getAllTransactions().map { entities ->
            entities.map { it.toDomainModel() }
        }

    suspend fun saveOrUpdateTransaction(operation: PaymentOperation) {
        val entity = PaymentTransactionEntity.fromDomainModel(operation)
        transactionDao.insertTransaction(entity)
    }

    suspend fun saveTransactions(operations: List<PaymentOperation>) {
        val entities = operations.map { PaymentTransactionEntity.fromDomainModel(it) }
        transactionDao.insertTransactions(entities)
    }

    suspend fun getTransactionById(id: String): PaymentOperation? {
        return transactionDao.getTransactionById(id)?.toDomainModel()
    }

    suspend fun getTransactionCount(): Int {
        return transactionDao.getCount()
    }

    /**
     * Sincroniza em background as transações obtidas do Supabase
     * e persiste no banco local Room (tabela 'nova_kz_payment_transactions').
     * Implementa resolução de conflitos baseada em updatedAt e precedência de estados terminais.
     */
    suspend fun syncTransactionsFromBackend(): NetworkResult<List<PaymentOperation>> {
        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_LIST_MY_OPERATIONS, JSONObject())

        val jsonArrayToParse: JSONArray? = when (rpcResult) {
            is NetworkResult.Success -> {
                try {
                    JSONArray(rpcResult.data)
                } catch (e: Exception) {
                    Log.d(TAG, "Parsing JSON array from RPC failed: ${e.message}")
                    null
                }
            }
            else -> null
        }

        if (jsonArrayToParse != null && jsonArrayToParse.length() > 0) {
            val operations = parseJsonToOperations(jsonArrayToParse)
            if (operations.isNotEmpty()) {
                val mergedEntities = mutableListOf<PaymentTransactionEntity>()
                for (op in operations) {
                    val existingLocal = transactionDao.getTransactionById(op.id)
                        ?: transactionDao.getTransactionByIdempotencyKey(op.idempotencyKey)

                    if (existingLocal == null) {
                        // Novo registro vindo do backend
                        mergedEntities.add(PaymentTransactionEntity.fromDomainModel(op))
                    } else {
                        val localStatus = try { PaymentStatus.valueOf(existingLocal.status) } catch (e: Exception) { PaymentStatus.DRAFT }
                        // Se o backend tiver estado terminal (CONFIRMED, FAILED, REJECTED, CANCELLED), backend prevalece
                        if (op.status.isTerminal() || !localStatus.isTerminal()) {
                            mergedEntities.add(PaymentTransactionEntity.fromDomainModel(op))
                        } else {
                            // Mantém o estado local se mais recente e ainda não sincronizado
                            mergedEntities.add(existingLocal)
                        }
                    }
                }
                transactionDao.insertTransactions(mergedEntities)
                Log.d(TAG, "Merged and persisted ${mergedEntities.size} transactions to Room (nova_kz_payment_transactions)")
                return NetworkResult.Success(mergedEntities.map { it.toDomainModel() })
            }
        }

        return when (rpcResult) {
            is NetworkResult.Success -> NetworkResult.Success(emptyList())
            is NetworkResult.Error -> NetworkResult.Error(rpcResult.message)
        }
    }

    private fun parseJsonToOperations(array: JSONArray): List<PaymentOperation> {
        val list = mutableListOf<PaymentOperation>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            val metadata = if (obj.has("metadata") && !obj.isNull("metadata")) obj.optJSONObject("metadata") else null

            val statusStr = obj.optString("status", "DRAFT")
            val typeStr = obj.optString("operation_type", obj.optString("type", "TRANSFER"))
            val authMethodStr = metadata?.optString("auth_method") ?: obj.optString("auth_method", "APP")
            val status = try { PaymentStatus.valueOf(statusStr) } catch (e: Exception) { PaymentStatus.DRAFT }
            val type = try { PaymentType.valueOf(typeStr) } catch (e: Exception) { PaymentType.TRANSFER }
            val authMethod = try { AuthMethod.valueOf(authMethodStr) } catch (e: Exception) { AuthMethod.APP }

            val beneficiary = metadata?.optString("beneficiary_name")
                ?: metadata?.optString("beneficiary")
                ?: obj.optString("beneficiary_name", obj.optString("beneficiary", ""))

            val beneficiaryAccount = when {
                metadata?.has("beneficiary_account") == true && !metadata.isNull("beneficiary_account") -> metadata.getString("beneficiary_account")
                obj.has("beneficiary_account") && !obj.isNull("beneficiary_account") -> obj.getString("beneficiary_account")
                else -> null
            }

            val reference = when {
                metadata?.has("reference") == true && !metadata.isNull("reference") -> metadata.getString("reference")
                obj.has("reference") && !obj.isNull("reference") -> obj.getString("reference")
                else -> null
            }

            val description = metadata?.optString("description")
                ?: obj.optString("description", "")

            val fee = metadata?.optDouble("fee", 0.0) ?: obj.optDouble("fee", 0.0)

            val completedAt = when {
                metadata?.has("completed_at") == true && !metadata.isNull("completed_at") -> metadata.getString("completed_at")
                obj.has("completed_at") && !obj.isNull("completed_at") -> obj.getString("completed_at")
                else -> null
            }

            val failureReason = when {
                metadata?.has("failure_reason") == true && !metadata.isNull("failure_reason") -> metadata.getString("failure_reason")
                obj.has("failure_reason") && !obj.isNull("failure_reason") -> obj.getString("failure_reason")
                else -> null
            }

            val transactionId = metadata?.optString("transaction_id")
                ?: obj.optString("transaction_id", "NKZ-" + System.currentTimeMillis().toString().takeLast(8))

            list.add(
                PaymentOperation(
                    id = obj.optString("id", UUID.randomUUID().toString()),
                    idempotencyKey = obj.optString("idempotency_key", UUID.randomUUID().toString()),
                    type = type,
                    amount = obj.optDouble("amount", 0.0),
                    currency = obj.optString("currency", "AOA"),
                    beneficiary = beneficiary,
                    beneficiaryAccount = beneficiaryAccount,
                    reference = reference,
                    description = description,
                    status = status,
                    authMethod = authMethod,
                    environment = obj.optString("environment", "SANDBOX"),
                    createdAt = obj.optString("created_at", ""),
                    completedAt = completedAt,
                    fee = fee,
                    transactionId = transactionId,
                    failureReason = failureReason
                )
            )
        }
        return list
    }

    companion object {
        private const val TAG = "PaymentTxRepo"
    }
}
