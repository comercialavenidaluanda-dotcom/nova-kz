package com.example.security

import android.content.Context
import com.example.data.LocalDataStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SecurityManager(
    private val context: Context,
    private val dataStore: LocalDataStore
) {
    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private var lastInteractionTime = System.currentTimeMillis()

    // Double-click protection threshold in ms
    private var lastClickTime = 0L
    private val clickDebouncePeriod = 600L

    fun notifyUserInteraction() {
        lastInteractionTime = System.currentTimeMillis()
        dataStore.lastInteractionTimestamp = lastInteractionTime
    }

    fun checkInactivityLock(): Boolean {
        // If not logged in, don't lock
        if (dataStore.authToken == null) return false

        val timeoutMillis = dataStore.inactivityTimeoutMinutes * 60 * 1000L
        val elapsed = System.currentTimeMillis() - lastInteractionTime
        if (elapsed > timeoutMillis) {
            _isLocked.value = true
            dataStore.isAppLocked = true
            return true
        }
        return false
    }

    fun lockManually() {
        _isLocked.value = true
        dataStore.isAppLocked = true
    }

    fun unlockWithPin(pin: String): Boolean {
        val valid = dataStore.verifyAppPin(pin)
        if (valid) {
            _isLocked.value = false
            dataStore.isAppLocked = false
            notifyUserInteraction()
        }
        return valid
    }

    fun unlockWithBiometrics() {
        _isLocked.value = false
        dataStore.isAppLocked = false
        notifyUserInteraction()
    }

    fun resetLock() {
        _isLocked.value = false
        dataStore.isAppLocked = false
    }

    /**
     * Prevents double clicks and multiple financial submissions
     */
    fun canExecuteAction(): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastClickTime < clickDebouncePeriod) {
            return false
        }
        lastClickTime = now
        notifyUserInteraction()
        return true
    }
}
