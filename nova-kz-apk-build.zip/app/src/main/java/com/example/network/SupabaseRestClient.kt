package com.example.network

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit

class SupabaseRestClient(
    private val baseUrl: String = SupabaseEndpoints.PROJECT_URL,
    private val getAuthToken: () -> String? = { null }
) {
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private val anonKey: String
        get() {
            return try {
                val key = BuildConfig.SUPABASE_ANON_KEY
                if (key.isNullOrBlank()) "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.e30.placeholder_anon_key" else key
            } catch (e: Exception) {
                "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.e30.placeholder_anon_key"
            }
        }

    suspend fun invokeRpc(functionName: String, params: JSONObject): NetworkResult<String> {
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/rest/v1/rpc/$functionName"
            val token = getAuthToken() ?: anonKey

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Authorization", "Bearer $token")
                .addHeader("Content-Type", "application/json")
                .post(params.toString().toRequestBody(jsonMediaType))
                .build()

            executeRequest(request)
        }
    }

    suspend fun invokeEdgeGateway(action: String, payload: JSONObject): NetworkResult<String> {
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/functions/v1/${SupabaseEndpoints.EDGE_INTEGRATION_GATEWAY}"
            val token = getAuthToken() ?: anonKey

            val fullBody = JSONObject().apply {
                put("action", action)
                put("environment", "SANDBOX")
                put("payload", payload)
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Authorization", "Bearer $token")
                .addHeader("Content-Type", "application/json")
                .post(fullBody.toString().toRequestBody(jsonMediaType))
                .build()

            executeRequest(request)
        }
    }

    suspend fun upsertDeviceToken(
        userId: String,
        token: String,
        platform: String = "android"
    ): NetworkResult<String> {
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/rest/v1/${SupabaseEndpoints.TABLE_DEVICE_TOKENS}"
            val authToken = getAuthToken() ?: anonKey

            val record = JSONObject().apply {
                put("user_id", userId)
                put("token", token)
                put("platform", platform)
                put("last_seen_at", java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).format(java.util.Date()))
                put("is_active", true)
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Authorization", "Bearer $authToken")
                .addHeader("Prefer", "resolution=merge-duplicates")
                .addHeader("Content-Type", "application/json")
                .post(record.toString().toRequestBody(jsonMediaType))
                .build()

            executeRequest(request)
        }
    }

    suspend fun deactivateDeviceToken(token: String): NetworkResult<String> {
        return withContext(Dispatchers.IO) {
            val url = "$baseUrl/rest/v1/${SupabaseEndpoints.TABLE_DEVICE_TOKENS}?token=eq.$token"
            val authToken = getAuthToken() ?: anonKey

            val update = JSONObject().apply {
                put("is_active", false)
            }

            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", anonKey)
                .addHeader("Authorization", "Bearer $authToken")
                .addHeader("Content-Type", "application/json")
                .patch(update.toString().toRequestBody(jsonMediaType))
                .build()

            executeRequest(request)
        }
    }

    private fun executeRequest(request: Request): NetworkResult<String> {
        return try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                val code = response.code

                when {
                    response.isSuccessful -> {
                        NetworkResult.Success(body)
                    }
                    code == 401 -> {
                        Log.w(TAG, "Session expired or unauthorized: $body")
                        NetworkResult.Error("Sessão expirada. Por favor, volte a autenticar-se.", code = 401, isSessionExpired = true)
                    }
                    code == 404 -> {
                        NetworkResult.Error("Recurso ou RPC não encontrado no backend ($code).", code = 404)
                    }
                    code in 500..599 -> {
                        NetworkResult.Error("Falha interna no servidor Supabase ($code). Tente mais tarde.", code = code)
                    }
                    else -> {
                        val parsedMessage = try {
                            JSONObject(body).optString("message", body)
                        } catch (e: Exception) {
                            body
                        }
                        NetworkResult.Error(parsedMessage.ifBlank { "Erro na requisição ($code)" }, code = code)
                    }
                }
            }
        } catch (e: SocketTimeoutException) {
            Log.e(TAG, "Request timeout", e)
            NetworkResult.Error("Tempo limite excedido na ligação ao servidor NOVA KZ.", isTimeout = true, cause = e)
        } catch (e: IOException) {
            Log.e(TAG, "Network IO error", e)
            NetworkResult.Error("Falha de rede ao contactar o servidor NOVA KZ. Verifique a ligação à internet.", isNetworkError = true, cause = e)
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error", e)
            NetworkResult.Error(e.localizedMessage ?: "Erro desconhecido na rede", cause = e)
        }
    }

    companion object {
        private const val TAG = "SupabaseRestClient"
    }
}
