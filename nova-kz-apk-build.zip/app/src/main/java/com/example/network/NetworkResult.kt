package com.example.network

sealed class NetworkResult<out T> {
    data class Success<T>(val data: T) : NetworkResult<T>()
    data class Error(
        val message: String,
        val code: Int? = null,
        val cause: Throwable? = null,
        val isNetworkError: Boolean = false,
        val isTimeout: Boolean = false,
        val isSessionExpired: Boolean = false
    ) : NetworkResult<Nothing>()
}
