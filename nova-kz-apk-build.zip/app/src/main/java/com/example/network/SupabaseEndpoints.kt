package com.example.network

object SupabaseEndpoints {
    const val PROJECT_URL = "https://earucsaqqtbllnqsxvlb.supabase.co"
    const val PROJECT_REF = "earucsaqqtbllnqsxvlb"

    // Public secure RPCs
    const val RPC_CREATE_PAYMENT = "nova_kz_create_payment_operation"
    const val RPC_AUTHORIZE_PAYMENT = "nova_kz_authorize_payment_operation"
    const val RPC_TRANSITION_PAYMENT = "nova_kz_transition_payment"
    const val RPC_EXECUTE_SANDBOX_PAYMENT = "nova_kz_execute_sandbox_payment"
    const val RPC_LIST_OPERATIONS = "nova_kz_list_my_payment_operations"
    const val RPC_LIST_MY_OPERATIONS = "nova_kz_list_my_payment_operations"
    const val RPC_LIST_BANK_ACCOUNTS = "nova_kz_list_bank_accounts"
    const val RPC_GET_SANDBOX_BALANCE = "nova_kz_get_sandbox_balance"

    // Integration Gateway Edge Function
    const val EDGE_INTEGRATION_GATEWAY = "nova-kz-integration-gateway"

    // Tables
    const val TABLE_PAYMENT_TRANSACTIONS = "nova_kz_payment_transactions"
    const val TABLE_DEVICE_TOKENS = "nova_kz_device_tokens"
    const val TABLE_NOTIFICATIONS = "nova_kz_notifications"
}
