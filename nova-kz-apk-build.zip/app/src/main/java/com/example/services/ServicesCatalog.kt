package com.example.services

import com.example.domain.models.ServiceCategoryType
import com.example.domain.models.ServiceProviderItem

object ServicesCatalog {

    val providers: List<ServiceProviderItem> = listOf(
        // Estado
        ServiceProviderItem(
            id = "srv_rupe",
            category = ServiceCategoryType.ESTADO,
            name = "RUPE - Documento Único de Cobrança",
            entityCode = "00001",
            placeholderRef = "Ex: 24010293849102",
            referenceLabel = "Número do RUPE (20 dígitos)",
            description = "Pagamento de impostos, taxas e emolumentos do Estado Angolano"
        ),
        ServiceProviderItem(
            id = "srv_agt",
            category = ServiceCategoryType.ESTADO,
            name = "AGT - Administração Geral Tributária",
            entityCode = "00002",
            placeholderRef = "Ex: 005928172LA041",
            referenceLabel = "NIF do Contribuinte",
            description = "Liquidação de impostos prediais, industriais e IRT"
        ),

        // Água
        ServiceProviderItem(
            id = "srv_epal",
            category = ServiceCategoryType.AGUA,
            name = "EPAL - Empresa Pública de Águas de Luanda",
            entityCode = "00101",
            placeholderRef = "Ex: 001928374",
            referenceLabel = "Número de Cliente EPAL",
            description = "Pagamento de faturas mensais de consumo de água potável"
        ),

        // Energia
        ServiceProviderItem(
            id = "srv_ende_pre",
            category = ServiceCategoryType.ENERGIA,
            name = "ENDE - Energia Pré-Pago (Recargas)",
            entityCode = "00201",
            placeholderRef = "Ex: 01928374650",
            referenceLabel = "Número do Contador ENDE",
            description = "Compra de recargas e geração de código de eletricidade"
        ),
        ServiceProviderItem(
            id = "srv_ende_pos",
            category = ServiceCategoryType.ENERGIA,
            name = "ENDE - Eletricidade Pós-Pago",
            entityCode = "00202",
            placeholderRef = "Ex: 100293849",
            referenceLabel = "Número de Contrato",
            description = "Liquidação de fatura mensal de consumo elétrico"
        ),

        // Telecom
        ServiceProviderItem(
            id = "srv_unitel",
            category = ServiceCategoryType.TELECOM,
            name = "Unitel - Carregamentos de Saldo & Net",
            entityCode = "00301",
            placeholderRef = "Ex: 923000000",
            referenceLabel = "Número de Telefone Unitel",
            description = "Planos Voz, Dados + e planos familiares"
        ),
        ServiceProviderItem(
            id = "srv_africell",
            category = ServiceCategoryType.TELECOM,
            name = "Africell Angola - Recargas",
            entityCode = "00302",
            placeholderRef = "Ex: 950000000",
            referenceLabel = "Número Africell",
            description = "Recargas de saldo e pacotes de internet de alta velocidade"
        ),
        ServiceProviderItem(
            id = "srv_zap",
            category = ServiceCategoryType.TELECOM,
            name = "ZAP Fibra & TV Satélite",
            entityCode = "00303",
            placeholderRef = "Ex: 0019283746",
            referenceLabel = "Número de Cartão ZAP",
            description = "Renovação de subscrição ZAP Mini, Max e Mega"
        ),
        ServiceProviderItem(
            id = "srv_dstv",
            category = ServiceCategoryType.TELECOM,
            name = "DStv Multichoice Angola",
            entityCode = "00304",
            placeholderRef = "Ex: 1029384756",
            referenceLabel = "Número Smartcard DStv",
            description = "Pagamento de pacotes Fácil, Grande, Grande Mais e Bué"
        ),

        // Saúde
        ServiceProviderItem(
            id = "srv_clinica_girassol",
            category = ServiceCategoryType.SAUDE,
            name = "Clínica Girassol",
            entityCode = "00501",
            placeholderRef = "Ex: FAT-839201",
            referenceLabel = "Número de Fatura Médica",
            description = "Consultas e exames médicos especializados"
        ),

        // Educação
        ServiceProviderItem(
            id = "srv_uan",
            category = ServiceCategoryType.EDUCACAO,
            name = "Universidade Agostinho Neto (UAN)",
            entityCode = "00601",
            placeholderRef = "Ex: 20249102",
            referenceLabel = "Número de Estudante / Matrícula",
            description = "Pagamento de propinas, emolumentos e inscrições"
        ),

        // Mobilidade
        ServiceProviderItem(
            id = "srv_cfl",
            category = ServiceCategoryType.MOBILIDADE,
            name = "CFL - Caminhos de Ferro de Luanda",
            entityCode = "00701",
            placeholderRef = "Ex: 923000000",
            referenceLabel = "Telefone para Bilhete Digital",
            description = "Passe mensal e bilhetes ferroviários Bungo - Viana"
        )
    )

    fun getProvidersByCategory(category: ServiceCategoryType): List<ServiceProviderItem> {
        return providers.filter { it.category == category }
    }
}
