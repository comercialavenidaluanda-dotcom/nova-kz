package com.example.domain.models

import java.util.UUID

enum class InsurerCompany(val displayName: String, val shortName: String, val providerHomologated: Boolean = false) {
    NOSSA("NOSSA Seguros", "NOSSA", false),
    ENSA("ENSA Seguros", "ENSA", false),
    FIDELIDADE("Fidelidade Angola", "Fidelidade", false),
    SANLAM_ALLIANZ("SanlamAllianz Angola", "SanlamAllianz", false),
    VIVA("VIVA Seguros", "VIVA", false);

    val companyName: String get() = displayName
}

enum class InsuranceProduct(val title: String, val description: String, val baseEstimateAoa: Double) {
    AUTO("Automóvel Obrigatório + Danos", "Proteção contra terceiros e danos próprios em Angola", 45_000.0),
    HEALTH("Saúde Individual & Família", "Rede de clínicas e hospitais privados conveniados", 120_000.0),
    LIFE("Vida & Invalidez", "Segurança financeira para os seus beneficiários", 35_000.0),
    HOME("Multirriscos Habitação", "Cobertura para incêndio, roubo e danos por água", 60_000.0),
    TRAVEL("Viagem Internacional", "Assistência médica no estrangeiro e perda de bagagem", 25_000.0);

    val productName: String get() = title
}

data class InsuranceQuote(
    val id: String = UUID.randomUUID().toString(),
    val insurer: InsurerCompany,
    val product: InsuranceProduct,
    val clientName: String,
    val clientPhone: String,
    val clientEmail: String,
    val notes: String = "",
    val quoteAmountAoa: Double,
    val currency: String = "AOA",
    val status: String = "COTADO_SANDBOX", // COTADO_SANDBOX, PAGO_SANDBOX, EXPIRADO
    val isSandbox: Boolean = true,
    val createdAt: String = "",
    val quoteReference: String = "SEG-" + System.currentTimeMillis().toString().takeLast(6)
)
