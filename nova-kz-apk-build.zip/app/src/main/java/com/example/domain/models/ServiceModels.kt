package com.example.domain.models

enum class ServiceCategoryType(val title: String, val iconName: String) {
    ESTADO("Estado (RUPE)", "account_balance"),
    AGUA("Água", "water_drop"),
    ENERGIA("Energia", "bolt"),
    TELECOM("Telecomunicações", "cell_tower"),
    SEGUROS("Seguros", "health_and_safety"),
    SAUDE("Saúde & Farmácias", "local_hospital"),
    EDUCACAO("Educação & Propinas", "school"),
    MOBILIDADE("Mobilidade & Transportes", "directions_car");

    val label: String get() = title
}

data class ServiceProviderItem(
    val id: String,
    val category: ServiceCategoryType,
    val name: String,
    val entityCode: String,
    val placeholderRef: String,
    val referenceLabel: String,
    val isFixedAmount: Boolean = false,
    val fixedAmount: Double? = null,
    val description: String = ""
)
