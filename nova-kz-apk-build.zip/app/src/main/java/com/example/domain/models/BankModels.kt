package com.example.domain.models

data class BankAccount(
    val id: String,
    val bankName: String,
    val iban: String,
    val accountNumber: String,
    val accountType: String, // Corrente, Poupança, Salário
    val currency: String = "AOA",
    val balance: Double,
    val isPrimary: Boolean = false
)

enum class CardStatus(val label: String) {
    ACTIVE("Ativo"),
    BLOCKED("Bloqueado"),
    EXPIRED("Expirado")
}

data class CardItem(
    val id: String,
    val friendlyName: String,
    val brand: String, // Multicaixa, Visa, Mastercard
    val last4Digits: String,
    val expiryDate: String, // MM/AA
    val status: CardStatus = CardStatus.ACTIVE,
    val isVirtual: Boolean = false,
    val dailyLimitAoa: Double = 500_000.0
)
