package com.example.domain.models

data class CreditProposal(
    val id: String,
    val title: String,
    val requestedAmount: Double,
    val approvedAmount: Double,
    val termMonths: Int,
    val interestRateMonthly: Double,
    val installmentAmount: Double,
    val status: String, // EM_ANALISE, APROVADO, ATIVO, LIQUIDADO
    val isSandbox: Boolean = true
)

data class SavingsGoal(
    val id: String,
    val name: String,
    val targetAmount: Double,
    val currentAmount: Double,
    val deadline: String,
    val category: String,
    val isAutoDepositActive: Boolean = false
)
