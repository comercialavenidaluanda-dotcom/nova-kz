package com.example.domain.models

import java.util.UUID

enum class PaymentType(val label: String) {
    TRANSFER("Transferência"),
    SERVICE_PAYMENT("Pagamento de Serviço"),
    RUPE("RUPE - Estado"),
    TELECOM("Telecomunicações"),
    WATER("Água"),
    ENERGY("Energia"),
    INSURANCE("Seguros"),
    CREDIT_INSTALLMENT("Prestação de Crédito"),
    SAVINGS_DEPOSIT("Depósito Poupança")
}

enum class PaymentStatus(val label: String) {
    DRAFT("Rascunho"),
    VALIDATED("Validado"),
    PENDING_AUTHORIZATION("Aguardando Autorização"),
    AUTHORIZED("Autorizado"),
    PROCESSING("Processando"),
    CONFIRMED("Confirmado"),
    FAILED("Falhou"),
    CANCELLED("Cancelado"),
    REJECTED("Rejeitado");

    fun isTerminal(): Boolean = this in listOf(CONFIRMED, FAILED, CANCELLED, REJECTED)

    fun canTransitionTo(target: PaymentStatus): Boolean {
        if (this == target) return true
        if (isTerminal()) return false

        return when (this) {
            DRAFT -> target in listOf(VALIDATED, PENDING_AUTHORIZATION, CANCELLED, REJECTED)
            VALIDATED -> target in listOf(PENDING_AUTHORIZATION, CANCELLED, REJECTED)
            PENDING_AUTHORIZATION -> target in listOf(AUTHORIZED, CANCELLED, REJECTED, FAILED)
            AUTHORIZED -> target in listOf(PROCESSING, CONFIRMED, FAILED, CANCELLED, REJECTED)
            PROCESSING -> target in listOf(CONFIRMED, FAILED, REJECTED)
            CONFIRMED, FAILED, CANCELLED, REJECTED -> false
        }
    }
}

enum class AuthMethod(val label: String, val description: String) {
    APP("NOVA KZ App", "Autorização instantânea através do aplicativo (Recomendado para Sandbox)"),
    MCX_EXPRESS("Multicaixa Express", "Confirmação via notificação MCX Express"),
    OTP("SMS / OTP", "Código numérico temporário enviado por SMS"),
    THREE_DS("3D Secure", "Autenticação adicional segura para cartões"),
    BANK("Internet Banking", "Validação no portal da instituição bancária"),
    OTHER("Outro Método", "Validação através de token de segurança externo")
}

data class PaymentOperation(
    val id: String = UUID.randomUUID().toString(),
    val idempotencyKey: String = UUID.randomUUID().toString(),
    val type: PaymentType,
    val amount: Double,
    val currency: String = "AOA",
    val beneficiary: String,
    val beneficiaryAccount: String? = null,
    val reference: String? = null,
    val description: String,
    val status: PaymentStatus = PaymentStatus.DRAFT,
    val authMethod: AuthMethod = AuthMethod.APP,
    val environment: String = "SANDBOX",
    val createdAt: String = "",
    val completedAt: String? = null,
    val fee: Double = 0.0,
    val transactionId: String = "NKZ-" + System.currentTimeMillis().toString().takeLast(8),
    val failureReason: String? = null
)
