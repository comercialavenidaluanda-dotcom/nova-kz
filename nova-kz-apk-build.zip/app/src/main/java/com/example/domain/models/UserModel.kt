package com.example.domain.models

data class UserProfile(
    val id: String,
    val name: String,
    val email: String,
    val phone: String,
    val nif: String,
    val kycLevel: String = "Nível 2 (Verificado)",
    val isSandboxMode: Boolean = true,
    val biometricsEnabled: Boolean = false,
    val appPinConfigured: Boolean = true,
    val inactivityTimeoutMinutes: Int = 3
)
