package com.example.domain.models

import java.util.UUID

enum class NotificationCategory(val title: String) {
    TRANSFER_DONE("Transferência efetuada"),
    PAYMENT_DONE("Pagamento efetuado"),
    VALUE_RECEIVED("Valor recebido"),
    PAYMENT_PENDING("Pagamento pendente"),
    PAYMENT_FAILED("Pagamento falhou"),
    NEW_AUTHORIZATION("Nova autorização"),
    INSURANCE("Seguro"),
    ACCOUNT_SECURITY("Segurança da conta")
}

data class NovaNotification(
    val id: String = UUID.randomUUID().toString(),
    val category: NotificationCategory,
    val title: String,
    val body: String,
    val amount: Double? = null,
    val currency: String = "AOA",
    val reference: String? = null,
    val operationId: String? = null,
    val timestamp: String,
    val isRead: Boolean = false,
    val actionDeepLink: String? = null
)
