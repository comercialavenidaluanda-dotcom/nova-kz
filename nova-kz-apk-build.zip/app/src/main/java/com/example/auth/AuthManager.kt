package com.example.auth

import android.content.Context
import com.example.data.LocalDataStore
import com.example.domain.models.UserProfile
import com.example.network.NetworkResult
import com.example.network.SupabaseRestClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject

class AuthManager(
    private val dataStore: LocalDataStore,
    private val restClient: SupabaseRestClient,
    private val onFcmDeactivate: (suspend (String) -> Unit)? = null
) {
    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    init {
        // Check if there is an existing session
        if (dataStore.authToken != null) {
            _currentUser.value = loadSavedProfile()
            _isAuthenticated.value = true
        }
    }

    private fun loadSavedProfile(): UserProfile {
        return UserProfile(
            id = dataStore.userId,
            name = dataStore.userName,
            email = dataStore.userEmail,
            phone = dataStore.userPhone,
            nif = "005928172LA041",
            kycLevel = "Nível 2 (Verificado)",
            isSandboxMode = true,
            biometricsEnabled = dataStore.isBiometricsEnabled,
            appPinConfigured = dataStore.hasAppPin(),
            inactivityTimeoutMinutes = dataStore.inactivityTimeoutMinutes
        )
    }

    suspend fun login(email: String, pinOrPassword: String): NetworkResult<UserProfile> {
        if (email.isBlank() || pinOrPassword.isBlank()) {
            return NetworkResult.Error("Preencha o e-mail e a palavra-passe ou PIN.")
        }

        val dummyToken = "sb_session_" + System.currentTimeMillis()
        dataStore.authToken = dummyToken
        dataStore.userEmail = email

        val profile = UserProfile(
            id = dataStore.userId,
            name = if (dataStore.userName.isNotBlank()) dataStore.userName else "Utilizador NOVA KZ",
            email = email,
            phone = dataStore.userPhone,
            nif = "005928172LA041",
            isSandboxMode = true,
            biometricsEnabled = dataStore.isBiometricsEnabled,
            appPinConfigured = dataStore.hasAppPin(),
            inactivityTimeoutMinutes = dataStore.inactivityTimeoutMinutes
        )

        _currentUser.value = profile
        _isAuthenticated.value = true

        dataStore.fcmToken?.let { token ->
            restClient.upsertDeviceToken(profile.id, token, "android")
        }

        return NetworkResult.Success(profile)
    }

    fun loginWithBiometrics(): Boolean {
        if (dataStore.authToken == null) {
            dataStore.authToken = "sb_session_" + System.currentTimeMillis()
            dataStore.isBiometricsEnabled = true
        }
        _currentUser.value = loadSavedProfile()
        _isAuthenticated.value = true
        return true
    }

    suspend fun register(
        name: String,
        email: String,
        phone: String,
        nif: String,
        pin: String
    ): NetworkResult<UserProfile> {
        if (name.isBlank() || email.isBlank() || phone.isBlank() || pin.length < 4) {
            return NetworkResult.Error("Por favor, preencha todos os campos obrigatórios (PIN mínimo 4 dígitos).")
        }

        dataStore.userName = name
        dataStore.userEmail = email
        dataStore.userPhone = phone
        dataStore.setAppPin(pin)
        dataStore.authToken = "sb_session_" + System.currentTimeMillis()

        val profile = UserProfile(
            id = dataStore.userId,
            name = name,
            email = email,
            phone = phone,
            nif = nif.ifBlank { "005928172LA041" },
            isSandboxMode = true,
            biometricsEnabled = false,
            appPinConfigured = true,
            inactivityTimeoutMinutes = 3
        )

        _currentUser.value = profile
        _isAuthenticated.value = true

        dataStore.fcmToken?.let { token ->
            restClient.upsertDeviceToken(profile.id, token, "android")
        }

        return NetworkResult.Success(profile)
    }

    suspend fun recoverAccess(identifier: String): NetworkResult<String> {
        if (identifier.isBlank()) {
            return NetworkResult.Error("Introduza o seu e-mail ou número de telefone registado.")
        }
        return NetworkResult.Success(
            "Enviámos instruções seguras para recuperação de acesso para $identifier. Verifique também o seu SMS/Email."
        )
    }

    fun logout() {
        val currentToken = dataStore.fcmToken
        if (currentToken != null) {
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    restClient.deactivateDeviceToken(currentToken)
                    onFcmDeactivate?.invoke(currentToken)
                } catch (e: Exception) {
                    // Ignore failure on logout
                }
            }
        }
        dataStore.clearSession()
        _currentUser.value = null
        _isAuthenticated.value = false
    }

    fun updateProfile(updated: UserProfile) {
        _currentUser.value = updated
        dataStore.userName = updated.name
        dataStore.userEmail = updated.email
        dataStore.userPhone = updated.phone
        dataStore.isBiometricsEnabled = updated.biometricsEnabled
        dataStore.inactivityTimeoutMinutes = updated.inactivityTimeoutMinutes
    }
}
