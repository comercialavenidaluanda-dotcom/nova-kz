package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.rememberNavController
import com.example.security.BiometricHelper
import com.example.ui.navigation.NavRoutes
import com.example.ui.navigation.NovaNavHost
import com.example.ui.theme.NovaKzTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {

    private lateinit var app: NovaKzApplication

    private val requestNotificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                app.syncDeviceToken()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = application as NovaKzApplication

        enableEdgeToEdge()
        requestPermissionsIfNeeded()
        startInactivityMonitor()

        setContent {
            NovaKzTheme {
                val navController = rememberNavController()

                // Check for incoming intent with operationId
                intent?.let { handleIntent(it, navController) }

                NovaNavHost(
                    navController = navController,
                    app = app,
                    onBiometricAuthRequested = { onSuccess ->
                        if (BiometricHelper.isBiometricAvailable(this)) {
                            BiometricHelper.showBiometricPrompt(
                                activity = this,
                                onSuccess = onSuccess,
                                onError = { errorMsg ->
                                    Toast.makeText(this, errorMsg, Toast.LENGTH_SHORT).show()
                                }
                            )
                        } else {
                            Toast.makeText(
                                this,
                                "Biometria não configurada no dispositivo. Utilize o seu PIN.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        app.securityManager.notifyUserInteraction()
    }

    private fun handleIntent(intent: Intent, navController: androidx.navigation.NavController) {
        val operationIdExtra = intent.getStringExtra("operationId")
        if (!operationIdExtra.isNullOrBlank()) {
            navController.navigate(NavRoutes.receiptRoute(operationIdExtra))
            return
        }
        val dataUri = intent.data
        if (dataUri != null && dataUri.scheme == "novakz") {
            val opId = dataUri.getQueryParameter("id")
            if (!opId.isNullOrBlank()) {
                if (dataUri.host == "operation") {
                    navController.navigate(NavRoutes.authorizeRoute(opId))
                } else if (dataUri.host == "receipt") {
                    navController.navigate(NavRoutes.receiptRoute(opId))
                }
            }
        }
    }

    private fun startInactivityMonitor() {
        lifecycleScope.launch {
            while (isActive) {
                delay(15000) // check every 15s
                app.securityManager.checkInactivityLock()
            }
        }
    }

    private fun requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val permission = Manifest.permission.POST_NOTIFICATIONS
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermissionLauncher.launch(permission)
            } else {
                app.syncDeviceToken()
            }
        } else {
            app.syncDeviceToken()
        }
    }
}
