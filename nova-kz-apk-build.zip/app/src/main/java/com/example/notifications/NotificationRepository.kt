package com.example.notifications

import com.example.domain.models.NotificationCategory
import com.example.domain.models.NovaNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotificationRepository {

    private val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "AO"))

    private val _notifications = MutableStateFlow<List<NovaNotification>>(emptyList())
    val notifications: StateFlow<List<NovaNotification>> = _notifications.asStateFlow()

    init {
        loadDefaultNotifications()
    }

    private fun loadDefaultNotifications() {
        val now = System.currentTimeMillis()
        _notifications.value = listOf(
            NovaNotification(
                category = NotificationCategory.NEW_AUTHORIZATION,
                title = "Nova autorização pendente",
                body = "Tem uma transferência de 200,00 AOA a aguardar a sua autorização no aplicativo.",
                amount = 200.0,
                reference = "NKZ-99381023",
                operationId = "op_init_02",
                timestamp = dateFormat.format(Date(now - 1000L * 60 * 20)),
                isRead = false,
                actionDeepLink = "novakz://operation?id=op_init_02"
            ),
            NovaNotification(
                category = NotificationCategory.TRANSFER_DONE,
                title = "Transferência efetuada com sucesso",
                body = "A transferência para António Kwanza no valor de 200,00 AOA foi concluída com sucesso.",
                amount = 200.0,
                reference = "TRF-882193",
                operationId = "op_init_01",
                timestamp = dateFormat.format(Date(now - 1000L * 60 * 120)),
                isRead = false
            ),
            NovaNotification(
                category = NotificationCategory.PAYMENT_DONE,
                title = "Pagamento efetuado",
                body = "Pagamento de fatura ENDE - Energia Pré-pago validado no valor de 150,00 AOA.",
                amount = 150.0,
                reference = "1002938491",
                timestamp = dateFormat.format(Date(now - 1000L * 60 * 360)),
                isRead = true
            ),
            NovaNotification(
                category = NotificationCategory.VALUE_RECEIVED,
                title = "Valor recebido na conta",
                body = "Foi creditado o valor de 500,00 AOA por via de Multicaixa Express.",
                amount = 500.0,
                reference = "CRD-948102",
                timestamp = dateFormat.format(Date(now - 86400000L)),
                isRead = true
            ),
            NovaNotification(
                category = NotificationCategory.INSURANCE,
                title = "Cotação de Seguro Disponível",
                body = "A sua simulação de Seguro Automóvel pela NOSSA Seguros está pronta para consulta em Sandbox.",
                amount = 45000.0,
                reference = "SEG-482019",
                timestamp = dateFormat.format(Date(now - 86400000L * 2)),
                isRead = true
            ),
            NovaNotification(
                category = NotificationCategory.ACCOUNT_SECURITY,
                title = "Segurança da conta",
                body = "Novo início de sessão registado com sucesso no dispositivo Android nativo.",
                timestamp = dateFormat.format(Date(now - 86400000L * 3)),
                isRead = true
            )
        )
    }

    fun markAsRead(id: String) {
        _notifications.value = _notifications.value.map {
            if (it.id == id) it.copy(isRead = true) else it
        }
    }

    fun markAllAsRead() {
        _notifications.value = _notifications.value.map { it.copy(isRead = true) }
    }

    fun addNotification(notification: NovaNotification) {
        _notifications.value = listOf(notification) + _notifications.value
    }
}
