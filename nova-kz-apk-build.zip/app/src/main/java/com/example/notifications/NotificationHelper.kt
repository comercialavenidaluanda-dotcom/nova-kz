package com.example.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.domain.models.NotificationCategory
import com.example.domain.models.NovaNotification
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object NotificationHelper {

    const val FINANCIAL_CHANNEL_ID = "nova_kz_financial_channel"
    const val SECURITY_CHANNEL_ID = "nova_kz_security_channel"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val financialChannel = NotificationChannel(
                FINANCIAL_CHANNEL_ID,
                "NOVA KZ Transações e Pagamentos",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notificações sobre transferências, pagamentos, autorizações e valores recebidos"
                enableLights(true)
                enableVibration(true)
            }

            val securityChannel = NotificationChannel(
                SECURITY_CHANNEL_ID,
                "NOVA KZ Segurança & Conta",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alertas de segurança, novo acesso e dispositivos autorizados"
                enableLights(true)
            }

            notificationManager.createNotificationChannel(financialChannel)
            notificationManager.createNotificationChannel(securityChannel)
        }
    }

    fun showSystemNotification(
        context: Context,
        title: String,
        body: String,
        category: NotificationCategory = NotificationCategory.PAYMENT_DONE,
        amount: Double? = null,
        reference: String? = null,
        operationId: String? = null
    ) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Create deep link intent
        val deepLinkIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (!operationId.isNullOrBlank()) {
                data = Uri.parse("novakz://operation?id=$operationId")
                putExtra("operationId", operationId)
            } else {
                data = Uri.parse("novakz://notifications")
            }
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            System.currentTimeMillis().toInt(),
            deepLinkIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Format body with amount and reference when available
        val enrichedBody = buildString {
            append(body)
            if (amount != null && amount > 0) {
                append("\nValor: ${String.format(Locale("pt", "AO"), "%,.2f", amount)} AOA")
            }
            if (!reference.isNullOrBlank()) {
                append("\nRef: $reference")
            }
        }

        val channelId = if (category == NotificationCategory.ACCOUNT_SECURITY) {
            SECURITY_CHANNEL_ID
        } else {
            FINANCIAL_CHANNEL_ID
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(enrichedBody))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify((System.currentTimeMillis() % 10000).toInt(), notification)
    }
}
