package com.example

import android.app.Application
import android.util.Log
import com.example.auth.AuthManager
import com.example.data.LocalDataStore
import com.example.data.local.NovaKzDatabase
import com.example.data.repository.PaymentTransactionRepository
import com.example.insurance.InsuranceRepository
import com.example.network.SupabaseRestClient
import com.example.notifications.DeviceTokenManager
import com.example.notifications.NotificationHelper
import com.example.notifications.NotificationRepository
import com.example.payments.PaymentManager
import com.example.security.SecurityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class NovaKzApplication : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var database: NovaKzDatabase
        private set

    lateinit var paymentTransactionRepository: PaymentTransactionRepository
        private set

    lateinit var dataStore: LocalDataStore
        private set

    lateinit var securityManager: SecurityManager
        private set

    lateinit var restClient: SupabaseRestClient
        private set

    lateinit var authManager: AuthManager
        private set

    lateinit var paymentManager: PaymentManager
        private set

    lateinit var notificationRepository: NotificationRepository
        private set

    lateinit var insuranceRepository: InsuranceRepository
        private set

    lateinit var deviceTokenManager: DeviceTokenManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        Log.d(TAG, "Starting NOVA KZ Native Android Application (ao.novakz.app)...")

        dataStore = LocalDataStore(this)
        securityManager = SecurityManager(this, dataStore)
        restClient = SupabaseRestClient(getAuthToken = { dataStore.authToken })
        authManager = AuthManager(dataStore, restClient)

        // Initialize Room local database and repository
        database = NovaKzDatabase.getDatabase(this)
        paymentTransactionRepository = PaymentTransactionRepository(
            transactionDao = database.paymentTransactionDao(),
            restClient = restClient
        )

        paymentManager = PaymentManager(
            dataStore = dataStore,
            restClient = restClient,
            transactionRepository = paymentTransactionRepository,
            scope = applicationScope
        )

        notificationRepository = NotificationRepository()
        insuranceRepository = InsuranceRepository(restClient)
        deviceTokenManager = DeviceTokenManager(dataStore, restClient, applicationScope)

        // Initialize notification channels for Android 8.0+
        NotificationHelper.createNotificationChannels(this)

        // Trigger background sync with Supabase
        applicationScope.launch {
            paymentManager.loadMyPaymentOperations()
        }
    }

    fun syncDeviceToken() {
        val userId = dataStore.userId.ifBlank { "user_sandbox_01" }
        deviceTokenManager.syncCurrentTokenWithUser(userId)
    }

    companion object {
        private const val TAG = "NovaKzApp"
        lateinit var instance: NovaKzApplication
            private set
    }
}
