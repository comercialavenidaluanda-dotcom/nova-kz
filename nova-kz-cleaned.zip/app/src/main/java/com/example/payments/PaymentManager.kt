package com.example.payments

import android.util.Log
import com.example.data.LocalDataStore
import com.example.data.repository.PaymentTransactionRepository
import com.example.domain.models.AngolaBankProvider
import com.example.domain.models.AngolaBanksCatalog
import com.example.domain.models.AuthMethod
import com.example.domain.models.BankAccount
import com.example.domain.models.BankTransferSubMethod
import com.example.domain.models.CardItem
import com.example.domain.models.CardStatus
import com.example.domain.models.IntegrationAvailabilityStatus
import com.example.domain.models.NovaLookupSubMethod
import com.example.domain.models.NovaRecipient
import com.example.domain.models.PaymentOperation
import com.example.domain.models.PaymentStatus
import com.example.domain.models.PaymentType
import com.example.domain.models.PhoneUtils
import com.example.network.NetworkResult
import com.example.network.SupabaseEndpoints
import com.example.network.SupabaseRestClient
import com.example.services.ServicesCatalog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class SandboxBalanceUiState(
    val balance: Double? = null,
    val cachedBalance: Double? = null,
    val isLoading: Boolean = false,
    val syncError: String? = null,
    val walletInitialized: Boolean = true,
    val lastSyncedAtMs: Long? = null
)

class PaymentManager(
    private val dataStore: LocalDataStore,
    private val restClient: SupabaseRestClient,
    private val transactionRepository: PaymentTransactionRepository? = null,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
) {
    private val executionMutex = Mutex()
    private val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "AO"))

    private val _operations = MutableStateFlow<List<PaymentOperation>>(emptyList())
    val operations: StateFlow<List<PaymentOperation>> = _operations.asStateFlow()

    private val _bankAccounts = MutableStateFlow<List<BankAccount>>(emptyList())
    val bankAccounts: StateFlow<List<BankAccount>> = _bankAccounts.asStateFlow()

    private val _cards = MutableStateFlow<List<CardItem>>(emptyList())
    val cards: StateFlow<List<CardItem>> = _cards.asStateFlow()

    private val _balanceUiState = MutableStateFlow(
        SandboxBalanceUiState(
            balance = null,
            cachedBalance = dataStore.getCachedSandboxBalance(),
            isLoading = false,
            syncError = null,
            walletInitialized = true
        )
    )
    val balanceUiState: StateFlow<SandboxBalanceUiState> = _balanceUiState.asStateFlow()

    // Never defaults to 1000.0; uses visual cache if present or 0.0 until loadSandboxBalance() completes
    private val _sandboxBalance = MutableStateFlow(dataStore.getCachedSandboxBalance() ?: 0.0)
    val sandboxBalance: StateFlow<Double> = _sandboxBalance.asStateFlow()

    fun setSandboxBalance(balance: Double) {
        applyBackendVerifiedBalance(
            userId = dataStore.userId,
            balance = balance,
            walletInitialized = true
        )
    }

    private val _pendingAuthorizations = MutableStateFlow<List<PaymentOperation>>(emptyList())
    val pendingAuthorizations: StateFlow<List<PaymentOperation>> = _pendingAuthorizations.asStateFlow()

    init {
        loadInitialData()
    }

    private fun loadInitialData() {
        val initialVisualBalance = dataStore.getCachedSandboxBalance() ?: 0.0

        // Initial Sandbox accounts (primary account balance is synchronized from Supabase RPC)
        _bankAccounts.value = listOf(
            BankAccount(
                id = "acc_01",
                bankName = "Banco Angolano de Investimentos (BAI)",
                iban = "AO06.0040.0000.8291.0291.1012.3",
                accountNumber = "82910291101",
                accountType = "Conta Corrente",
                currency = "AOA",
                balance = initialVisualBalance,
                isPrimary = true
            ),
            BankAccount(
                id = "acc_02",
                bankName = "Banco de Fomento Angola (BFA)",
                iban = "AO06.0006.0000.1928.3746.5019.2",
                accountNumber = "19283746501",
                accountType = "Conta Ordem",
                currency = "AOA",
                balance = 250000.0,
                isPrimary = false
            ),
            BankAccount(
                id = "acc_03",
                bankName = "Banco Millennium Atlântico (BMA)",
                iban = "AO06.0055.0000.4433.2211.9087.1",
                accountNumber = "44332211908",
                accountType = "Conta Poupança",
                currency = "AOA",
                balance = 50000.0,
                isPrimary = false
            )
        )

        // Initial Cards (strictly compliant with security rule: brand, last 4 digits, status, friendly name only)
        _cards.value = listOf(
            CardItem(
                id = "crd_01",
                friendlyName = "Multicaixa Débito BAI",
                brand = "Multicaixa",
                last4Digits = "8492",
                expiryDate = "08/28",
                status = CardStatus.ACTIVE,
                isVirtual = false,
                dailyLimitAoa = 500000.0
            ),
            CardItem(
                id = "crd_02",
                friendlyName = "Cartão Virtual Compras Online",
                brand = "Visa",
                last4Digits = "1934",
                expiryDate = "12/26",
                status = CardStatus.ACTIVE,
                isVirtual = true,
                dailyLimitAoa = 150000.0
            )
        )

        // Production build: no synthetic/pending sandbox operations are seeded.
        _operations.value = emptyList()
        updatePendingAuthorizations()

        // Room database persistence observation (visual cache only for balance; never source of truth)
        transactionRepository?.let { repo ->
            scope.launch {
                val roomVisualCached = repo.getVisualCachedBalance(dataStore.userId)
                if (roomVisualCached != null && _balanceUiState.value.balance == null) {
                    _balanceUiState.value = _balanceUiState.value.copy(cachedBalance = roomVisualCached)
                    _sandboxBalance.value = roomVisualCached
                }
            }
            scope.launch {
                repo.allTransactions.collect { cachedList ->
                    if (cachedList.isNotEmpty()) {
                        val currentMap = _operations.value.associateBy { it.id }
                        val mergedFromCache = cachedList.map { cachedOp ->
                            val existing = currentMap[cachedOp.id]
                            if (existing != null && statusRank(existing.status) >= statusRank(cachedOp.status)) {
                                existing
                            } else {
                                cachedOp
                            }
                        }
                        val cachedIds = cachedList.map { it.id }.toSet()
                        val pendingInMemory = _operations.value.filter { it.id !in cachedIds }
                        _operations.value = pendingInMemory + mergedFromCache
                        updatePendingAuthorizations()
                    }
                }
            }
            scope.launch {
                if (repo.getTransactionCount() == 0) {
                    repo.saveTransactions(initialList)
                }
            }
        }
    }

    private fun statusRank(status: PaymentStatus): Int = when (status) {
        PaymentStatus.DRAFT -> 0
        PaymentStatus.VALIDATED -> 1
        PaymentStatus.PENDING_AUTHORIZATION -> 2
        PaymentStatus.AUTHORIZED -> 3
        PaymentStatus.PROCESSING -> 4
        PaymentStatus.CONFIRMED, PaymentStatus.FAILED, PaymentStatus.REJECTED, PaymentStatus.CANCELLED -> 5
    }

    private fun anonymizeUserId(userId: String?): String {
        val clean = userId?.trim().orEmpty()
        if (clean.isEmpty()) return "none"
        return if (clean.length <= 6) "***${clean.takeLast(3)}" else "***${clean.takeLast(6)}"
    }

    private fun applyBackendVerifiedBalance(
        userId: String,
        balance: Double,
        walletInitialized: Boolean = true
    ) {
        _sandboxBalance.value = balance
        _balanceUiState.value = SandboxBalanceUiState(
            balance = balance,
            cachedBalance = balance,
            isLoading = false,
            syncError = null,
            walletInitialized = walletInitialized,
            lastSyncedAtMs = System.currentTimeMillis()
        )
        _bankAccounts.value = _bankAccounts.value.map { account ->
            if (account.isPrimary) account.copy(balance = balance) else account
        }
        dataStore.setCachedSandboxBalance(balance, userId)
        scope.launch {
            try {
                transactionRepository?.saveVisualCachedBalance(userId, balance)
            } catch (e: Exception) {
                // Visual Room cache failure is non-fatal
            }
        }
    }

    private data class ParsedBalanceResult(
        val balance: Double? = null,
        val walletInitialized: Boolean = true,
        val error: String? = null
    )

    private fun parseSandboxBalanceResponse(rawResponse: String): ParsedBalanceResult {
        val raw = rawResponse.trim()
        if (raw.isEmpty() || raw.equals("null", ignoreCase = true)) {
            return ParsedBalanceResult(balance = 0.0, walletInitialized = false)
        }
        return try {
            when {
                raw.startsWith("{") -> {
                    val json = JSONObject(raw)
                    if (json.has("ok") && !json.optBoolean("ok", true)) {
                        val err = json.optString("error", json.optString("message", "")).trim()
                        if (err.contains("WALLET_NOT_FOUND", ignoreCase = true) ||
                            err.contains("NO_WALLET", ignoreCase = true) ||
                            err.contains("NOT_INITIALIZED", ignoreCase = true) ||
                            err.contains("NOT_FOUND", ignoreCase = true)
                        ) {
                            return ParsedBalanceResult(balance = 0.0, walletInitialized = false)
                        }
                        return ParsedBalanceResult(
                            error = err.ifBlank { "Erro ao obter saldo da wallet Sandbox no servidor." }
                        )
                    }

                    val initialized = json.optBoolean("wallet_initialized", json.optBoolean("exists", true))
                    val candidateKeys = listOf("balance", "new_balance", "sandbox_balance", "amount")
                    for (key in candidateKeys) {
                        if (json.has(key)) {
                            if (json.isNull(key)) {
                                return ParsedBalanceResult(balance = 0.0, walletInitialized = false)
                            }
                            val num = json.optString(key, "").toDoubleOrNull() ?: json.optDouble(key, Double.NaN)
                            if (!num.isNaN()) {
                                return ParsedBalanceResult(balance = num, walletInitialized = initialized)
                            }
                        }
                    }
                    if (!initialized) {
                        ParsedBalanceResult(balance = 0.0, walletInitialized = false)
                    } else {
                        ParsedBalanceResult(error = "Resposta do servidor não contém o campo balance.")
                    }
                }
                raw.startsWith("[") -> {
                    val arr = JSONArray(raw)
                    if (arr.length() == 0) {
                        ParsedBalanceResult(balance = 0.0, walletInitialized = false)
                    } else {
                        val firstObj = arr.optJSONObject(0)
                        if (firstObj != null) {
                            parseSandboxBalanceResponse(firstObj.toString())
                        } else {
                            val scalar = arr.optString(0, "").trim('"').toDoubleOrNull()
                            if (scalar != null) {
                                ParsedBalanceResult(balance = scalar, walletInitialized = true)
                            } else {
                                ParsedBalanceResult(error = "Formato de saldo inválido retornado pela RPC.")
                            }
                        }
                    }
                }
                else -> {
                    val scalar = raw.trim('"').toDoubleOrNull()
                    if (scalar != null) {
                        ParsedBalanceResult(balance = scalar, walletInitialized = true)
                    } else {
                        ParsedBalanceResult(error = "Formato de saldo inválido retornado pela RPC.")
                    }
                }
            }
        } catch (e: Exception) {
            ParsedBalanceResult(error = "Erro ao interpretar saldo do servidor: ${e.message}")
        }
    }

    /**
     * Single source of truth for loading the user's Sandbox balance from Supabase RPC:
     * `public.nova_kz_get_sandbox_balance()` -> `bankbot.get_my_sandbox_balance()`.
     *
     * Rules:
     * 1. Verifies authenticated session;
     * 2. Obtains authenticated user;
     * 3. Calls `supabase.rpc("nova_kz_get_sandbox_balance")`;
     * 4. Validates the response;
     * 5. Extracts `balance` (or 0.0 / uninitialized if no wallet exists on backend);
     * 6. Updates UI state;
     * 7. Updates Room only as visual cache;
     * 8. Never uses local cache to replace the backend or defaults to 1.000,00 AOA.
     */
    suspend fun loadSandboxBalance(): NetworkResult<Double> {
        val currentUserId = dataStore.userId.trim()
        if (!dataStore.hasActiveSession() && restClient.rpcHandler == null) {
            val errMsg = "Sessão não autenticada. Inicie sessão para sincronizar o saldo."
            _balanceUiState.value = _balanceUiState.value.copy(
                isLoading = false,
                syncError = errMsg
            )
            Log.d(TAG, "SandboxBalanceSync [user=none, rpcBalance=none, status=UNAUTHENTICATED]")
            return NetworkResult.Error(errMsg, code = 401)
        }

        if (currentUserId.isBlank()) {
            val errMsg = "Utilizador autenticado não identificado."
            _balanceUiState.value = _balanceUiState.value.copy(
                isLoading = false,
                syncError = errMsg
            )
            Log.d(TAG, "SandboxBalanceSync [user=none, rpcBalance=none, status=INVALID_USER]")
            return NetworkResult.Error(errMsg, code = 401)
        }

        val visualCache = try {
            transactionRepository?.getVisualCachedBalance(currentUserId)
                ?: dataStore.getCachedSandboxBalance(currentUserId)
        } catch (e: Exception) {
            dataStore.getCachedSandboxBalance(currentUserId)
        }

        _balanceUiState.value = _balanceUiState.value.copy(
            cachedBalance = visualCache,
            isLoading = true,
            syncError = null
        )

        // Refresh expired JWT token if refresh token is available
        val currentToken = dataStore.authToken
        val currentRefresh = dataStore.refreshToken
        if ((currentToken.isNullOrBlank() || dataStore.isTokenExpired()) &&
            !currentRefresh.isNullOrBlank() &&
            !currentRefresh.startsWith("nkz_sandbox_")
        ) {
            restClient.refreshSession(currentRefresh)
        }

        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_GET_SANDBOX_BALANCE, JSONObject())
        return when (rpcResult) {
            is NetworkResult.Success -> {
                val parsed = parseSandboxBalanceResponse(rpcResult.data)
                if (parsed.error != null) {
                    _balanceUiState.value = _balanceUiState.value.copy(
                        isLoading = false,
                        syncError = parsed.error
                    )
                    Log.d(
                        TAG,
                        "SandboxBalanceSync [user=${anonymizeUserId(currentUserId)}, rpcBalance=error, status=PARSE_ERROR]"
                    )
                    NetworkResult.Error(parsed.error)
                } else {
                    val confirmedBalance = parsed.balance ?: 0.0
                    applyBackendVerifiedBalance(
                        userId = currentUserId,
                        balance = confirmedBalance,
                        walletInitialized = parsed.walletInitialized
                    )
                    Log.d(
                        TAG,
                        "SandboxBalanceSync [user=${anonymizeUserId(currentUserId)}, rpcBalance=$confirmedBalance, status=${if (parsed.walletInitialized) "COMPLETED" else "WALLET_UNINITIALIZED"}]"
                    )
                    NetworkResult.Success(confirmedBalance)
                }
            }
            is NetworkResult.Error -> {
                val syncErrMsg = rpcResult.message.ifBlank {
                    "Erro de sincronização ao consultar o saldo no Supabase."
                }
                _balanceUiState.value = _balanceUiState.value.copy(
                    isLoading = false,
                    syncError = syncErrMsg
                )
                Log.d(
                    TAG,
                    "SandboxBalanceSync [user=${anonymizeUserId(currentUserId)}, rpcBalance=error, status=RPC_ERROR_${rpcResult.code}]"
                )
                NetworkResult.Error(
                    syncErrMsg,
                    code = rpcResult.code,
                    isNetworkError = rpcResult.isNetworkError,
                    isSessionExpired = rpcResult.isSessionExpired
                )
            }
        }
    }

    private fun updatePendingAuthorizations() {
        _pendingAuthorizations.value = _operations.value.filter {
            it.status == PaymentStatus.PENDING_AUTHORIZATION
        }
    }

    // Step 1: CRIAR & VALIDAR
    suspend fun createPaymentOperation(
        type: PaymentType,
        amount: Double,
        beneficiary: String,
        description: String,
        reference: String? = null,
        beneficiaryAccount: String? = null,
        authMethod: AuthMethod = AuthMethod.APP,
        idempotencyKey: String? = null
    ): NetworkResult<PaymentOperation> {
        // Pre-validation
        if (amount <= 0) {
            return NetworkResult.Error("O valor do pagamento deve ser superior a 0,00 AOA.")
        }
        if (beneficiary.isBlank()) {
            return NetworkResult.Error("Indique o beneficiário ou entidade de destino.")
        }

        val effectiveIdempotencyKey = idempotencyKey ?: UUID.randomUUID().toString()

        // Idempotency check: if an operation with this idempotencyKey already exists, return it
        val existingOp = _operations.value.find { it.idempotencyKey == effectiveIdempotencyKey }
        if (existingOp != null) {
            Log.d(
                TAG,
                "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=${existingOp.id}, rpcBalance=${_sandboxBalance.value}, status=IDEMPOTENT_EXISTING]"
            )
            return NetworkResult.Success(existingOp)
        }

        val rpcParams = JSONObject().apply {
            put("p_amount", amount)
            put("p_beneficiary_account", beneficiaryAccount ?: "")
            put("p_beneficiary_name", beneficiary)
            put("p_currency", "AOA")
            put("p_description", description.ifBlank { type.label })
            put("p_idempotency_key", effectiveIdempotencyKey)
            put("p_operation_type", type.backendOperationType)
        }

        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_CREATE_PAYMENT, rpcParams)

        var operationId = UUID.randomUUID().toString()
        var operationReference = reference
        var operationStatus = PaymentStatus.PENDING_AUTHORIZATION

        if (rpcResult is NetworkResult.Success) {
            try {
                val raw = rpcResult.data.trim()
                if (raw.startsWith("{")) {
                    val json = JSONObject(raw)
                    if (json.has("ok") && !json.optBoolean("ok", true)) {
                        val err = json.optString("error", json.optString("message", "Não foi possível criar a operação no servidor."))
                        return NetworkResult.Error(err)
                    }
                    if (json.has("operation_id")) {
                        operationId = json.getString("operation_id")
                    } else if (json.has("id")) {
                        operationId = json.getString("id")
                    }
                    if (json.has("reference") && !json.isNull("reference")) {
                        operationReference = json.getString("reference")
                    }
                    val statusStr = json.optString("status", "")
                    if (statusStr.isNotBlank()) {
                        operationStatus = PaymentStatus.fromBackendString(statusStr)
                    }
                } else if (raw.isNotBlank() && !raw.startsWith("[")) {
                    operationId = raw.trim('"')
                }
            } catch (e: Exception) {
                Log.d(TAG, "Could not parse operation from create RPC: ${e.message}")
            }
        } else if (rpcResult is NetworkResult.Error) {
            Log.d(
                TAG,
                "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=none, rpcBalance=${_sandboxBalance.value}, status=CREATE_FAILED]"
            )
            return NetworkResult.Error(rpcResult.message, code = rpcResult.code, isNetworkError = rpcResult.isNetworkError)
        }

        val operation = PaymentOperation(
            id = operationId,
            idempotencyKey = effectiveIdempotencyKey,
            type = type,
            amount = amount,
            currency = "AOA",
            beneficiary = beneficiary,
            beneficiaryAccount = beneficiaryAccount,
            reference = operationReference,
            description = description.ifBlank { type.label },
            status = operationStatus,
            authMethod = authMethod,
            environment = "SANDBOX",
            createdAt = dateFormat.format(Date()),
            fee = 0.0,
            transactionId = "NKZ-" + System.currentTimeMillis().toString().takeLast(8)
        )

        // Progress to PENDING_AUTHORIZATION according to state machine
        val pendingOp = if (operation.status.canTransitionTo(PaymentStatus.PENDING_AUTHORIZATION)) {
            operation.copy(status = PaymentStatus.PENDING_AUTHORIZATION)
        } else {
            operation
        }
        _operations.value = listOf(pendingOp) + _operations.value
        updatePendingAuthorizations()
        transactionRepository?.saveOrUpdateTransaction(pendingOp)

        Log.d(
            TAG,
            "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=${pendingOp.id}, rpcBalance=${_sandboxBalance.value}, status=${pendingOp.status.name}]"
        )
        return NetworkResult.Success(pendingOp)
    }

    // Step 2: AUTORIZAR
    suspend fun authorizePaymentOperation(
        operationId: String,
        authMethod: AuthMethod = AuthMethod.APP,
        confirmationCode: String = ""
    ): NetworkResult<PaymentOperation> {
        val currentOp = _operations.value.find { it.id == operationId }
            ?: return NetworkResult.Error("Operação não encontrada.")

        // Strict State Machine Validation
        if (!currentOp.status.canTransitionTo(PaymentStatus.AUTHORIZED)) {
            return NetworkResult.Error("Transição de estado inválida: não é permitido transitar de ${currentOp.status.name} para AUTHORIZED.")
        }

        // Call RPC nova_kz_authorize_payment_operation with exact Supabase PostgreSQL signature
        val rpcParams = JSONObject().apply {
            put("p_method", authMethod.name)
            put("p_operation_id", operationId)
        }

        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_AUTHORIZE_PAYMENT, rpcParams)
        if (rpcResult is NetworkResult.Error) {
            Log.d(
                TAG,
                "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=$operationId, rpcBalance=${_sandboxBalance.value}, status=AUTHORIZE_FAILED]"
            )
            return NetworkResult.Error(rpcResult.message, code = rpcResult.code, isNetworkError = rpcResult.isNetworkError)
        }

        val authorizedOp = currentOp.copy(
            status = PaymentStatus.AUTHORIZED,
            authMethod = authMethod
        )

        updateOperationInList(authorizedOp)
        updatePendingAuthorizations()
        transactionRepository?.saveOrUpdateTransaction(authorizedOp)

        Log.d(
            TAG,
            "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=$operationId, rpcBalance=${_sandboxBalance.value}, status=AUTHORIZED]"
        )
        return NetworkResult.Success(authorizedOp)
    }

    // Step 3 & 4: PROCESSAR & CONFIRMAR COM PROTEÇÃO DE CONCORRÊNCIA E IDEMPOTÊNCIA
    suspend fun processAndConfirmPayment(
        operationId: String
    ): NetworkResult<PaymentOperation> = executionMutex.withLock {
        val currentOp = _operations.value.find { it.id == operationId }
            ?: return@withLock NetworkResult.Error("Operação não encontrada.")

        // Idempotency: if already confirmed, reject second execution and do NOT deduct again!
        if (currentOp.status == PaymentStatus.CONFIRMED) {
            Log.d(
                TAG,
                "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=$operationId, rpcBalance=${_sandboxBalance.value}, status=DUPLICATE_REJECTED]"
            )
            return@withLock NetworkResult.Error("Operação já confirmada (execução idempotente rejeitada). Nenhuma nova cobrança efetuada.")
        }

        // Strict state validation: must be authorized
        if (!currentOp.status.canTransitionTo(PaymentStatus.PROCESSING)) {
            return@withLock NetworkResult.Error("A operação não pode ser processada a partir do estado ${currentOp.status.label}.")
        }

        // Ensure we have synced balance from backend if not loaded yet
        if (_balanceUiState.value.balance == null && (dataStore.hasActiveSession() || restClient.rpcHandler != null)) {
            loadSandboxBalance()
        }

        // Check sandbox balance before sending to execution
        if (currentOp.amount > _sandboxBalance.value) {
            val failedOp = currentOp.copy(
                status = PaymentStatus.FAILED,
                failureReason = "Saldo Sandbox insuficiente para cobrir o valor de ${String.format(Locale("pt", "AO"), "%,.2f", currentOp.amount)} AOA."
            )
            updateOperationInList(failedOp)
            updatePendingAuthorizations()
            transactionRepository?.saveOrUpdateTransaction(failedOp)
            Log.d(
                TAG,
                "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=$operationId, rpcBalance=${_sandboxBalance.value}, status=INSUFFICIENT_FUNDS]"
            )
            return@withLock NetworkResult.Error(failedOp.failureReason ?: "Saldo insuficiente.")
        }

        // Transition to PROCESSING
        val processingOp = currentOp.copy(status = PaymentStatus.PROCESSING)
        updateOperationInList(processingOp)

        // Call Supabase RPC nova_kz_execute_sandbox_payment
        val executeParams = JSONObject().apply {
            put("p_operation_id", operationId)
        }
        val executeResult = restClient.invokeRpc(SupabaseEndpoints.RPC_EXECUTE_SANDBOX_PAYMENT, executeParams)

        if (executeResult is NetworkResult.Error) {
            // Se execução falhar:
            // - NÃO alterar saldo local;
            // - NÃO criar recibo de sucesso;
            // - NÃO inserir histórico como concluído.
            val failedOp = currentOp.copy(
                status = PaymentStatus.FAILED,
                failureReason = executeResult.message
            )
            updateOperationInList(failedOp)
            updatePendingAuthorizations()
            transactionRepository?.saveOrUpdateTransaction(failedOp)
            Log.d(
                TAG,
                "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=$operationId, rpcBalance=${_sandboxBalance.value}, status=EXECUTE_FAILED]"
            )
            return@withLock NetworkResult.Error(
                executeResult.message,
                code = executeResult.code,
                isNetworkError = executeResult.isNetworkError
            )
        }

        // Parse backend execute response: duplicate, new_balance, ok, status
        var isDuplicate = false
        var backendNewBalance: Double? = null
        var isCompletedOnBackend = true
        var backendErrorReason: String? = null

        if (executeResult is NetworkResult.Success) {
            try {
                val raw = executeResult.data.trim()
                if (raw.startsWith("{")) {
                    val json = JSONObject(raw)
                    if (json.has("ok") && !json.optBoolean("ok", true)) {
                        isCompletedOnBackend = false
                        backendErrorReason = json.optString("error", json.optString("message", "Execução recusada pelo backend."))
                    }
                    val statusField = json.optString("status", "COMPLETED").uppercase()
                    if (statusField in listOf("FAILED", "REJECTED", "CANCELLED", "ERROR")) {
                        isCompletedOnBackend = false
                        backendErrorReason = json.optString("message", "Operação retornou estado $statusField.")
                    } else if (statusField.isNotBlank() && statusField !in listOf("COMPLETED", "CONFIRMED", "SUCCESS", "OK")) {
                        isCompletedOnBackend = false
                        backendErrorReason = "Operação não concluída (estado: $statusField)."
                    }
                    isDuplicate = json.optBoolean("duplicate", false)
                    if (json.has("new_balance") && !json.isNull("new_balance")) {
                        backendNewBalance = json.optString("new_balance", "").toDoubleOrNull() ?: json.optDouble("new_balance")
                    } else if (json.has("balance") && !json.isNull("balance")) {
                        backendNewBalance = json.optString("balance", "").toDoubleOrNull() ?: json.optDouble("balance")
                    }
                } else if (raw.isNotBlank()) {
                    val scalar = raw.trim('"').toDoubleOrNull()
                    if (scalar != null) {
                        backendNewBalance = scalar
                    }
                }
            } catch (e: Exception) {
                isCompletedOnBackend = false
                backendErrorReason = "Resposta inválida ao executar pagamento: ${e.message}"
            }
        }

        if (!isCompletedOnBackend) {
            val failedOp = currentOp.copy(
                status = PaymentStatus.FAILED,
                failureReason = backendErrorReason ?: "Execução do pagamento não foi concluída pelo servidor."
            )
            updateOperationInList(failedOp)
            updatePendingAuthorizations()
            transactionRepository?.saveOrUpdateTransaction(failedOp)
            Log.d(
                TAG,
                "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=$operationId, rpcBalance=${_sandboxBalance.value}, status=FAILED]"
            )
            return@withLock NetworkResult.Error(failedOp.failureReason ?: "Falha na execução do pagamento.")
        }

        if (isDuplicate) {
            loadSandboxBalance()
            val confirmedDuplicate = currentOp.copy(status = PaymentStatus.CONFIRMED)
            Log.d(
                TAG,
                "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=$operationId, rpcBalance=${_sandboxBalance.value}, status=COMPLETED_DUPLICATE]"
            )
            return@withLock NetworkResult.Success(confirmedDuplicate)
        }

        // Call Supabase RPC nova_kz_transition_payment with exact signature
        val transitionParams = JSONObject().apply {
            put("p_id", operationId)
            put("p_new_status", PaymentStatus.CONFIRMED.name)
            put("p_reason", "Transação confirmada via biometria/app")
        }
        restClient.invokeRpc(SupabaseEndpoints.RPC_TRANSITION_PAYMENT, transitionParams)

        // Somente quando o resultado for COMPLETED:
        // 1. atualizar histórico;
        // 2. atualizar recibo;
        // 3. chamar novamente nova_kz_get_sandbox_balance;
        // 4. atualizar o saldo mostrado.
        val confirmedOp = processingOp.copy(
            status = PaymentStatus.CONFIRMED,
            completedAt = dateFormat.format(Date())
        )

        updateOperationInList(confirmedOp)
        updatePendingAuthorizations()
        transactionRepository?.saveOrUpdateTransaction(confirmedOp)

        // Reload persisted balance from Supabase RPC nova_kz_get_sandbox_balance()
        val reloadResult = loadSandboxBalance()
        if (reloadResult is NetworkResult.Error && backendNewBalance != null) {
            // If get_sandbox_balance RPC failed transiently right after execute returned new_balance from backend
            applyBackendVerifiedBalance(
                userId = dataStore.userId,
                balance = backendNewBalance,
                walletInitialized = true
            )
        }

        Log.d(
            TAG,
            "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=$operationId, rpcBalance=${_sandboxBalance.value}, status=COMPLETED]"
        )
        return@withLock NetworkResult.Success(confirmedOp)
    }

    private fun updateOperationInList(updated: PaymentOperation) {
        _operations.value = _operations.value.map {
            if (it.id == updated.id) updated else it
        }
    }

    fun getOperationById(id: String): PaymentOperation? {
        return _operations.value.find { it.id == id }
    }

    suspend fun refreshBackendBalance(): NetworkResult<Double> {
        return loadSandboxBalance()
    }

    suspend fun fetchSandboxBalance(): NetworkResult<Double> {
        return loadSandboxBalance()
    }

    suspend fun loadBankAccounts() {
        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_LIST_BANK_ACCOUNTS, JSONObject())
        if (rpcResult is NetworkResult.Success) {
            try {
                val array = org.json.JSONArray(rpcResult.data)
                val list = mutableListOf<BankAccount>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        BankAccount(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            bankName = obj.optString("bank_name", "Banco"),
                            iban = obj.optString("iban", ""),
                            accountNumber = obj.optString("account_number", ""),
                            accountType = obj.optString("account_type", "Conta Corrente"),
                            currency = obj.optString("currency", "AOA"),
                            balance = obj.optDouble("balance", 0.0),
                            isPrimary = obj.optBoolean("is_primary", i == 0)
                        )
                    )
                }
                if (list.isNotEmpty()) {
                    _bankAccounts.value = list
                }
            } catch (e: Exception) {
                Log.d(TAG, "Error parsing bank accounts from RPC: ${e.message}")
            }
        }
    }

    suspend fun loadMyPaymentOperations() {
        if (transactionRepository != null) {
            val syncResult = transactionRepository.syncTransactionsFromBackend()
            if (syncResult is NetworkResult.Success && syncResult.data.isNotEmpty()) {
                _operations.value = syncResult.data
                updatePendingAuthorizations()
                return
            }
        }

        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_LIST_MY_OPERATIONS, JSONObject())
        if (rpcResult is NetworkResult.Success) {
            try {
                val array = org.json.JSONArray(rpcResult.data)
                val list = mutableListOf<PaymentOperation>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val statusStr = obj.optString("status", "DRAFT")
                    val typeStr = obj.optString("operation_type", obj.optString("type", "TRANSFER"))
                    val descStr = obj.optString("description", "")
                    val authMethodStr = obj.optString("auth_method", "APP")
                    val status = PaymentStatus.fromBackendString(statusStr)
                    val type = PaymentType.fromBackendString(typeStr, descStr)
                    val authMethod = try { AuthMethod.valueOf(authMethodStr) } catch (e: Exception) { AuthMethod.APP }

                    list.add(
                        PaymentOperation(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            idempotencyKey = obj.optString("idempotency_key", UUID.randomUUID().toString()),
                            type = type,
                            amount = obj.optDouble("amount", 0.0),
                            currency = obj.optString("currency", "AOA"),
                            beneficiary = obj.optString("beneficiary_name", obj.optString("beneficiary", "")),
                            beneficiaryAccount = if (obj.has("beneficiary_account") && !obj.isNull("beneficiary_account")) obj.getString("beneficiary_account") else null,
                            reference = if (obj.has("reference") && !obj.isNull("reference")) obj.getString("reference") else null,
                            description = descStr,
                            status = status,
                            authMethod = authMethod,
                            environment = obj.optString("environment", "SANDBOX"),
                            createdAt = obj.optString("created_at", dateFormat.format(Date())),
                            completedAt = if (obj.has("completed_at") && !obj.isNull("completed_at")) obj.getString("completed_at") else null,
                            fee = obj.optDouble("fee", 0.0),
                            transactionId = obj.optString("transaction_id", "NKZ-" + System.currentTimeMillis().toString().takeLast(8)),
                            failureReason = if (obj.has("failure_reason") && !obj.isNull("failure_reason")) obj.getString("failure_reason") else null
                        )
                    )
                }
                if (list.isNotEmpty()) {
                    _operations.value = list
                    updatePendingAuthorizations()
                    scope.launch {
                        transactionRepository?.saveTransactions(list)
                    }
                }
            } catch (e: Exception) {
                Log.d(TAG, "Error parsing payment operations from RPC: ${e.message}")
            }
        }
    }

    // NOVA → NOVA: Consulta de destinatário por Telefone ou NOVA ID
    suspend fun lookupNovaRecipient(
        phone: String,
        subMethod: NovaLookupSubMethod = NovaLookupSubMethod.PHONE
    ): NetworkResult<NovaRecipient> {
        val rawInput = phone.trim()
        if (rawInput.isBlank()) {
            return NetworkResult.Error(
                if (subMethod == NovaLookupSubMethod.NOVA_ID) "Introduza um NOVA ID válido."
                else "Introduza um número de telefone válido com indicativo de Angola."
            )
        }

        // Resolve NOVA ID aliases (e.g., NOVA-946110370 or NKZ-946110370) or phone
        val extractedPhoneCandidate = when {
            rawInput.uppercase().startsWith("NOVA-") -> "+244" + rawInput.substringAfter("-").filter { it.isDigit() }.removePrefix("244")
            rawInput.uppercase().startsWith("NKZ-") -> "+244" + rawInput.substringAfter("-").filter { it.isDigit() }.removePrefix("244")
            else -> rawInput
        }

        val normalized = PhoneUtils.normalizeAngolaPhone(extractedPhoneCandidate)
        if (subMethod == NovaLookupSubMethod.PHONE && (normalized.isBlank() || normalized.length < 12)) {
            return NetworkResult.Error("Introduza um número de telefone válido com indicativo de Angola.")
        }
        if (subMethod == NovaLookupSubMethod.NOVA_ID && rawInput.length < 5) {
            return NetworkResult.Error("Introduza um identificador NOVA ID válido (ex: NOVA-946110370 ou +244 946 110 370).")
        }

        val lookupParam = if (normalized.length >= 12) normalized else rawInput
        val params = JSONObject().apply {
            put("p_phone", lookupParam)
        }

        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_LOOKUP_NOVA_ID, params)
        Log.d(TAG, "nova_kz_lookup_nova_id RPC result: $rpcResult")

        when (rpcResult) {
            is NetworkResult.Success -> {
                try {
                    val raw = rpcResult.data.trim()
                    val obj: JSONObject? = when {
                        raw.startsWith("[") -> {
                            val arr = JSONArray(raw)
                            if (arr.length() > 0) arr.getJSONObject(0) else null
                        }
                        raw.startsWith("{") -> JSONObject(raw)
                        else -> null
                    }

                    if (obj == null) {
                        return NetworkResult.Error("Não encontramos uma conta NOVA associada a este identificador.")
                    }

                    val retPhone = obj.optString("phone", normalized.ifBlank { rawInput })
                    val displayName = obj.optString("display_name", "")
                    val active = obj.optBoolean("active", false)
                    val retNovaId = obj.optString("nova_id", "NOVA-" + retPhone.removePrefix("+244"))

                    if (displayName.isBlank() || !active) {
                        return NetworkResult.Error("Não existe uma conta NOVA ativa associada a este identificador.")
                    }

                    return NetworkResult.Success(
                        NovaRecipient(
                            phone = retPhone,
                            displayName = displayName,
                            active = active,
                            novaId = retNovaId
                        )
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing lookup result", e)
                    return NetworkResult.Error("Não encontramos uma conta NOVA associada a este identificador.")
                }
            }
            is NetworkResult.Error -> {
                // If unconfigured or demo fallback for isolated sandbox test accounts
                if (!restClient.isConfigured() || rpcResult.code == 503 || rpcResult.code == 404) {
                    val sampleNames = mapOf(
                        "+244946110370" to "Manuel Bento da Silva",
                        "+244923000000" to "Conta Pessoal NOVA",
                        "+244924111222" to "Ana Paula Kiala",
                        "+244931555777" to "Mateus Domingos"
                    )
                    val sampleName = sampleNames[normalized] ?: if (normalized.length == 13 && normalized.startsWith("+2449")) {
                        "Utilizador NOVA (${PhoneUtils.formatDisplayPhone(normalized)})"
                    } else null

                    if (sampleName != null) {
                        return NetworkResult.Success(
                            NovaRecipient(
                                phone = normalized,
                                displayName = sampleName,
                                active = true,
                                novaId = "NOVA-" + normalized.removePrefix("+244")
                            )
                        )
                    }
                }

                val msg = rpcResult.message
                val friendly = when {
                    rpcResult.isNetworkError || rpcResult.isTimeout ->
                        "Não foi possível consultar o destinatário por falha de rede. Verifique a ligação."
                    msg.contains("RECIPIENT_NOT_FOUND", ignoreCase = true) || rpcResult.code == 404 ->
                        "Não encontramos uma conta NOVA associada a este número."
                    else -> msg
                }
                return NetworkResult.Error(friendly, code = rpcResult.code, cause = rpcResult.cause)
            }
        }
    }

    data class ReferenceValidationInfo(
        val entityCode: String,
        val beneficiaryName: String,
        val serviceCategory: String,
        val reference: String,
        val amount: Double,
        val statusLabel: String
    )

    fun validateReferencePayment(
        entityInput: String,
        referenceInput: String,
        amount: Double
    ): NetworkResult<ReferenceValidationInfo> {
        val cleanEntity = entityInput.trim()
        val cleanRef = referenceInput.trim()
        if (cleanEntity.isBlank()) {
            return NetworkResult.Error("Introduza o código ou nome da Entidade.")
        }
        if (cleanRef.length < 5) {
            return NetworkResult.Error("Introduza uma Referência de pagamento válida.")
        }
        if (amount <= 0.0) {
            return NetworkResult.Error("Introduza um valor válido superior a 0,00 AOA.")
        }

        val digitsOnly = cleanEntity.takeWhile { it.isDigit() }
        val matchedProvider = ServicesCatalog.providers.find {
            it.entityCode.equals(cleanEntity, ignoreCase = true) ||
                (digitsOnly.isNotBlank() && it.entityCode == digitsOnly) ||
                cleanEntity.contains(it.entityCode) ||
                cleanEntity.contains(it.name.substringBefore(" -"), ignoreCase = true)
        }

        val resolvedCode = matchedProvider?.entityCode ?: digitsOnly.ifBlank { cleanEntity }
        val resolvedName = matchedProvider?.name ?: cleanEntity
        val resolvedCategory = matchedProvider?.category?.label ?: "Pagamento por Referência"
        val resolvedStatus = matchedProvider?.let {
            "Entidade validada (${it.description}) • Pronta para autorização"
        } ?: "Entidade e Referência validadas • Pronta para autorização"

        return NetworkResult.Success(
            ReferenceValidationInfo(
                entityCode = resolvedCode,
                beneficiaryName = resolvedName,
                serviceCategory = resolvedCategory,
                reference = cleanRef,
                amount = amount,
                statusLabel = resolvedStatus
            )
        )
    }

    data class BankTransferValidationResult(
        val canExecute: Boolean,
        val availabilityStatus: IntegrationAvailabilityStatus,
        val bank: AngolaBankProvider?,
        val subMethod: BankTransferSubMethod,
        val destinationIdentifier: String,
        val accountHolder: String,
        val amount: Double,
        val description: String,
        val message: String
    )

    /**
     * Valida os campos e a disponibilidade do provider bancário para IBAN.
     * NUNCA simula uma transferência bancária real quando o banco/provider está PLANNED ou NOT_AVAILABLE.
     */
    fun validateBankTransferRequest(
        subMethod: BankTransferSubMethod,
        bankCodeOrName: String,
        ibanOrAccount: String,
        accountHolder: String,
        amount: Double,
        description: String
    ): BankTransferValidationResult {
        val bank = AngolaBanksCatalog.findByCodeOrName(bankCodeOrName)
        if (bank == null) {
            return BankTransferValidationResult(
                canExecute = false,
                availabilityStatus = IntegrationAvailabilityStatus.NOT_AVAILABLE,
                bank = null,
                subMethod = subMethod,
                destinationIdentifier = ibanOrAccount.trim(),
                accountHolder = accountHolder.trim(),
                amount = amount,
                description = description.trim(),
                message = "Selecione um banco angolano válido para validar a operação."
            )
        }

        val cleanDest = ibanOrAccount.trim()
        if (subMethod == BankTransferSubMethod.IBAN) {
            val normalizedIban = cleanDest.uppercase().replace(".", "").replace(" ", "")
            if (!normalizedIban.startsWith("AO06") || normalizedIban.length < 21) {
                return BankTransferValidationResult(
                    canExecute = false,
                    availabilityStatus = bank.transferAvailability,
                    bank = bank,
                    subMethod = subMethod,
                    destinationIdentifier = cleanDest,
                    accountHolder = accountHolder.trim(),
                    amount = amount,
                    description = description.trim(),
                    message = "Introduza um IBAN angolano válido iniciado por AO06."
                )
            }
        } else {
            val digits = cleanDest.filter { it.isDigit() }
            if (digits.length < 8) {
                return BankTransferValidationResult(
                    canExecute = false,
                    availabilityStatus = bank.transferAvailability,
                    bank = bank,
                    subMethod = subMethod,
                    destinationIdentifier = cleanDest,
                    accountHolder = accountHolder.trim(),
                    amount = amount,
                    description = description.trim(),
                    message = "Introduza um número de conta bancária válido (mínimo 8 dígitos)."
                )
            }
        }

        if (accountHolder.trim().length < 3) {
            return BankTransferValidationResult(
                canExecute = false,
                availabilityStatus = bank.transferAvailability,
                bank = bank,
                subMethod = subMethod,
                destinationIdentifier = cleanDest,
                accountHolder = accountHolder.trim(),
                amount = amount,
                description = description.trim(),
                message = "Indique o nome completo do titular da conta de destino."
            )
        }

        if (amount <= 0.0) {
            return BankTransferValidationResult(
                canExecute = false,
                availabilityStatus = bank.transferAvailability,
                bank = bank,
                subMethod = subMethod,
                destinationIdentifier = cleanDest,
                accountHolder = accountHolder.trim(),
                amount = amount,
                description = description.trim(),
                message = "Introduza um valor válido superior a 0,00 AOA."
            )
        }

        val statusMsg = when (bank.transferAvailability) {
            IntegrationAvailabilityStatus.PLANNED, IntegrationAvailabilityStatus.NOT_AVAILABLE ->
                "Integração interbancária direta com ${bank.fullName} (${subMethod.label}) encontra-se no estado ${bank.transferAvailability.name} (${bank.transferAvailability.label}). " +
                    "A infraestrutura técnica está preparada, mas aguarda conexão oficial a um provider bancário/EMIS autorizado. " +
                    "Nenhuma transferência bancária simulada foi executada e o seu saldo não foi alterado."
            IntegrationAvailabilityStatus.ACTIVE_SANDBOX ->
                "Provider Sandbox disponível."
        }

        return BankTransferValidationResult(
            canExecute = bank.transferAvailability == IntegrationAvailabilityStatus.ACTIVE_SANDBOX,
            availabilityStatus = bank.transferAvailability,
            bank = bank,
            subMethod = subMethod,
            destinationIdentifier = cleanDest,
            accountHolder = accountHolder.trim(),
            amount = amount,
            description = description.trim().ifBlank { "Transferência Bancária (${subMethod.label})" },
            message = statusMsg
        )
    }

    suspend fun createMulticaixaExpressOperation(
        phoneNumber: String,
        amount: Double,
        merchantOrService: String,
        description: String
    ): NetworkResult<PaymentOperation> {
        val normalizedPhone = PhoneUtils.normalizeAngolaPhone(phoneNumber)
        if (normalizedPhone.length < 12) {
            return NetworkResult.Error("Introduza um número de telemóvel válido associado ao Multicaixa Express (+244 9XX XXX XXX).")
        }
        if (amount <= 0.0) {
            return NetworkResult.Error("Introduza um valor válido superior a 0,00 AOA.")
        }
        return createPaymentOperation(
            type = PaymentType.MULTICAIXA_EXPRESS,
            amount = amount,
            beneficiary = merchantOrService.trim().ifBlank { "Multicaixa Express" },
            beneficiaryAccount = normalizedPhone,
            reference = "MCX-" + UUID.randomUUID().toString().take(8).uppercase(),
            description = description.trim().ifBlank { "Pagamento via Multicaixa Express" },
            authMethod = AuthMethod.MCX_EXPRESS
        )
    }

    // NOVA → NOVA: Transferência instantânea por número de telefone
    suspend fun sendToNova(
        recipientPhone: String,
        amount: Double,
        description: String = "",
        idempotencyKey: String,
        recipientName: String? = null
    ): NetworkResult<PaymentOperation> = executionMutex.withLock {
        val normalizedPhone = PhoneUtils.normalizeAngolaPhone(recipientPhone)
        val userNormalizedPhone = PhoneUtils.normalizeAngolaPhone(dataStore.userPhone)

        // 1. Validation
        if (amount <= 0) {
            return@withLock NetworkResult.Error("Introduz um valor válido.")
        }

        if (normalizedPhone.isNotBlank() && userNormalizedPhone.isNotBlank() && normalizedPhone == userNormalizedPhone) {
            return@withLock NetworkResult.Error("Não podes enviar dinheiro para o teu próprio número.")
        }

        if (amount > _sandboxBalance.value) {
            return@withLock NetworkResult.Error("Saldo insuficiente para concluir esta transferência.")
        }

        // Idempotency check: if already completed locally with this idempotency key, return it without re-deducting
        val existingOp = _operations.value.find { it.idempotencyKey == idempotencyKey }
        if (existingOp != null && existingOp.status == PaymentStatus.CONFIRMED) {
            Log.d(TAG, "Idempotent sendToNova: returning existing completed operation ${existingOp.id}")
            return@withLock NetworkResult.Success(existingOp)
        }

        val rpcParams = JSONObject().apply {
            put("p_recipient_nova_id", normalizedPhone)
            put("p_amount", amount)
            put("p_idempotency_key", idempotencyKey)
            put("p_description", description.ifBlank { "NOVA → NOVA" })
        }

        val rpcResult = restClient.invokeRpc(SupabaseEndpoints.RPC_SEND_TO_NOVA, rpcParams)

        if (rpcResult is NetworkResult.Success) {
            var operationId = UUID.randomUUID().toString()
            var operationRef = "NOVA-" + UUID.randomUUID().toString().take(12).uppercase()
            val completedStatus = PaymentStatus.CONFIRMED
            var completedAtStr = dateFormat.format(Date())
            var backendNewBalance: Double? = null
            var beneficiaryDisplayName = recipientName ?: "Destinatário NOVA"
            var isCompletedOnBackend = true
            var backendErrorMsg: String? = null

            try {
                val raw = rpcResult.data.trim()
                if (raw.startsWith("{")) {
                    val json = JSONObject(raw)
                    if (json.has("ok") && !json.optBoolean("ok", true)) {
                        isCompletedOnBackend = false
                        backendErrorMsg = json.optString("error", json.optString("message", "Falha na transferência NOVA → NOVA."))
                    }
                    val statusField = json.optString("status", "COMPLETED").uppercase()
                    if (statusField in listOf("FAILED", "REJECTED", "CANCELLED", "ERROR")) {
                        isCompletedOnBackend = false
                        backendErrorMsg = json.optString("message", "Transferência recusada pelo servidor ($statusField).")
                    }
                    if (json.has("operation_id")) operationId = json.getString("operation_id")
                    else if (json.has("id")) operationId = json.getString("id")
                    if (json.has("reference") && !json.isNull("reference")) {
                        operationRef = json.getString("reference")
                    }
                    if (json.has("recipient_name") && !json.isNull("recipient_name")) {
                        beneficiaryDisplayName = json.getString("recipient_name")
                    } else if (json.has("display_name") && !json.isNull("display_name")) {
                        beneficiaryDisplayName = json.getString("display_name")
                    }
                    if (json.has("new_balance") && !json.isNull("new_balance")) {
                        backendNewBalance = json.optString("new_balance", "").toDoubleOrNull() ?: json.optDouble("new_balance")
                    } else if (json.has("balance") && !json.isNull("balance")) {
                        backendNewBalance = json.optString("balance", "").toDoubleOrNull() ?: json.optDouble("balance")
                    }
                    if (json.has("completed_at") && !json.isNull("completed_at")) {
                        completedAtStr = json.getString("completed_at")
                    }
                }
            } catch (e: Exception) {
                isCompletedOnBackend = false
                backendErrorMsg = "Erro ao interpretar resposta da transferência: ${e.message}"
            }

            if (!isCompletedOnBackend) {
                Log.d(
                    TAG,
                    "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=$operationId, rpcBalance=${_sandboxBalance.value}, status=FAILED]"
                )
                return@withLock NetworkResult.Error(backendErrorMsg ?: "Não foi possível concluir a transferência NOVA → NOVA.")
            }

            val confirmedOp = PaymentOperation(
                id = operationId,
                idempotencyKey = idempotencyKey,
                type = PaymentType.NOVA_TO_NOVA,
                amount = amount,
                currency = "AOA",
                beneficiary = beneficiaryDisplayName,
                beneficiaryAccount = normalizedPhone,
                reference = operationRef,
                description = "NOVA → NOVA",
                status = completedStatus,
                authMethod = AuthMethod.APP,
                environment = "SANDBOX",
                createdAt = completedAtStr,
                completedAt = completedAtStr,
                fee = 0.0,
                transactionId = "NKZ-" + System.currentTimeMillis().toString().takeLast(8)
            )

            // Update operations history & receipt
            _operations.value = listOf(confirmedOp) + _operations.value.filter { it.id != confirmedOp.id && it.idempotencyKey != idempotencyKey }
            transactionRepository?.saveOrUpdateTransaction(confirmedOp)

            // Reload persisted balance from Supabase RPC nova_kz_get_sandbox_balance()
            val reloadResult = loadSandboxBalance()
            if (reloadResult is NetworkResult.Error && backendNewBalance != null) {
                applyBackendVerifiedBalance(
                    userId = dataStore.userId,
                    balance = backendNewBalance,
                    walletInitialized = true
                )
            }

            Log.d(
                TAG,
                "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=$operationId, rpcBalance=${_sandboxBalance.value}, status=COMPLETED]"
            )
            return@withLock NetworkResult.Success(confirmedOp)
        } else {
            val errorResult = rpcResult as NetworkResult.Error
            Log.d(
                TAG,
                "PaymentOp [user=${anonymizeUserId(dataStore.userId)}, opId=none, rpcBalance=${_sandboxBalance.value}, status=SEND_FAILED]"
            )

            val msg = errorResult.message
            val friendlyMessage = when {
                errorResult.isNetworkError || errorResult.isTimeout ->
                    "Não foi possível concluir a transferência por falha de rede. Podes tentar novamente com segurança."
                msg.contains("RECIPIENT_NOT_FOUND", ignoreCase = true) ->
                    "Não existe uma conta NOVA ativa associada a este número."
                msg.contains("SELF_TRANSFER_NOT_ALLOWED", ignoreCase = true) ->
                    "Não podes enviar dinheiro para o teu próprio número."
                msg.contains("INSUFFICIENT_FUNDS", ignoreCase = true) ->
                    "Saldo insuficiente para concluir esta transferência."
                msg.contains("AUTH_REQUIRED", ignoreCase = true) || errorResult.isSessionExpired ->
                    "A tua sessão expirou. Inicia sessão novamente."
                msg.contains("INVALID_AMOUNT", ignoreCase = true) ->
                    "Introduz um valor válido."
                msg.contains("INVALID_IDEMPOTENCY_KEY", ignoreCase = true) ->
                    "Chave de idempotência inválida. Tente novamente."
                msg.contains("SENDER_WALLET_NOT_FOUND", ignoreCase = true) ->
                    "Carteira de envio não encontrada para a conta atual."
                else -> msg
            }
            return@withLock NetworkResult.Error(friendlyMessage, code = errorResult.code, cause = errorResult.cause)
        }
    }

    companion object {
        private const val TAG = "PaymentManager"
    }
}
