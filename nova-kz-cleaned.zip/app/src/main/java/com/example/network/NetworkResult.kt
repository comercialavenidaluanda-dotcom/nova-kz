package com.example.network

sealed class NetworkResult<out T> {
    data class Success<T>(val data: T) : NetworkResult<T>()
    data class Error(
        val message: String,
        val code: Int? = null,
        val cause: Throwable? = null,
        val isNetworkError: Boolean = false,
        val isTimeout: Boolean = false,
        val isSessionExpired: Boolean = false
    ) : NetworkResult<Nothing>()
}

inline fun <T, R> NetworkResult<T>.map(transform: (T) -> R): NetworkResult<R> {
    return when (this) {
        is NetworkResult.Success -> NetworkResult.Success(transform(data))
        is NetworkResult.Error -> NetworkResult.Error(
            message = message,
            code = code,
            cause = cause,
            isNetworkError = isNetworkError,
            isTimeout = isTimeout,
            isSessionExpired = isSessionExpired
        )
    }
}

