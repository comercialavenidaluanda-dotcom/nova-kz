package com.example.data.repository

import android.util.Log
import com.example.data.LocalDataStore
import com.example.domain.legal.AppLegalAuthState
import com.example.domain.legal.LegalConstants
import com.example.network.NetworkResult
import com.example.network.SupabaseRestClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

enum class LegalAcceptanceStatus {
    ACCESS_GRANTED,
    LEGAL_ACCEPTANCE_REQUIRED
}

class LegalAcceptanceRepository(
    private val dataStore: LocalDataStore,
    private val restClient: SupabaseRestClient
) {
    private val _acceptanceStatus = MutableStateFlow(evaluateLocalStatus())
    val acceptanceStatus: StateFlow<LegalAcceptanceStatus> = _acceptanceStatus.asStateFlow()

    fun evaluateLocalStatus(userId: String = dataStore.userId): LegalAcceptanceStatus {
        val hasValidTerms = dataStore.getAcceptedTermsVersion(userId) == LegalConstants.CURRENT_TERMS_VERSION && dataStore.hasAcceptedTerms(userId)
        val hasValidPrivacy = dataStore.getAcceptedPrivacyVersion(userId) == LegalConstants.CURRENT_PRIVACY_VERSION && dataStore.hasAcceptedPrivacy(userId)

        return if (hasValidTerms && hasValidPrivacy) {
            LegalAcceptanceStatus.ACCESS_GRANTED
        } else {
            LegalAcceptanceStatus.LEGAL_ACCEPTANCE_REQUIRED
        }
    }

    fun isLocallyAccepted(userId: String = dataStore.userId): Boolean {
        return evaluateLocalStatus(userId) == LegalAcceptanceStatus.ACCESS_GRANTED
    }

    fun getLegalAuthState(userId: String = dataStore.userId): AppLegalAuthState {
        if (dataStore.authToken == null) return AppLegalAuthState.UNAUTHENTICATED
        return if (isLocallyAccepted(userId)) {
            AppLegalAuthState.AUTHENTICATED_AND_LEGAL_ACCEPTED
        } else {
            AppLegalAuthState.LEGAL_ACCEPTANCE_REQUIRED
        }
    }

    suspend fun checkLegalAcceptance(userId: String): LegalAcceptanceStatus {
        return withContext(Dispatchers.IO) {
            // First evaluate local fast check for this user
            val localStatus = evaluateLocalStatus(userId)

            // If user has a valid auth token and network, verify with backend Supabase
            if (dataStore.authToken != null && userId.isNotBlank()) {
                try {
                    when (val result = restClient.queryLegalAcceptance(userId)) {
                        is NetworkResult.Success -> {
                            val jsonArray = JSONArray(result.data)
                            if (jsonArray.length() > 0) {
                                val latest = jsonArray.getJSONObject(0)
                                val termsVersion = latest.optString("terms_version", "")
                                val privacyVersion = latest.optString("privacy_version", "")
                                val acceptedTerms = latest.optBoolean("accepted_terms", false)
                                val acceptedPrivacy = latest.optBoolean("accepted_privacy", false)

                                if (termsVersion == LegalConstants.CURRENT_TERMS_VERSION &&
                                    privacyVersion == LegalConstants.CURRENT_PRIVACY_VERSION &&
                                    acceptedTerms && acceptedPrivacy
                                ) {
                                    // Update local store to match verified backend record for this user
                                    dataStore.setLegalAcceptance(
                                        user = userId,
                                        termsVersion = termsVersion,
                                        privacyVersion = privacyVersion,
                                        termsAccepted = true,
                                        privacyAccepted = true,
                                        acceptedAt = System.currentTimeMillis()
                                    )
                                    _acceptanceStatus.value = LegalAcceptanceStatus.ACCESS_GRANTED
                                    return@withContext LegalAcceptanceStatus.ACCESS_GRANTED
                                } else {
                                    // Remote version is outdated or not fully accepted
                                    _acceptanceStatus.value = LegalAcceptanceStatus.LEGAL_ACCEPTANCE_REQUIRED
                                    return@withContext LegalAcceptanceStatus.LEGAL_ACCEPTANCE_REQUIRED
                                }
                            }
                        }
                        is NetworkResult.Error -> {
                            Log.w(TAG, "Failed to verify remote acceptance, relying on validated local cache: ${result.message}")
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Exception verifying remote legal acceptance: ${e.message}", e)
                }
            }

            _acceptanceStatus.value = localStatus
            localStatus
        }
    }

    suspend fun acceptCurrentTermsAndPrivacy(userId: String): NetworkResult<Boolean> {
        return withContext(Dispatchers.IO) {
            val targetUserId = userId.ifBlank { dataStore.userId }
            val now = System.currentTimeMillis()

            // 1. Save locally with timestamp for target user
            dataStore.setLegalAcceptance(
                user = targetUserId,
                termsVersion = LegalConstants.CURRENT_TERMS_VERSION,
                privacyVersion = LegalConstants.CURRENT_PRIVACY_VERSION,
                termsAccepted = true,
                privacyAccepted = true,
                acceptedAt = now
            )
            _acceptanceStatus.value = LegalAcceptanceStatus.ACCESS_GRANTED

            // 2. Synchronize to Supabase table
            try {
                restClient.recordLegalAcceptance(
                    userId = targetUserId,
                    termsVersion = LegalConstants.CURRENT_TERMS_VERSION,
                    privacyVersion = LegalConstants.CURRENT_PRIVACY_VERSION,
                    acceptedTerms = true,
                    acceptedPrivacy = true
                )
            } catch (e: Exception) {
                Log.w(TAG, "Error posting legal acceptance to Supabase: ${e.message}")
            }

            NetworkResult.Success(true)
        }
    }

    fun clearAcceptance(userId: String = dataStore.userId) {
        dataStore.clearLegalAcceptance(userId)
        _acceptanceStatus.value = LegalAcceptanceStatus.LEGAL_ACCEPTANCE_REQUIRED
    }

    companion object {
        private const val TAG = "LegalAcceptanceRepo"
    }
}
