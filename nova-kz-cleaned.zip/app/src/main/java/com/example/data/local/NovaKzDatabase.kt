package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration

@Database(
    entities = [PaymentTransactionEntity::class, SandboxBalanceCacheEntity::class],
    version = 2,
    exportSchema = false
)
abstract class NovaKzDatabase : RoomDatabase() {

    abstract fun paymentTransactionDao(): PaymentTransactionDao

    companion object {
        @Volatile
        private var INSTANCE: NovaKzDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `nova_kz_sandbox_balance_cache` (
                        `userId` TEXT NOT NULL,
                        `balance` REAL NOT NULL,
                        `currency` TEXT NOT NULL,
                        `updatedAt` INTEGER NOT NULL,
                        PRIMARY KEY(`userId`)
                    )
                    """.trimIndent()
                )
            }
        }

        // Explicit migrations registry to prevent destructive data loss on schema updates
        val MIGRATIONS: Array<Migration> = arrayOf(
            MIGRATION_1_2
        )

        fun getDatabase(context: Context): NovaKzDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NovaKzDatabase::class.java,
                    "nova_kz_database"
                )
                    .addMigrations(*MIGRATIONS)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
