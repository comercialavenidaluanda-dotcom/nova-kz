package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Visual-only cache for the last known Sandbox balance fetched from Supabase RPC
 * `public.nova_kz_get_sandbox_balance()`.
 *
 * IMPORTANT: CACHE != SOURCE OF TRUTH.
 * This entity is never used as the authoritative financial balance; it is only
 * updated after a successful backend RPC response.
 */
@Entity(tableName = "nova_kz_sandbox_balance_cache")
data class SandboxBalanceCacheEntity(
    @PrimaryKey
    val userId: String,
    val balance: Double,
    val currency: String = "AOA",
    val updatedAt: Long = System.currentTimeMillis()
)
