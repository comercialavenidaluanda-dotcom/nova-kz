package com.example.ui.screens.profile

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.auth.AuthManager
import com.example.domain.legal.LegalConstants
import com.example.network.NetworkResult
import com.example.network.SupabaseRestClient
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.theme.NovaDangerBg
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaInfoBlue
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import kotlinx.coroutines.launch

@Composable
fun AccountDeletionScreen(
    authManager: AuthManager,
    restClient: SupabaseRestClient,
    onBack: () -> Unit,
    onAccountDeletionCompleted: () -> Unit
) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val scope = rememberCoroutineScope()

    var isConfirmed by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var showConfirmDialog by remember { mutableStateOf(false) }
    var requestSuccess by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
            .testTag("account_deletion_screen")
    ) {
        NovaTopBar(
            title = "Eliminar Conta",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Warning Header Icon
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(NovaDangerBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Aviso de eliminação",
                    tint = NovaDangerRed,
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Eliminar conta NOVA KZ",
                color = NovaTextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Mandatory Informational Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = "A eliminação da conta remove os dados associados à sua conta que possam ser eliminados de acordo com a Política de Privacidade. Alguns registos poderão ter de ser conservados quando exigido por obrigações legais, segurança, auditoria ou prevenção de fraude.",
                        color = NovaTextPrimary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NovaNavySurface, RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = NovaInfoBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "O seu pedido será formalmente registado no sistema com estado REQUESTED para auditoria e retenção legal nos termos da Lei n.º 22/11.",
                            color = NovaTextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (!requestSuccess) {
                // Confirmation Checkbox Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isConfirmed = !isConfirmed },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isConfirmed) NovaDangerBg.copy(alpha = 0.3f) else NovaNavyCard
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = if (isConfirmed) NovaDangerRed else NovaNavyCardBorder,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isConfirmed,
                            onCheckedChange = { isConfirmed = it },
                            colors = CheckboxDefaults.colors(
                                checkedColor = NovaDangerRed,
                                uncheckedColor = NovaTextSecondary,
                                checkmarkColor = NovaTextPrimary
                            ),
                            modifier = Modifier.testTag("checkbox_confirm_deletion")
                        )

                        Spacer(modifier = Modifier.width(10.dp))

                        Text(
                            text = "Tenho conhecimento de que esta ação é destinada à eliminação da minha conta.",
                            color = NovaTextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 18.sp
                        )
                    }
                }

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = errorMessage ?: "",
                        color = NovaDangerRed,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Action Button: Request Deletion
                NovaButton(
                    text = if (isLoading) "A registar solicitação..." else "Solicitar eliminação da conta",
                    onClick = { showConfirmDialog = true },
                    enabled = isConfirmed && !isLoading,
                    isDanger = true,
                    leadingIcon = Icons.Default.DeleteForever,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_request_deletion"
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Link: Solicitar eliminação online
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            uriHandler.openUri(LegalConstants.ACCOUNT_DELETION_URL)
                        }
                        .padding(vertical = 12.dp)
                        .testTag("btn_request_deletion_online"),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                        contentDescription = null,
                        tint = NovaGold,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Solicitar eliminação online",
                        color = NovaGold,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            } else {
                // Success State Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, NovaEmerald, RoundedCornerShape(12.dp))
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = NovaEmerald,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Solicitação Registada (REQUESTED)",
                            color = NovaEmerald,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "O seu pedido de eliminação de conta foi transmitido à equipa de conformidade do NOVA KZ. A eliminação dos dados elegíveis será processada em conformidade com as regras de retenção legal e a Política de Privacidade.",
                            color = NovaTextSecondary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                NovaButton(
                    text = "Terminar Sessão e Concluir",
                    onClick = {
                        authManager.logout()
                        onAccountDeletionCompleted()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_finish_after_deletion"
                )
            }
        }
    }

    // Confirmation Alert Dialog
    if (showConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            title = {
                Text(
                    text = "Confirmar Solicitação de Eliminação",
                    color = NovaTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Tem a certeza de que pretende solicitar a eliminação da sua conta NOVA KZ? O pedido será registado com estado REQUESTED no servidor.",
                    color = NovaTextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showConfirmDialog = false
                        scope.launch {
                            isLoading = true
                            errorMessage = null
                            val currentUser = authManager.currentUser.value
                            val email = currentUser?.email?.ifBlank { null } ?: "comercialavenidaluanda@gmail.com"
                            val userId = currentUser?.id
                            val result = restClient.requestAccountDeletion(
                                reason = "user_requested",
                                userEmail = email,
                                userId = userId
                            )
                            isLoading = false
                            when (result) {
                                is NetworkResult.Success -> {
                                    requestSuccess = true
                                    Toast.makeText(
                                        context,
                                        "Pedido de eliminação registado com sucesso (REQUESTED).",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                                is NetworkResult.Error -> {
                                    // Even if offline/network error, allow graceful submission or show error
                                    errorMessage = result.message
                                    Toast.makeText(
                                        context,
                                        result.message,
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        }
                    }
                ) {
                    Text("Confirmar Pedido", color = NovaDangerRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmDialog = false }) {
                    Text("Cancelar", color = NovaTextSecondary)
                }
            },
            containerColor = NovaNavyCard
        )
    }
}
