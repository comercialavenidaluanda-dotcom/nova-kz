package com.example.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.auth.AuthManager
import com.example.domain.legal.LegalConstants
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxBadge
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary

@Composable
fun ProfileScreen(
    authManager: AuthManager,
    onLogout: () -> Unit,
    onBack: () -> Unit,
    onNavigateToSecurity: () -> Unit = {},
    onNavigateToTerms: () -> Unit = {},
    onNavigateToPrivacy: () -> Unit = {},
    onNavigateToFaq: () -> Unit = {},
    onNavigateToAccountDeletion: () -> Unit = {}
) {
    val user by authManager.currentUser.collectAsState()
    var showSupportDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
            .testTag("profile_screen")
    ) {
        NovaTopBar(
            title = "Perfil e Definições",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Avatar & Name
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(NovaNavyCard)
                    .border(2.dp, NovaGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = NovaGold,
                    modifier = Modifier.size(40.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = user?.name ?: "Utilizador NOVA KZ",
                color = NovaTextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))
            SandboxBadge()

            Spacer(modifier = Modifier.height(20.dp))

            // User Profile Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_info_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(14.dp))
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Dados Cadastrais",
                        color = NovaGold,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    ProfileRowItem(icon = Icons.Default.Mail, label = "E-mail", value = user?.email ?: "comercialavenidaluanda@gmail.com")
                    ProfileRowItem(icon = Icons.Default.Phone, label = "Telefone", value = user?.phone ?: LegalConstants.SUPPORT_PHONE)
                    ProfileRowItem(icon = Icons.Default.Badge, label = "NIF", value = user?.nif ?: "005928172LA041")
                    ProfileRowItem(icon = Icons.Default.Shield, label = "Ambiente", value = "Sandbox (ao.novakz.app)")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Definições e Legal Section
            Text(
                text = "DEFINIÇÕES & SEGURANÇA JURÍDICA",
                color = NovaTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(14.dp))
                ) {
                    ProfileMenuRow(
                        icon = Icons.Default.Security,
                        title = "Segurança",
                        subtitle = "Anti-Roubo, Biometria e PIN de Acesso",
                        onClick = onNavigateToSecurity,
                        tag = "menu_security"
                    )

                    ProfileMenuDivider()

                    ProfileMenuRow(
                        icon = Icons.Default.Description,
                        title = "Termos e Condições",
                        subtitle = "Versão v${LegalConstants.CURRENT_TERMS_VERSION} • Enquadramento Legal",
                        onClick = onNavigateToTerms,
                        tag = "menu_terms"
                    )

                    ProfileMenuDivider()

                    ProfileMenuRow(
                        icon = Icons.Default.Lock,
                        title = "Privacidade e Protecção de Dados",
                        subtitle = "Lei n.º 22/11 de Angola • Minimização de Dados",
                        onClick = onNavigateToPrivacy,
                        tag = "menu_privacy"
                    )

                    ProfileMenuDivider()

                    ProfileMenuRow(
                        icon = Icons.AutoMirrored.Filled.HelpOutline,
                        title = "FAQ — Perguntas Frequentes",
                        subtitle = "28 Perguntas e Respostas sobre o NOVA KZ",
                        onClick = onNavigateToFaq,
                        tag = "menu_faq"
                    )

                    ProfileMenuDivider()

                    ProfileMenuRow(
                        icon = Icons.Default.SupportAgent,
                        title = "Suporte",
                        subtitle = "Apoio ao cliente, canais oficiais e denúncias",
                        onClick = { showSupportDialog = true },
                        tag = "menu_support"
                    )

                    ProfileMenuDivider()

                    ProfileMenuRow(
                        icon = Icons.Default.Info,
                        title = "Sobre o NOVA KZ",
                        subtitle = "Versão 1.0.0 • Projecto Independente",
                        onClick = { showAboutDialog = true },
                        tag = "menu_about"
                    )

                    ProfileMenuDivider()

                    ProfileMenuRow(
                        icon = Icons.Default.DeleteForever,
                        title = "Eliminar Conta",
                        subtitle = "Direito ao esquecimento • Lei n.º 22/11",
                        onClick = onNavigateToAccountDeletion,
                        tag = "menu_account_deletion"
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            NovaButton(
                text = "Terminar Sessão",
                onClick = {
                    authManager.logout()
                    onLogout()
                },
                isDanger = true,
                leadingIcon = Icons.Default.ExitToApp,
                modifier = Modifier.fillMaxWidth(),
                testTag = "profile_logout_button"
            )

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Support Dialog
        if (showSupportDialog) {
            AlertDialog(
                onDismissRequest = { showSupportDialog = false },
                title = {
                    Text(text = "Canais de Apoio Oficial", color = NovaTextPrimary, fontWeight = FontWeight.Bold)
                },
                text = {
                    Column {
                        Text(
                            text = "A nossa equipa está disponível para esclarecimentos, reporte de anomalias e suporte a operações:",
                            color = NovaTextSecondary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "• E-mail: ${LegalConstants.SUPPORT_EMAIL}", color = NovaGold, fontSize = 13.sp)
                        Text(text = "• WhatsApp / Linha: ${LegalConstants.SUPPORT_WHATSAPP}", color = NovaGold, fontSize = 13.sp)
                        Text(text = "• Localização: Luanda, República de Angola", color = NovaTextSecondary, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSupportDialog = false }) {
                        Text("Fechar", color = NovaGold)
                    }
                },
                containerColor = NovaNavyCard
            )
        }

        // About Dialog
        if (showAboutDialog) {
            AlertDialog(
                onDismissRequest = { showAboutDialog = false },
                title = {
                    Text(text = "Sobre o NOVA KZ", color = NovaTextPrimary, fontWeight = FontWeight.Bold)
                },
                text = {
                    Column {
                        Text(
                            text = "NOVA KZ é uma plataforma móvel e infraestrutura de pagamentos digitais independente desenvolvida para o mercado financeiro angolano.",
                            color = NovaTextSecondary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "• Versão: 1.0.0 (Build Produção / Sandbox)", color = NovaGold, fontSize = 12.sp)
                        Text(text = "• Arquitectura: Kotlin + Jetpack Compose + Supabase", color = NovaTextSecondary, fontSize = 12.sp)
                        Text(text = "• Conformidade: Lei n.º 22/11 de Angola", color = NovaTextSecondary, fontSize = 12.sp)
                        Text(text = "• Projecto independente do KONECTA.", color = NovaTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showAboutDialog = false }) {
                        Text("Compreendido", color = NovaGold)
                    }
                },
                containerColor = NovaNavyCard
            )
        }
    }
}

@Composable
fun ProfileMenuRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(NovaGold.copy(alpha = 0.12f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = NovaGold, modifier = Modifier.size(18.dp))
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = NovaTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(text = subtitle, color = NovaTextSecondary, fontSize = 11.sp)
        }
        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = NovaGold, modifier = Modifier.size(16.dp))
    }
}

@Composable
fun ProfileMenuDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(NovaNavyCardBorder.copy(alpha = 0.5f))
    )
}

@Composable
fun ProfileRowItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = NovaGold, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(text = label, color = NovaTextSecondary, fontSize = 11.sp)
            Text(text = value, color = NovaTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}
