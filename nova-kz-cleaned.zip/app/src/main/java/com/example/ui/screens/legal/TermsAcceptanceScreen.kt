package com.example.ui.screens.legal

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.LegalAcceptanceRepository
import com.example.domain.legal.LegalConstants
import com.example.ui.components.NovaButton
import com.example.ui.components.SandboxBadge
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import kotlinx.coroutines.launch

@Composable
fun TermsAcceptanceScreen(
    legalAcceptanceRepository: LegalAcceptanceRepository,
    userId: String,
    onAcceptanceCompleted: () -> Unit,
    onNavigateToTerms: () -> Unit,
    onNavigateToPrivacy: () -> Unit,
    onNavigateToFaq: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var acceptedTerms by remember { mutableStateOf(false) }
    var acceptedPrivacy by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }

    // Intercept back button to prevent bypassing mandatory legal terms
    BackHandler {
        Toast.makeText(
            context,
            "A aceitação dos Termos e da Política de Privacidade é obrigatória para aceder ao NOVA KZ.",
            Toast.LENGTH_LONG
        ).show()
    }

    val canProceed = acceptedTerms && acceptedPrivacy && !isLoading

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        // Shield / Emblem icon
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(NovaNavyCard)
                .border(2.dp, NovaGold, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Gavel,
                contentDescription = null,
                tint = NovaGold,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Conformidade Legal & Privacidade",
            color = NovaTextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Para sua segurança jurídica e protecção dos seus dados nos termos da legislação angolana, é necessário ler e aceitar os documentos antes de prosseguir.",
            color = NovaTextSecondary,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            lineHeight = 18.sp
        )

        Spacer(modifier = Modifier.height(14.dp))
        SandboxBadge()

        Spacer(modifier = Modifier.height(20.dp))

        // Version Info Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = NovaEmerald,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Versão Vigente: Termos v${LegalConstants.CURRENT_TERMS_VERSION} • Privacidade v${LegalConstants.CURRENT_PRIVACY_VERSION}",
                        color = NovaTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Lei n.º 22/11 de Protecção de Dados Pessoais • Angola",
                        color = NovaTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Document 1: Termos e Condições
        LegalDocumentCard(
            title = "Termos e Condições de Utilização",
            version = "v${LegalConstants.CURRENT_TERMS_VERSION}",
            description = "Natureza independente do NOVA KZ, pagamentos, ambiente Sandbox, responsabilidades e enquadramento bancário.",
            icon = Icons.Default.Description,
            onReadClick = onNavigateToTerms
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Document 2: Política de Privacidade
        LegalDocumentCard(
            title = "Política de Privacidade e Dados",
            version = "v${LegalConstants.CURRENT_PRIVACY_VERSION}",
            description = "Minimização de dados, proteção de direitos do titular (Lei n.º 22/11) e proibição de recolha de CVV/PINs.",
            icon = Icons.Default.Lock,
            onReadClick = onNavigateToPrivacy
        )

        Spacer(modifier = Modifier.height(12.dp))

        // FAQ Link Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onNavigateToFaq() }
                .testTag("terms_open_faq_card"),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.HelpOutline,
                    contentDescription = null,
                    tint = NovaGold,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Perguntas Frequentes (FAQ)",
                        color = NovaTextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Consulte respostas a 28 dúvidas sobre segurança, pagamentos e o Sandbox.",
                        color = NovaTextSecondary,
                        fontSize = 11.sp
                    )
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Abrir FAQ",
                    tint = NovaGold,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Mandatory Checkbox 1
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { acceptedTerms = !acceptedTerms }
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = acceptedTerms,
                onCheckedChange = { acceptedTerms = it },
                colors = CheckboxDefaults.colors(
                    checkedColor = NovaEmerald,
                    uncheckedColor = NovaGold,
                    checkmarkColor = NovaNavyDark
                ),
                modifier = Modifier.testTag("checkbox_terms")
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Li e aceito os Termos e Condições de Utilização.",
                color = if (acceptedTerms) NovaTextPrimary else NovaTextSecondary,
                fontSize = 13.sp,
                fontWeight = if (acceptedTerms) FontWeight.SemiBold else FontWeight.Normal
            )
        }

        // Mandatory Checkbox 2
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { acceptedPrivacy = !acceptedPrivacy }
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = acceptedPrivacy,
                onCheckedChange = { acceptedPrivacy = it },
                colors = CheckboxDefaults.colors(
                    checkedColor = NovaEmerald,
                    uncheckedColor = NovaGold,
                    checkmarkColor = NovaNavyDark
                ),
                modifier = Modifier.testTag("checkbox_privacy")
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Li e aceito a Política de Privacidade e Protecção de Dados.",
                color = if (acceptedPrivacy) NovaTextPrimary else NovaTextSecondary,
                fontSize = 13.sp,
                fontWeight = if (acceptedPrivacy) FontWeight.SemiBold else FontWeight.Normal
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Mandatory Submit Button
        NovaButton(
            text = "ACEITAR E CONTINUAR",
            onClick = {
                if (canProceed) {
                    scope.launch {
                        isLoading = true
                        val result = legalAcceptanceRepository.acceptCurrentTermsAndPrivacy(userId)
                        isLoading = false
                        if (result is com.example.network.NetworkResult.Success) {
                            Toast.makeText(context, "Termos aceites com sucesso!", Toast.LENGTH_SHORT).show()
                            onAcceptanceCompleted()
                        } else {
                            Toast.makeText(context, "Não foi possível registar a aceitação. Tente novamente.", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            },
            enabled = canProceed,
            isLoading = isLoading,
            leadingIcon = Icons.Default.CheckCircle,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("btn_accept_legal_continue")
        )

        if (!canProceed) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "É obrigatório marcar ambos os checkboxes para desbloquear o acesso à aplicação.",
                color = NovaTextSecondary,
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun LegalDocumentCard(
    title: String,
    version: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onReadClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onReadClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = NovaNavyCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(14.dp))
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(NovaGold.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = icon, contentDescription = null, tint = NovaGold, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(text = title, color = NovaTextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Versão $version", color = NovaEmerald, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(NovaGold.copy(alpha = 0.12f))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(text = "Ler", color = NovaGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = NovaGold, modifier = Modifier.size(14.dp))
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = description, color = NovaTextSecondary, fontSize = 12.sp, lineHeight = 16.sp)
        }
    }
}
