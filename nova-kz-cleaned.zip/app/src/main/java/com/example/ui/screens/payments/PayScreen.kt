package com.example.ui.screens.payments

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.models.AuthMethod
import com.example.domain.models.PaymentType
import com.example.domain.models.PhoneUtils
import com.example.domain.models.ReferencePaymentSubMethod
import com.example.domain.models.TransferMethodCategory
import com.example.network.NetworkResult
import com.example.payments.PaymentManager
import com.example.ui.components.NovaButton
import com.example.ui.components.NovaTopBar
import com.example.ui.components.SandboxDisclaimerBanner
import com.example.ui.components.formatAoa
import com.example.ui.theme.NovaDangerRed
import com.example.ui.theme.NovaEmerald
import com.example.ui.theme.NovaEmeraldBg
import com.example.ui.theme.NovaEmeraldLight
import com.example.ui.theme.NovaGold
import com.example.ui.theme.NovaGoldLight
import com.example.ui.theme.NovaNavyCard
import com.example.ui.theme.NovaNavyCardBorder
import com.example.ui.theme.NovaNavyDark
import com.example.ui.theme.NovaNavySurface
import com.example.ui.theme.NovaTextPrimary
import com.example.ui.theme.NovaTextSecondary
import kotlinx.coroutines.launch

@Composable
fun PayScreen(
    paymentManager: PaymentManager,
    onNavigateToAuthorize: (String) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val sandboxBalance by paymentManager.sandboxBalance.collectAsState()

    var activePaymentMethod by remember { mutableStateOf(TransferMethodCategory.REFERENCE_PAYMENT) }
    val referenceSubMethod = ReferencePaymentSubMethod.ENTITY_REFERENCE

    // REFERENCE_PAYMENT (ENTITY_REFERENCE) State
    var entity by remember { mutableStateOf("00201 (ENDE Pré-pago)") }
    var reference by remember { mutableStateOf("1002938491") }
    var amountText by remember { mutableStateOf("150") }
    var description by remember { mutableStateOf("Recarga de energia pré-pago") }
    var validatedReference by remember { mutableStateOf<PaymentManager.ReferenceValidationInfo?>(null) }

    // MULTICAIXA_EXPRESS State
    var mcxPhone by remember { mutableStateOf("+244 946 110 370") }
    var mcxMerchantOrService by remember { mutableStateOf("Pagamento Comercial MCX Express") }
    var mcxAmountText by remember { mutableStateOf("150") }
    var mcxDescription by remember { mutableStateOf("Autorização via Multicaixa Express") }
    var showMcxSummary by remember { mutableStateOf(false) }

    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaNavyDark)
    ) {
        NovaTopBar(
            title = "Efetuar Pagamento",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SandboxDisclaimerBanner()
            Spacer(modifier = Modifier.height(14.dp))

            // Method Selector: Referência (ENTITY_REFERENCE) vs Multicaixa Express (MULTICAIXA_EXPRESS)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NovaNavyCard)
                    .border(1.dp, NovaNavyCardBorder, RoundedCornerShape(12.dp))
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (activePaymentMethod == TransferMethodCategory.REFERENCE_PAYMENT) NovaGold else Color.Transparent)
                        .clickable {
                            activePaymentMethod = TransferMethodCategory.REFERENCE_PAYMENT
                            errorMessage = null
                        }
                        .padding(vertical = 10.dp)
                        .testTag("pay_mode_reference_tab"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Referência",
                        color = if (activePaymentMethod == TransferMethodCategory.REFERENCE_PAYMENT) NovaNavyDark else NovaTextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (activePaymentMethod == TransferMethodCategory.MULTICAIXA_EXPRESS) NovaGold else Color.Transparent)
                        .clickable {
                            activePaymentMethod = TransferMethodCategory.MULTICAIXA_EXPRESS
                            errorMessage = null
                        }
                        .padding(vertical = 10.dp)
                        .testTag("pay_mode_mcx_tab"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Multicaixa Express",
                        color = if (activePaymentMethod == TransferMethodCategory.MULTICAIXA_EXPRESS) NovaNavyDark else NovaTextSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // =========================================================================
            // 1. REFERENCE_PAYMENT (ENTITY_REFERENCE)
            // =========================================================================
            if (activePaymentMethod == TransferMethodCategory.REFERENCE_PAYMENT) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Pagamento por Referência",
                        color = NovaTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(NovaEmeraldBg)
                            .border(1.dp, NovaEmerald, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = referenceSubMethod.name,
                            color = NovaEmeraldLight,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Valide a Entidade e Referência para identificar o beneficiário/serviço antes de autorizar e confirmar o pagamento.",
                    color = NovaTextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Dados de pagamento introduzidos pelo utilizador. Sem valores de teste pré-carregados.

                OutlinedTextField(
                    value = entity,
                    onValueChange = {
                        entity = it
                        validatedReference = null
                        errorMessage = null
                    },
                    label = { Text("Entidade", color = NovaTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Widgets, null, tint = NovaGold) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pay_entity_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = reference,
                    onValueChange = {
                        reference = it
                        validatedReference = null
                        errorMessage = null
                    },
                    label = { Text("Referência de Pagamento", color = NovaTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Numbers, null, tint = NovaGold) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pay_reference_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        errorMessage = null
                    },
                    label = { Text("Valor a Pagar (AOA)", color = NovaTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Payment, null, tint = NovaGold) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pay_amount_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Descrição (opcional)", color = NovaTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Receipt, null, tint = NovaGold) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pay_description_input")
                )

                // Validated Beneficiary / Service Card
                if (validatedReference != null) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pay_validated_reference_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = NovaEmeraldBg.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, NovaEmerald, RoundedCornerShape(12.dp))
                                .padding(14.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(NovaEmerald),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.CheckCircle, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Beneficiário / Serviço Identificado",
                                        color = NovaTextSecondary,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = validatedReference!!.beneficiaryName,
                                        color = NovaTextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Entidade: ${validatedReference!!.entityCode} • ${validatedReference!!.serviceCategory}",
                                    color = NovaGoldLight,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Ref: ${validatedReference!!.reference}",
                                    color = NovaTextPrimary,
                                    fontSize = 12.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = validatedReference!!.statusLabel,
                                color = NovaEmeraldLight,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorMessage!!,
                        color = NovaDangerRed,
                        fontSize = 12.sp,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Button to explicitly validate Reference and show Beneficiary/Service if not yet validated
                if (validatedReference == null) {
                    NovaButton(
                        text = "Validar Entidade e Referência",
                        isSecondary = true,
                        leadingIcon = Icons.Default.Search,
                        onClick = {
                            val amount = amountText.toDoubleOrNull() ?: 0.0
                            when (val res = paymentManager.validateReferencePayment(entity, reference, amount)) {
                                is NetworkResult.Success -> {
                                    validatedReference = res.data
                                    errorMessage = null
                                }
                                is NetworkResult.Error -> {
                                    validatedReference = null
                                    errorMessage = res.message
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pay_validate_reference_button")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                NovaButton(
                    text = if (validatedReference != null) "Confirmar e Prosseguir para Autorização" else "Validar e Prosseguir",
                    onClick = {
                        val amount = amountText.toDoubleOrNull()
                        if (amount == null || amount <= 0) {
                            errorMessage = "Introduza um valor válido superior a zero."
                            return@NovaButton
                        }
                        val validation = paymentManager.validateReferencePayment(entity, reference, amount)
                        if (validation is NetworkResult.Error) {
                            errorMessage = validation.message
                            return@NovaButton
                        }
                        val refInfo = (validation as NetworkResult.Success).data
                        validatedReference = refInfo

                        scope.launch {
                            isLoading = true
                            errorMessage = null
                            val result = paymentManager.createPaymentOperation(
                                type = PaymentType.REFERENCE_PAYMENT,
                                amount = amount,
                                beneficiary = "${refInfo.entityCode} - ${refInfo.beneficiaryName}",
                                reference = refInfo.reference,
                                description = description.ifBlank { "Pagamento por Referência (${refInfo.beneficiaryName})" },
                                authMethod = AuthMethod.APP
                            )
                            isLoading = false
                            when (result) {
                                is NetworkResult.Success -> onNavigateToAuthorize(result.data.id)
                                is NetworkResult.Error -> errorMessage = result.message
                            }
                        }
                    },
                    isLoading = isLoading,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "pay_submit_button"
                )
            } else {
                // =========================================================================
                // 2. MULTICAIXA EXPRESS (Configured Sandbox Provider)
                // =========================================================================
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Multicaixa Express",
                        color = NovaGold,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(NovaEmeraldBg)
                            .border(1.dp, NovaEmerald, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "PROVIDER SANDBOX",
                            color = NovaEmeraldLight,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Pagamento com confirmação e estado real da operação através do provider Multicaixa Express configurado no ambiente Sandbox.",
                    color = NovaTextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = mcxPhone,
                    onValueChange = {
                        mcxPhone = it
                        showMcxSummary = false
                        errorMessage = null
                    },
                    label = { Text("Telemóvel Multicaixa Express (+244)", color = NovaTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.PhoneAndroid, null, tint = NovaGold) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("mcx_phone_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = mcxMerchantOrService,
                    onValueChange = {
                        mcxMerchantOrService = it
                        showMcxSummary = false
                        errorMessage = null
                    },
                    label = { Text("Comerciante / Operação", color = NovaTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Widgets, null, tint = NovaGold) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("mcx_merchant_input")
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = mcxAmountText,
                    onValueChange = {
                        mcxAmountText = it
                        showMcxSummary = false
                        errorMessage = null
                    },
                    label = { Text("Valor da Operação (AOA)", color = NovaTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Payment, null, tint = NovaGold) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("mcx_amount_input")
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Saldo disponível no Sandbox:", color = NovaTextSecondary, fontSize = 12.sp)
                    Text(
                        text = formatAoa(sandboxBalance),
                        color = NovaGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = mcxDescription,
                    onValueChange = { mcxDescription = it },
                    label = { Text("Descrição da Operação", color = NovaTextSecondary) },
                    leadingIcon = { Icon(Icons.Default.Receipt, null, tint = NovaGold) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NovaGold,
                        unfocusedBorderColor = NovaNavyCardBorder,
                        focusedTextColor = NovaTextPrimary,
                        unfocusedTextColor = NovaTextPrimary
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("mcx_description_input")
                )

                // Operation Summary Card before Authorization
                if (showMcxSummary) {
                    val parsedAmount = mcxAmountText.toDoubleOrNull() ?: 0.0
                    Spacer(modifier = Modifier.height(14.dp))
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("mcx_summary_card"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = NovaNavySurface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, NovaGold, RoundedCornerShape(12.dp))
                                .padding(14.dp)
                        ) {
                            Text(
                                text = "Resumo da Operação Multicaixa Express",
                                color = NovaGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Telemóvel MCX: ${PhoneUtils.formatDisplayPhone(mcxPhone)}",
                                color = NovaTextPrimary,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "Operação: $mcxMerchantOrService",
                                color = NovaTextPrimary,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "Valor Total: ${formatAoa(parsedAmount)}",
                                color = NovaGoldLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "Provider: EMIS / MCX Express (Sandbox Configurado)",
                                color = NovaTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorMessage!!,
                        color = NovaDangerRed,
                        fontSize = 12.sp,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                if (!showMcxSummary) {
                    NovaButton(
                        text = "Ver Resumo da Operação",
                        isSecondary = true,
                        onClick = {
                            val amount = mcxAmountText.toDoubleOrNull()
                            val normalizedPhone = PhoneUtils.normalizeAngolaPhone(mcxPhone)
                            if (normalizedPhone.length < 12) {
                                errorMessage = "Introduza um número de telemóvel válido associado ao Multicaixa Express."
                                return@NovaButton
                            }
                            if (amount == null || amount <= 0) {
                                errorMessage = "Introduza um valor válido superior a zero."
                                return@NovaButton
                            }
                            errorMessage = null
                            showMcxSummary = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("mcx_review_summary_button")
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                NovaButton(
                    text = "Confirmar e Autorizar via MCX Express",
                    onClick = {
                        val amount = mcxAmountText.toDoubleOrNull()
                        if (amount == null || amount <= 0) {
                            errorMessage = "Introduza um valor válido superior a zero."
                            return@NovaButton
                        }
                        scope.launch {
                            isLoading = true
                            errorMessage = null
                            val result = paymentManager.createMulticaixaExpressOperation(
                                phoneNumber = mcxPhone,
                                amount = amount,
                                merchantOrService = mcxMerchantOrService,
                                description = mcxDescription
                            )
                            isLoading = false
                            when (result) {
                                is NetworkResult.Success -> onNavigateToAuthorize(result.data.id)
                                is NetworkResult.Error -> errorMessage = result.message
                            }
                        }
                    },
                    isLoading = isLoading,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "pay_submit_button"
                )
            }
        }
    }
}

