package com.example.domain.legal

data class FaqItem(
    val id: Int,
    val category: String,
    val question: String,
    val answer: String
)

object LegalDocumentProvider {

    val TERMS_AND_CONDITIONS = """
TERMOS E CONDIÇÕES DE UTILIZAÇÃO DO NOVA KZ
Versão: ${LegalConstants.CURRENT_TERMS_VERSION}
Data de Entrada em Vigor: ${LegalConstants.LAST_UPDATED_DATE}
Jurisdição: ${LegalConstants.JURISDICTION}

1. DISPOSIÇÕES GERAIS E OBJECTO
1.1. Os presentes Termos e Condições de Utilização ("Termos") regulam o acesso, registo e utilização da plataforma móvel, serviços e soluções tecnológicas disponibilizados sob a designação NOVA KZ ("Aplicação" ou "Plataforma").
1.2. O NOVA KZ é um projecto e produto tecnológico independente, concebido para oferecer uma experiência nativa, segura e moderna de gestão de serviços financeiros, pagamentos e inclusão financeira digital na República de Angola.
1.3. A utilização da Aplicação está estritamente condicionada à aceitação prévia, expressa e sem reservas destes Termos e da respectiva Política de Privacidade e Protecção de Dados.

2. ENQUADRAMENTO LEGAL E DECLARAÇÃO REGULATÓRIA
2.1. O NOVA KZ opera em conformidade com o ordenamento jurídico angolano aplicável aos serviços da sociedade da informação, protecção de dados e transacções electrónicas, designadamente:
    a) Lei n.º 22/11, de 17 de Junho — Lei da Protecção de Dados Pessoais;
    b) Legislação aplicável sobre Comunicações Electrónicas e Serviços de Pagamento.
2.2. O NOVA KZ NÃO É UM BANCO, INSTITUIÇÃO FINANCEIRA BANCÁRIA OU EMISSOR DIRETO DE MOEDA FIDUCIÁRIA.
2.3. O NOVA KZ actua como camada tecnológica de agregação, iniciação, encaminhamento, comunicação segura e visualização de serviços prestados por instituições bancárias, prestadores de serviços de pagamento (PSPs) e entidades parceiras devidamente licenciadas pelo Banco Nacional de Angola (BNA).
2.4. Nenhuma menção nos presentes Termos constitui declaração de detenção de licença bancária exclusiva pelo NOVA KZ.

3. CONTA DO UTILIZADOR, CADASTRO E IDONEIDADE
3.1. Para utilizar as funcionalidades da Aplicação, o Utilizador deve ser maior de 18 anos, possuir capacidade jurídica plena e fornecer dados autênticos, incluindo Nome Completo, Número de Identificação Fiscal (NIF) angolano, Telefone móvel e E-mail.
3.2. O Utilizador é o único responsável pela guarda e confidencialidade das suas credenciais de acesso, tais como PIN de aplicação, palavras-passe e dispositivos móveis associados.

4. AUTENTICAÇÃO, SEGURANÇA E BIOMETRIA
4.1. A Aplicação disponibiliza mecanismos robustos de segurança, incluindo autenticação multifactor (MFA), PIN de aplicação e biometria nativa do dispositivo (impressão digital ou reconhecimento facial).
4.2. O NOVA KZ NÃO recolhe, NÃO armazena e NÃO transmite dados biométricos brutos (impressões digitais ou mapeamento biométrico facial). A verificação biométrica é processada exclusivamente no hardware seguro (TEE / Secure Enclave) do sistema operativo Android do Utilizador.
4.3. Toda e qualquer operação de pagamento ou autorização sensível exige confirmação explícita do Utilizador antes do seu processamento.

5. AMBIENTE SANDBOX E TRANSAÇÕES DEMONSTRATIVAS
5.1. A Aplicação disponibiliza um ambiente SANDBOX identificado com destaque visual ("SANDBOX NOVA KZ").
5.2. O saldo apresentado no ambiente Sandbox (ex.: 1.000,00 AOA ou 800,00 AOA após pagamentos de demonstração) é VIRTUAL E FICTÍCIO, destinando-se unicamente a testes, demonstrações de fluxos de integração e verificação de usabilidade.
5.3. As transacções realizadas em ambiente Sandbox NÃO movimentam fundos reais, NÃO geram débitos bancários reais e NÃO conferem direitos a levantamento monetário em kwanzas reais.

6. CONTAS BANCÁRIAS E CARTÕES TOKENIZADOS
6.1. O Utilizador pode associar as suas contas bancárias de bancos angolanos (BAI, BFA, BIC, Atlântico, etc.) e cartões Multicaixa para consulta agregada e gestão.
6.2. O NOVA KZ segue rigorosos padrões de segurança: NUNCA solicita, NUNCA recebe e NUNCA armazena o código de segurança (CVV/CVC) de cartões de pagamento, nem PINs bancários de cartões físicos.
6.3. Os cartões são representados exclusivamente através de identificadores tokenizados e exibição dos últimos 4 dígitos.

7. OPERAÇÕES FINANCEIRAS E PAGAMENTOS
7.1. Os pagamentos de serviços (ex.: Energia ENDE, Água EPAL, Telecomunicações Unitel/Africell/Movicel, DSTV, Zap, etc.) e transferências seguem a máquina de estados finita: DRAFT → VALIDATED → PENDING_AUTHORIZATION → AUTHORIZED → PROCESSING → CONFIRMED.
7.2. Toda a operação gera um comprovativo digital com código de autorização e registo imutável.
7.3. O cancelamento de operações financeiras concluídas depende das regras dos prestadores de serviço e sistemas interbancários aplicáveis.

8. MÓDULO DE CRÉDITO E PARCEIROS
8.1. O NOVA KZ disponibiliza um módulo de consulta de requisitos e submissão de candidaturas de crédito pessoal junto de bancos e instituições financeiras parceiras.
8.2. A aprovação, determinação de taxas de juro, limites de crédito e prazos são de competência EXCLUSIVA do banco parceiro seleccionado.
8.3. A validação de requisitos no NOVA KZ visa apenas assegurar a conformidade documental prévia, não constituindo aprovação ou garantia de concessão de crédito.

9. SEGUROS E SERVIÇOS DE TERCEIROS
9.1. As apólices de seguro (Auto, Saúde, Viagem) e serviços parceiros são subscritos junto de seguradoras autorizadas pela ARSEG (Agência Reguladora de Seguros de Angola).
9.2. O NOVA KZ actua como canal de visualização e emissão digital simplificada.

10. PREVENÇÃO DE FRAUDE E COMBATE AO BRANQUEAMENTO DE CAPITAIS
10.1. O Utilizador compromete-se a utilizar a Aplicação exclusivamente para finalidades lícitas, repudiando qualquer uso associado a fraude, burla, branqueamento de capitais ou financiamento ao terrorismo.
10.2. O NOVA KZ reserva-se o direito de suspender cautelarmente operações suspeitas, solicitar documentação adicional ou reportar actividades anómalas às autoridades competentes nos termos da lei.

11. LIMITAÇÃO DE RESPONSABILIDADE E DISPONIBILIDADE
11.1. O NOVA KZ emprega os mais elevados padrões técnicos para assegurar a disponibilidade contínua dos serviços. Todavia, não se responsabiliza por interrupções temporárias decorrentes de manutenção, falhas nas redes de telecomunicações públicas ou indisponibilidade dos sistemas dos bancos emissores e do BNA.
11.2. O Utilizador é responsável por manter o seu telemóvel livre de vírus, trojans, acessos root ou modificações não autorizadas de sistema operativo que comprometam a segurança.

12. ALTERAÇÕES DOS TERMOS E CONDICIONAMENTO DE ACESSO
12.1. O NOVA KZ poderá actualizar os presentes Termos a qualquer momento. Sempre que ocorrer uma alteração de versão (ex.: de 1.0 para 1.1), o Utilizador será notificado e o acesso ao Dashboard e funcionalidades protegidas ficará bloqueado até nova aceitação expressa.

13. RESOLUÇÃO DE LITÍGIOS E CONTACTO
13.1. Para dúvidas, esclarecimentos, sugestões ou reclamações, o Utilizador pode contactar a nossa equipa de suporte através do e-mail oficial: ${LegalConstants.SUPPORT_EMAIL} ou WhatsApp: ${LegalConstants.SUPPORT_WHATSAPP}.
13.2. Os presentes Termos são regidos e interpretados pela legislação em vigor na República de Angola, elegendo-se o foro da Comarca de Luanda com expressa renúncia a qualquer outro.
""".trimIndent()

    val PRIVACY_POLICY = """
POLÍTICA DE PRIVACIDADE E PROTECÇÃO DE DADOS PESSOAIS — NOVA KZ
Versão: ${LegalConstants.CURRENT_PRIVACY_VERSION}
Data de Entrada em Vigor: ${LegalConstants.LAST_UPDATED_DATE}
Legislação de Referência: Lei n.º 22/11 (Lei da Protecção de Dados Pessoais da República de Angola)

1. COMPROMISSO DE PRIVACIDADE E MINIMIZAÇÃO DE DADOS
1.1. O NOVA KZ assume o compromisso fundamental de proteger a privacidade, a confidencialidade e a segurança dos dados pessoais de todos os seus utilizadores.
1.2. Adoptamos o princípio da MINIMIZAÇÃO DE DADOS: recolhemos estritamente os dados necessários para a identificação, autenticação, execução de ordens de pagamento, prevenção de fraudes e suporte ao cliente.

2. QUE DADOS SÃO RECOLHIDOS
2.1. Dados Fornecidos pelo Utilizador no Registo:
    a) Nome completo;
    b) Endereço de correio electrónico (e-mail);
    c) Número de telefone móvel;
    d) Número de Identificação Fiscal (NIF) angolano.
2.2. Dados Técnicos e de Segurança:
    a) Identificador aleatório e seguro do dispositivo;
    b) Endereço IP e carimbos de data/hora de interacção;
    c) Tokens de sessão criptografados.
2.3. Dados Financeiros e de Transacções:
    a) Histórico de pagamentos e transferências efectuadas na Aplicação;
    b) Identificadores de contas bancárias associadas (número de conta e IBAN angolano);
    c) Dados tokenizados de cartões (últimos 4 dígitos e validade);
    d) NÃO recolhemos nem armazenamos CVV/CVC nem PINs de cartões bancários físicos.
2.4. Dados Biométricos:
    a) O NOVA KZ NÃO recolhe, NÃO transmite e NÃO armazena imagens de impressões digitais nem reconhecimento facial.
    b) A autenticação biométrica é gerida exclusivamente pelo sistema operativo Android através de chaves criptográficas locais.

3. FINALIDADES DO TRATAMENTO
Os dados recolhidos destinam-se exclusivamente às seguintes finalidades:
    a) Criar e gerir a conta de utilizador no NOVA KZ;
    b) Processar, autorizar e emitir comprovativos de pagamentos e transferências;
    c) Viabilizar o encaminhamento seguro de solicitações de crédito e seguros junto dos parceiros autorizados;
    d) Prevenir fraudes, intrusões e cumprir obrigações legais de auditoria;
    e) Prestar apoio ao cliente e comunicar avisos de segurança importantes;
    f) Manter o registo auditável de aceitação de termos legais.

4. PARTILHA DE DADOS COM TERCEIROS
4.1. O NOVA KZ NÃO vende, NÃO aluga e NÃO comercializa dados pessoais dos utilizadores a anunciantes ou entidades de marketing de terceiros.
4.2. Os dados apenas são partilhados nas seguintes circunstâncias estritas:
    a) Com bancos parceiros e prestadores de serviços de pagamento oficiais (PSPs), exclusivamente quando o Utilizador solicita uma operação de pagamento ou candidatura de crédito;
    b) Com provedores de infra-estrutura em nuvem segura com encriptação em trânsito e em repouso (TLS 1.3 e AES-256);
    c) Em cumprimento de mandados judiciais ou notificações de autoridades reguladoras da República de Angola (BNA, ARSEG, PGR).

5. DIREITOS DOS TITULARES DOS DADOS
Nos termos da Lei n.º 22/11 de Protecção de Dados Pessoais de Angola, o Utilizador tem o direito de:
    a) Aceder e consultar os seus dados pessoais armazenados na Aplicação;
    b) Solicitar a correcção ou actualização de dados inexactos ou incompletos;
    c) Solicitar o bloqueio ou eliminação de dados tratados em desconformidade com a lei;
    d) Opor-se, por motivos legítimos, ao tratamento dos seus dados para determinados fins;
    e) Revogar consentimentos previamente concedidos, ciente de que tal revogação poderá impossibilitar o fornecimento contínuo de funcionalidades dependentes.

6. CONSERVAÇÃO E SEGURANÇA DOS DADOS
6.1. Os dados são conservados pelo período estritamente necessário para as finalidades do tratamento e para o cumprimento de prazos legais e regulamentares de arquivo contabilístico e fiscal vigentes em Angola.
6.2. Implementamos medidas técnicas e organizativas de ponta, tais como criptografia em repouso, políticas de Row Level Security (RLS) no Supabase, tokens de curta duração e restrição de acesso por privilégios mínimos.

7. CONTACTO DO ENCARREGADO DE PROTECÇÃO DE DADOS
Para o exercício de qualquer um dos seus direitos ou esclarecimento sobre o tratamento de dados pessoais, contacte o nosso Encarregado de Protecção de Dados através de:
E-mail: ${LegalConstants.SUPPORT_EMAIL}
WhatsApp / Linha de Apoio: ${LegalConstants.SUPPORT_WHATSAPP}
Morada: Luanda, República de Angola.
""".trimIndent()

    val FAQ_ITEMS = listOf(
        FaqItem(
            id = 1,
            category = "Geral",
            question = "1. O que é o NOVA KZ?",
            answer = "O NOVA KZ é uma plataforma móvel e ecossistema tecnológico independente concebido para centralizar a gestão de pagamentos, transferências, cartões, serviços e crédito pessoal em Angola com tecnologia moderna e segura."
        ),
        FaqItem(
            id = 2,
            category = "Geral",
            question = "2. O NOVA KZ é um banco?",
            answer = "Não. O NOVA KZ não é um banco nem uma instituição de crédito. É uma fintech e plataforma de software que se conecta de forma segura a bancos e prestadores de serviços de pagamento devidamente licenciados pelo Banco Nacional de Angola (BNA)."
        ),
        FaqItem(
            id = 3,
            category = "Sandbox",
            question = "3. O que é o Sandbox?",
            answer = "O Sandbox é um ambiente de demonstração e testes seguro do NOVA KZ onde pode experimentar todas as funcionalidades (pagamentos, transferências, autorização biométrica e comprovativos) sem utilizar dinheiro real."
        ),
        FaqItem(
            id = 4,
            category = "Sandbox",
            question = "4. O saldo Sandbox é dinheiro verdadeiro?",
            answer = "Não. O saldo exibido no ambiente Sandbox é totalmente fictício e virtual. Não pode ser levantado, transferido para contas bancárias externas nem trocado por notas de Kwanza."
        ),
        FaqItem(
            id = 5,
            category = "Pagamentos",
            question = "5. Como funciona um pagamento?",
            answer = "Para pagar um serviço ou fatura, escolha o fornecedor (ex.: ENDE, EPAL, Unitel), insira a referência e o valor, valide os dados e confirme a operação mediante a sua autenticação biométrica ou PIN de segurança."
        ),
        FaqItem(
            id = 6,
            category = "Segurança",
            question = "6. Por que é necessária autorização?",
            answer = "A autorização é uma camada essencial de segurança bancária para garantir que nenhuma transação financeira seja processada sem o consentimento voluntário, consciente e explícito do titular da conta."
        ),
        FaqItem(
            id = 7,
            category = "Segurança",
            question = "7. Posso utilizar biometria?",
            answer = "Sim. O NOVA KZ suporta impressão digital e reconhecimento facial nativos do Android para desbloquear a aplicação e autorizar pagamentos de forma rápida e protegida."
        ),
        FaqItem(
            id = 8,
            category = "Segurança",
            question = "8. O NOVA KZ guarda a minha impressão digital?",
            answer = "Não. O NOVA KZ nunca tem acesso aos seus dados biométricos brutos. A validação ocorre estritamente dentro da área de segurança do processador do seu telemóvel (Android Keystore)."
        ),
        FaqItem(
            id = 9,
            category = "Contas",
            question = "9. Posso adicionar uma conta bancária?",
            answer = "Sim. Pode associar contas bancárias de bancos angolanos (como BAI, BFA, BIC, Atlântico, etc.) inserindo o número de conta e o respetivo IBAN para facilitar transferências e consultas."
        ),
        FaqItem(
            id = 10,
            category = "Cartões",
            question = "10. Posso adicionar cartões?",
            answer = "Sim. Pode registar cartões Multicaixa ou pré-pagos. Os cartões são tokenizados de forma segura, mantendo apenas a referência e os últimos 4 dígitos para sua protecção."
        ),
        FaqItem(
            id = 11,
            category = "Parceiros",
            question = "11. O NOVA KZ funciona com todos os bancos?",
            answer = "O NOVA KZ foi arquitetado para suportar os principais bancos do sistema financeiro angolano. A disponibilidade de cada funcionalidade específica depende das integrações ativas com os canais oficiais de cada entidade."
        ),
        FaqItem(
            id = 12,
            category = "Operações",
            question = "12. O NOVA KZ movimenta dinheiro real?",
            answer = "Em ambiente Sandbox as operações são de simulação. Quando conectado aos canais oficiais de produção das instituições financeiras parceiras, as operações passam a instruir transações reais com total enquadramento bancário."
        ),
        FaqItem(
            id = 13,
            category = "Operações",
            question = "13. O que significa Pendente?",
            answer = "O estado 'Pendente' (PENDING_AUTHORIZATION) significa que a operação foi criada com sucesso pelo sistema e está a aguardar a sua confirmação com PIN ou biometria para poder ser enviada ao processamento."
        ),
        FaqItem(
            id = 14,
            category = "Operações",
            question = "14. O que acontece se um pagamento falhar?",
            answer = "Se uma operação falhar por erro de rede ou saldo insuficiente, o valor não é deduzido (ou é revertido imediatamente), e o motivo da falha é detalhado no comprovativo e no histórico."
        ),
        FaqItem(
            id = 15,
            category = "Histórico",
            question = "15. Onde vejo o histórico?",
            answer = "Pode consultar todo o histórico detalhado de pagamentos, transferências e recibos clicando no separador 'Histórico' na barra de navegação principal da aplicação."
        ),
        FaqItem(
            id = 16,
            category = "Privacidade",
            question = "16. Os meus dados estão protegidos?",
            answer = "Sim. O NOVA KZ utiliza criptografia ponta a ponta (TLS 1.3), bases de dados com Row Level Security (RLS) e cumpre rigorosamente a Lei n.º 22/11 de Protecção de Dados Pessoais de Angola."
        ),
        FaqItem(
            id = 17,
            category = "Segurança",
            question = "17. Como funciona a segurança?",
            answer = "Contamos com bloqueio automático por inactividade, PIN criptografado com sal, verificação biométrica em hardware seguro, proteção contra captura de ecrã e anti-roubo com bloqueio preventivo de cartões."
        ),
        FaqItem(
            id = 18,
            category = "Segurança",
            question = "18. O que faço se alguém entrar na minha conta?",
            answer = "Aceda imediatamente a Definições > Segurança > Anti-Roubo para suspender as operações e bloquear cartões. Poderá também alterar o seu PIN e contactar de imediato o nosso suporte oficial."
        ),
        FaqItem(
            id = 19,
            category = "Crédito",
            question = "19. O NOVA KZ disponibiliza crédito?",
            answer = "O NOVA KZ disponibiliza um módulo de verificação de requisitos e encaminhamento de pedidos de crédito junto de bancos parceiros. A decisão de aprovação de crédito pertence única e exclusivamente ao banco selecionado."
        ),
        FaqItem(
            id = 20,
            category = "Serviços",
            question = "20. Posso pagar serviços?",
            answer = "Sim. Pode pagar energia pré-paga e pós-paga (ENDE), abastecimento de água (EPAL), planos móveis e internet (Unitel, Africell, Movicel), televisão (DSTV, Zap) e outros serviços utilitários em Angola."
        ),
        FaqItem(
            id = 21,
            category = "Operações",
            question = "21. Posso cancelar uma operação?",
            answer = "Pode cancelar operações que estejam no estado 'Pendente' ou em 'Rascunho'. Após a conclusão e confirmação junto da entidade prestadora, o estorno depende dos procedimentos normativos do fornecedor."
        ),
        FaqItem(
            id = 22,
            category = "Suporte",
            question = "22. O que faço se o saldo estiver incorrecto?",
            answer = "Puxe o ecrã para baixo para forçar a sincronização de rede. Se a divergência persistir, abra o Histórico para verificar as últimas movimentações e entre em contacto com o suporte através da aplicação."
        ),
        FaqItem(
            id = 23,
            category = "Suporte",
            question = "23. Como faço uma reclamação?",
            answer = "Aceda a Perfil > Suporte ou envie um e-mail para ${LegalConstants.SUPPORT_EMAIL} (ou WhatsApp ${LegalConstants.SUPPORT_WHATSAPP}) com o comprovativo da operação e a descrição do ocorrido para que a equipa técnica possa auditar os registos."
        ),
        FaqItem(
            id = 24,
            category = "Legal",
            question = "24. Onde encontro os Termos?",
            answer = "Os Termos e Condições de Utilização podem ser consultados a qualquer momento na aplicação em Perfil > Termos e Condições, ou durante o processo de aceitação legal obrigatória."
        ),
        FaqItem(
            id = 25,
            category = "Legal",
            question = "25. Onde encontro a Política de Privacidade?",
            answer = "A Política de Privacidade e Protecção de Dados está disponível em Perfil > Privacidade e Protecção de Dados, com todos os detalhes sobre a recolha e salvaguarda de informações."
        ),
        FaqItem(
            id = 26,
            category = "Conta",
            question = "26. Posso encerrar a conta?",
            answer = "Sim. Pode solicitar a eliminação definitiva da sua conta e de dados elegíveis diretamente na aplicação em Perfil > Segurança > Eliminar Conta NOVA KZ (ou Perfil > Eliminar Conta), ou através da página web oficial, em plena observância dos direitos do titular da Lei n.º 22/11."
        ),
        FaqItem(
            id = 27,
            category = "Legal",
            question = "27. Os Termos substituem o contrato do meu banco?",
            answer = "Não. Os Termos do NOVA KZ regulam unicamente a utilização da aplicação. A sua relação contratual com os bancos onde mantém contas continua a ser regida pelos contratos celebrados com as respectivas instituições bancárias."
        ),
        FaqItem(
            id = 28,
            category = "Suporte",
            question = "28. Como posso contactar o suporte?",
            answer = "Pode contactar a equipa de apoio técnico e de atendimento ao cliente através do e-mail ${LegalConstants.SUPPORT_EMAIL}, WhatsApp ${LegalConstants.SUPPORT_WHATSAPP}, ou pelo canal de suporte integrado na aplicação em Perfil > Suporte."
        )
    )
}
