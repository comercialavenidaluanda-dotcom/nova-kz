package com.example.notifications

import com.example.domain.models.NotificationCategory
import com.example.domain.models.NovaNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotificationRepository {

    private val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "AO"))

    private val _notifications = MutableStateFlow<List<NovaNotification>>(emptyList())
    val notifications: StateFlow<List<NovaNotification>> = _notifications.asStateFlow()

    init {
        loadDefaultNotifications()
    }

    private fun loadDefaultNotifications() {
        // Production build: no synthetic notifications are seeded.
        _notifications.value = emptyList()
    }

    fun markAsRead(id: String) {
        _notifications.value = _notifications.value.map {
            if (it.id == id) it.copy(isRead = true) else it
        }
    }

    fun markAllAsRead() {
        _notifications.value = _notifications.value.map { it.copy(isRead = true) }
    }

    fun addNotification(notification: NovaNotification) {
        _notifications.value = listOf(notification) + _notifications.value
    }
}
