# NOVA KZ — GOOGLE PLAY CLOSED TEST CHECKLIST

**Projeto:** NOVA KZ  
**Pacote (applicationId):** `ao.novakz.app`  
**Canais Oficiais de Suporte:**  
- **E-mail:** `ivanioalberto83@gmail.com`  
- **WhatsApp:** `+244 946 110 370`  

---

## 1. REGRA MANDATÓRIA GOOGLE PLAY (CONTAS PESSOAIS PÓS-NOVEMBRO 2023)
Se a sua conta de programador na Google Play Console for uma conta pessoal registada após 13 de Novembro de 2023:
- **Exigência Obrigatória:** Pelo menos **12 testadores** devem estar ativamente inscritos no teste fechado durante pelo menos **14 dias ininterruptos**.
- **Nota de Segurança:** Esta exigência é regulamentada pelo Google Play. Não tente simular contas fictícias nem burlar o processo no aplicativo; o processo deve ser cumprido com utilizadores e dispositivos reais.

---

## 2. GUIA PASSO A PASSO NA GOOGLE PLAY CONSOLE

### Fase 1: Criar a Faixa de Teste Fechado (Closed Testing Track)
1. Inicie sessão na [Google Play Console](https://play.google.com/console).
2. Selecione a aplicação **NOVA KZ**.
3. No menu lateral, navegue até **Testar e lançar** > **Teste** > **Teste fechado** (*Closed testing*).
4. Clique em **Criar faixa** (ou utilize a faixa fechada padrão `Alpha`).
5. Nome da faixa sugerido: `NOVA KZ Teste Fechado v1.0`.

### Fase 2: Configurar a Lista de Testadores
1. Na faixa de teste fechado, clique no separador **Testadores**.
2. Escolha **Criar lista de e-mails** (ou vincule um Grupo do Google, ex.: `testadores-novakz@googlegroups.com`).
3. Adicione os endereços de e-mail dos seus testadores (mínimo de 15 a 20 convidados para assegurar que pelo menos 12 permaneçam ativos sem interrupções).
4. Indique o e-mail de feedback para os testadores: `ivanioalberto83@gmail.com`.
5. Guarde as alterações.

### Fase 3: Carregar a Versão Release (AAB)
1. Clique em **Criar novo lançamento**.
2. Faça o upload do ficheiro:
   ```
   app/build/outputs/bundle/release/app-release.aab
   ```
3. Nome da versão: `1.0.0 (1)`.
4. Notas da versão (Português de Angola / pt-PT / pt-BR):
   ```
   Versão inicial de testes fechados do NOVA KZ:
   - Gestão integrada de pagamentos e serviços.
   - Ambiente de testes Sandbox seguro (1.000 AOA demonstrativos).
   - Autenticação e autorização por PIN e biometria nativa.
   - Conformidade com a Lei n.º 22/11 de Protecção de Dados Pessoais.
   - Canal oficial de feedback: ivanioalberto83@gmail.com e WhatsApp +244 946 110 370.
   ```
5. Clique em **Rever e iniciar lançamento para Teste Fechado**.

### Fase 4: Envio do Link de Adesão aos Testadores
1. Após a aprovação do lançamento de teste fechado pelo Google, volte ao separador **Testadores**.
2. Copie o **Link para participar no teste** (disponível via Web e via Android).
3. Envie este link e as instruções aos seus testadores convidados.
4. **Instruções para os testadores:**
   - Clicar no link de convite.
   - Aceitar tornar-se testador.
   - Descarregar a aplicação NOVA KZ através da Play Store no seu telemóvel Android.
   - Abrir a aplicação, explorar as funcionalidades e manter a aplicação instalada durante os 14 dias.

---

## 3. ROTEIRO DE VERIFICAÇÃO PARA OS TESTADORES

Forneça aos seus testadores a seguinte lista de tarefas para validação:
- [ ] **Instalação e Abertura:** Instalar a partir da Google Play Store e verificar abertura sem falhas.
- [ ] **Leitura Legal:** Visualizar e aceitar os Termos e Condições e a Política de Privacidade.
- [ ] **Persistência:** Fechar a aplicação e abrir novamente, confirmando que os Termos não são pedidos de forma repetida.
- [ ] **Saldo Sandbox:** Confirmar o saldo demonstrativo inicial de 1.000,00 AOA e testar a ocultação de saldo (ícone do olho).
- [ ] **Pagamento de Serviço Sandbox:** Efetuar um pagamento de teste (ex.: recarga ou eletricidade de 200,00 AOA) e verificar a transição para 800,00 AOA.
- [ ] **Recibo Digital:** Conferir a visualização do comprovativo digital no ecrã e no separador Histórico.
- [ ] **Biometria:** Ativar a autenticação biométrica em *Perfil > Segurança* e testar o desbloqueio rápido.
- [ ] **Suporte e Feedback:** Reportar qualquer comportamento anómalo através do e-mail `ivanioalberto83@gmail.com` ou WhatsApp `+244 946 110 370`.

---

## 4. CHECKLIST FINAL PARA SOLICITAR ACESSO À PRODUÇÃO

Quando o período de 14 dias estiver concluído:
- [ ] Mínimo de 12 testadores inscritos continuamente há pelo menos 14 dias seguidos na Google Play Console.
- [ ] Questionário sobre o teste fechado respondido na Play Console (descrever o feedback recolhido, melhorias implementadas e perfil dos testadores).
- [ ] Todos os itens do menu da Play Console (Data Safety, Classificação de Conteúdo, Ficha da Loja, Acesso à Aplicação) totalmente preenchidos e validados.
- [ ] Clicar no botão **Solicitar acesso à produção** na Google Play Console.
