const DEFAULT_TARGET = 'https://earucsaqqtbllnqsxvlb.supabase.co/functions/v1/nova-kz-bitpay-webhook';

function getTarget() {
  return process.env.NOVA_KZ_WEBHOOK_URL || DEFAULT_TARGET;
}

function copyForwardHeaders(req) {
  const headers = {
    'content-type': req.headers['content-type'] || 'application/json',
    'user-agent': 'NOVA-KZ-BitPay-Relay/1.0',
  };

  // Preserve BitPay signature headers when present, without inventing credentials.
  const xSignature = req.headers['x-signature'];
  const bitpaySignature = req.headers['bitpay-signature'];
  if (xSignature) headers['x-signature'] = xSignature;
  if (bitpaySignature) headers['BitPay-Signature'] = bitpaySignature;

  return headers;
}

async function readBody(req) {
  if (typeof req.body === 'string') return req.body;
  if (req.body && typeof req.body === 'object') return JSON.stringify(req.body);

  const chunks = [];
  for await (const chunk of req) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  return Buffer.concat(chunks).toString('utf8');
}

export default async function handler(req, res) {
  if (req.method === 'GET') {
    return res.status(200).json({
      ok: true,
      service: 'nova-kz-bitpay-relay',
      target_configured: Boolean(process.env.NOVA_KZ_WEBHOOK_URL || DEFAULT_TARGET),
    });
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ ok: false, error: 'METHOD_NOT_ALLOWED' });
  }

  const target = getTarget();
  const body = await readBody(req);

  try {
    const upstream = await fetch(target, {
      method: 'POST',
      headers: copyForwardHeaders(req),
      body,
    });

    const responseText = await upstream.text();

    // Return the upstream HTTP status so BitPay can see exactly what happened.
    // The NOVA KZ endpoint normally returns 200 with an empty body.
    res.status(upstream.status);

    const contentType = upstream.headers.get('content-type');
    if (contentType) res.setHeader('content-type', contentType);

    return res.send(responseText);
  } catch (error) {
    console.error('[NOVA KZ BitPay Relay] upstream request failed', {
      target,
      message: error instanceof Error ? error.message : String(error),
    });

    return res.status(502).json({
      ok: false,
      error: 'UPSTREAM_UNREACHABLE',
    });
  }
}
