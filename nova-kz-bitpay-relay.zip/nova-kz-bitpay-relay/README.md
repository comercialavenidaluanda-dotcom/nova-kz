# NOVA KZ — BitPay Webhook Relay

Relay Vercel simples, sem dependências, para diagnosticar e encaminhar webhooks BitPay para o NOVA KZ.

## Endpoint

Depois do deploy, o endpoint será:

`https://SEU-PROJETO.vercel.app/api/bitpay-webhook`

GET retorna um health check `200`.

POST encaminha o corpo recebido para:

`https://earucsaqqtbllnqsxvlb.supabase.co/functions/v1/nova-kz-bitpay-webhook`

O código também encaminha `x-signature` e `BitPay-Signature` quando existirem.

## Configuração opcional

A variável de ambiente `NOVA_KZ_WEBHOOK_URL` pode ser criada na Vercel para substituir o destino padrão.

Não coloque a `service_role`, a chave secreta BitPay ou outras credenciais privadas neste projeto.

## Publicar gratuitamente na Vercel

1. Crie um projeto novo na Vercel.
2. Faça upload deste projeto ou importe o repositório.
3. Não é necessário instalar dependências.
4. Após o deploy, teste:

   `https://SEU-PROJETO.vercel.app/api/bitpay-webhook`

   Deve retornar JSON com `ok: true`.

5. No BitPay, altere a URL do webhook existente para:

   `https://SEU-PROJETO.vercel.app/api/bitpay-webhook`

6. Faça Retry do `test.ping` existente.

## Interpretação

- `HTTP 200`: BitPay alcançou o relay e o relay alcançou o NOVA KZ.
- `HTTP 502`: o relay não conseguiu alcançar o webhook NOVA KZ.
- `HTTP 4xx/5xx`: o relay alcançou o NOVA KZ, e o status retornado veio do upstream.
- `HTTP 0` no BitPay: o BitPay ainda não conseguiu concluir uma resposta HTTP do relay.

O relay não cria pagamentos e não altera nenhuma operação financeira por conta própria.
